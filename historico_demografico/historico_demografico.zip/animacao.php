<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Hist&oacute;rico Demogr&aacute;fico do Munic&iacute;pio de S&atilde;o Paulo</title>
<link rel="stylesheet" type="text/css" href="estilo_padrao.css">
<script language="JavaScript1.2" src="funcoes.js"></script>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="resource-type" content="document" />
<meta name="classification" content="Internet" />
<meta name="description" content="Viaje pela hist&oacute;ria do Munic&iacute;pio de S&atilde;o Paulo atrav&eacute;s de anima&ccedil;&otilde;es com  mapas, fatos e fotos de &eacute;poca. Acesse tamb&eacute;m informa&ccedil;&otilde;es dos censos de  1872 at&eacute; 2000." />
<meta name="keywords" content="mapas, tabelas, são paulo, município, georreferenciamento, geo, infolocal, educação, cultura, saúde, habitação, esportes, transportes, abastecimento, economia, meio ambiente, planejamento, inundação, mananciais, enchentes, alagamento, endereços, indicadores, estatística, informação, geografia, dados, subprefeitura, prefeitura, hidrografia, censo, ibge, orçamento, plano diretor, pde, revisão, licitações, urbanismo, história, histórico" />
<meta name="robots" content="ALL" />
<meta name="distribution" content="Global" />
<meta name="rating" content="General" />
<meta name="author" content="Guilherme Passotti, Thiago Ramon" />
<meta name="language" content="pt-br" />
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">

</head>

<body onLoad="MM_preloadImages('img/botao_apresentacao_2.jpg','img/botao_equipe_2.jpg','img/botao_dados_2.jpg','img/menu-acesso-animacao-hover.jpg','img/menu-acesso-fotosmapas-hover.jpg','img/menu-acesso-tabelas-hover.jpg')">

<div id="geral">

<table align="center" border="0" cellpadding="0" cellspacing="0" width="780">

    <tr><td><div id="header_prefeitura">
</div></div>
</div></td></tr>

    <tr><td><table width="778" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td><div id="tarja_laranja"> <a href="index.php" title="Voltar para a p&aacute;gina inicial">
		<h1 class="semestilo">Hist&oacute;rico Demogr&aacute;fico do Munic&iacute;pio de S&atilde;o Paulo</h1>
		</a> </div></td>
		<td align="right">
				<a href="index.php"><img src="img/botao_apresentacao_1.jpg" name="Image1" width="103" height="35" border="0" id="Image1" title="Página Inicial" onMouseOver="MM_swapImage('Image1','','img/botao_apresentacao_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a><a href="introducao.php"><img src="img/botao_introducao_1.jpg" name="Image2" width="85" height="35" border="0" id="Image2" title="Introdu&ccedil;&atilde;o" onMouseOver="MM_swapImage('Image2','','img/botao_introducao_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a><a href="equipe.php"><img src="img/botao_equipe_1.jpg" name="Image3" width="108" height="35" border="0" id="Image3" title="Equipe T&eacute;cnica" onMouseOver="MM_swapImage('Image3','','img/botao_equipe_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a><a href="tabelas.php"><img src="img/botao_dados_1.jpg" name="Image4" width="76" height="35" border="0" id="Image4" title="Tabelas" onMouseOver="MM_swapImage('Image4','','img/botao_dados_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a></td>
	</tr>
</table></td></tr>
	  
</table></div>
<div id="animacao">
<script language="javascript">
if (AC_FL_RunContent == 0) {
alert("This page requires AC_RunActiveContent.js. In Flash, run \"Apply Active Content Update\" in the Commands menu to copy AC_RunActiveContent.js to the HTML output folder.");
} else {
AC_FL_RunContent(
'codebase', 'http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0',
'width', '100%',
'height', '300',
'src', 'img/animacao',
'quality', 'high',
'pluginspage', 'http://www.macromedia.com/go/getflashplayer',
'align', 'middle',
'play', 'true',
'loop', 'true',
'scale', 'showall',
'wmode', 'transparent',
'devicefont', 'false',
'id', 'animacao',
'bgcolor', '#ffffff',
'name', 'animacao',
'menu', 'false',
'allowScriptAccess','sameDomain',
'movie', 'img/animacao',
'salign', ''
); //end AC code
}
</script>
<noscript><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" width="100%" height="300"> 
  <param name="movie" value="img/animacao.swf">
  <param name="quality" value="high">
  <embed src="img/animacao.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type=application/x-shockwave-flash" width="100%" height="300"></embed>
</object>
</noscript>
</div>
<div>
</div>

<div id="assinatura">
<div style="text-align:center"><div>
</div>

</body>
</html>