<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Hist&oacute;rico Demogr&aacute;fico do Munic&iacute;pio de S&atilde;o Paulo</title>
<link rel="stylesheet" type="text/css" href="../estilo_padrao.css">
<script language="JavaScript1.2" src="../funcoes.js"></script><style type="text/css">
<!--
.xl24 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl25 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl26 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl27 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl28 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl29 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl30 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl31 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl32 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl241 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl242 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl243 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl244 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl251 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl261 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl271 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl281 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl291 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl301 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl311 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl321 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
-->
</style>
</head>

<body>

<div id="geral">

<table align="center" border="0" cellpadding="0" cellspacing="0" width="780">

    <tr><td><div id="header_prefeitura">
</div></div>
</div></td></tr>

    <tr><td><table width="778" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td><div id="tarja_laranja"> <a href="../index.php" title="Voltar para a p&aacute;gina inicial">
		<h1 class="semestilo">Hist&oacute;ria Demogr&aacute;fica do Munic&iacute;pio de S&atilde;o Paulo</h1>
		</a> </div></td>
		<td align="right">
		
		<a href="../index.php"><img src="../img/botao_apresentacao_1.jpg" alt="P&aacute;gina Inicial" name="Image1" width="103" height="35" border="0" id="Image1" title="Página Inicial" onMouseOver="MM_swapImage('Image1','','../img/botao_apresentacao_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a><a href="../introducao.php"><img src="../img/botao_introducao_1.jpg" alt="Introdu&ccedil;&atilde;o" name="Image2" width="85" height="35" border="0" id="Image2" title="Introdu&ccedil;&atilde;o" onMouseOver="MM_swapImage('Image2','','../img/botao_introducao_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a><a href="../equipe.php"><img src="../img/botao_equipe_1.jpg" alt="Equipe T&eacute;cnica" name="Image3" width="108" height="35" border="0" id="Image3" title="Equipe T&eacute;cnica" onMouseOver="MM_swapImage('Image3','','../img/botao_equipe_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a><a href="../tabelas.php"><img src="../img/botao_dados_1.jpg" alt="Tabelas" name="Image4" width="76" height="35" border="0" id="Image4" title="Tabelas" onMouseOver="MM_swapImage('Image4','','../img/botao_dados_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a></td>
	</tr>
</table></td></tr>
	  
</table>

<div id="conteudo"> 
  <h1>Tabelas</h1>
  <p>&nbsp;</p>
  <table x:str="x:str" border="0" cellpadding="0" cellspacing="0" width="355" style='border-collapse:
 collapse;table-layout:fixed;width:267pt'>
    <col class="xl251" width="69" style='mso-width-source:userset;mso-width-alt:2523;
 width:52pt' />
    <col class="xl251" width="80" style='mso-width-source:userset;mso-width-alt:2925;
 width:60pt' />
    <col class="xl251" width="93" style='mso-width-source:userset;mso-width-alt:3401;
 width:70pt' />
    <col class="xl251" width="113" style='mso-width-source:userset;mso-width-alt:4132;
 width:85pt' />
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl244" colspan="4" width="355" style='height:12.75pt;
  mso-ignore:colspan;width:267pt'>Total de Domic&iacute;lios e N&ordm; M&eacute;dio
        Pessoas/Domic&iacute;lio</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl244" colspan="3" style='height:12.75pt;mso-ignore:colspan'>Munic&iacute;pio
        de S&atilde;o Paulo</td>
      <td class="xl244"></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl244" colspan="2" style='height:12.75pt;mso-ignore:colspan'>1960
        a 2000</td>
      <td colspan="2" class="xl244" style='mso-ignore:colspan'></td>
    </tr>
    <tr height="18" style='height:13.5pt'>
      <td height="18" class="xl261" style='height:13.5pt'>&nbsp;</td>
      <td class="xl261">&nbsp;</td>
      <td class="xl261">&nbsp;</td>
      <td class="xl261">&nbsp;</td>
    </tr>
    <tr height="18" style='height:13.5pt'>
      <td height="18" class="xl271" style='height:13.5pt;border-top:none'>Ano</td>
      <td class="xl271" style='border-top:none' x:str="Popula&ccedil;&atilde;o* ">Popula&ccedil;&atilde;o*<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td class="xl271" style='border-top:none'>Domic&iacute;lios*</td>
      <td class="xl271" style='border-top:none'>Pessoas/Domic&iacute;lio</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl281" style='height:12.75pt'>1960**</td>
      <td class="xl291" x:num="3781446">3.781.446</td>
      <td class="xl291" x:num="834935">834.935</td>
      <td class="xl281" x:num="4.53">4,53</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl281" style='height:12.75pt' x:num="x:num">1970</td>
      <td class="xl291" x:num="5924615">5.924.615</td>
      <td class="xl291" x:num="1272279">1.272.279</td>
      <td class="xl281" x:num="4.66">4,66</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl281" style='height:12.75pt' x:num="x:num">1980</td>
      <td class="xl291" x:num="8493226">8.493.226</td>
      <td class="xl291" x:num="2062157">2.062.157</td>
      <td class="xl281" x:num="4.12">4,12</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl281" style='height:12.75pt' x:num="x:num">1991</td>
      <td class="xl291" x:num="9527426">9.527.426</td>
      <td class="xl291" x:num="2539953">2.539.953</td>
      <td class="xl281" x:num="3.75">3,75</td>
    </tr>
    <tr height="18" style='height:13.5pt'>
      <td height="18" class="xl301" style='height:13.5pt' x:num="x:num">2000</td>
      <td class="xl311" x:num="10338932">10.338.932</td>
      <td class="xl311" x:num="2985977">2.985.977</td>
      <td class="xl301" x:num="3.46">3,46</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl321" colspan="3" style='height:12.75pt;mso-ignore:colspan'>Fonte:
        IBGE, Censos Demogr&aacute;ficos</td>
      <td class="xl321"></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl321" colspan="4" style='height:12.75pt;mso-ignore:colspan'>*
        Refere-se aos domic&iacute;lios Particulares Permanentes</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl321" colspan="4" style='height:12.75pt;mso-ignore:colspan'>**
        Inclui os dados do futuro Munic&iacute;pio de Osasco</td>
    </tr>
    <![if supportMisalignedColumns]>
    <tr height="0" style='display:none'>
      <td width="69" style='width:52pt'></td>
      <td width="80" style='width:60pt'></td>
      <td width="93" style='width:70pt'></td>
      <td width="113" style='width:85pt'></td>
    </tr>
    <![endif]>
  </table>
  <p>&nbsp;</p>
  <p><strong><img src="../img/seta-download.gif" width="11" height="12" /></strong><strong> </strong><a href="xls/dom.xls" title="Clique para baixar a tabela no formato Excel (.xls)"><strong>FORMATO EXCEL (.XLS)</strong></a></p>
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">
</div>

</div>

<td><div id="assinatura">
<div style="text-align:center"><div>
</div></td>

</body>
</html>
