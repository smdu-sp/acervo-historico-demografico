<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Hist&oacute;rico Demogr&aacute;fico do Munic&iacute;pio de S&atilde;o Paulo</title>
<link rel="stylesheet" type="text/css" href="../estilo_padrao.css">
<script language="JavaScript1.2" src="../funcoes.js"></script><style type="text/css">
<!--
.xl24 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl25 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl26 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl27 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl28 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl29 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl30 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl31 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl32 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl241 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl242 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl243 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl244 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl251 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl261 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl271 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl281 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl291 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl301 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl311 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl321 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl245 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl252 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl262 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl272 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl282 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl292 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl302 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl312 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl322 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl33 {mso-style-parent:style21;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl34 {mso-style-parent:style21;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl35 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl36 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl37 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl38 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl39 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl40 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl41 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
-->
</style>
</head>

<body>

<div id="geral">

<table align="center" border="0" cellpadding="0" cellspacing="0" width="780">

    <tr><td><div id="header_prefeitura">
</div></div>
</div></td></tr>

    <tr><td><table width="778" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td><div id="tarja_laranja"> <a href="../index.php" title="Voltar para a p&aacute;gina inicial">
		<h1 class="semestilo">Hist&oacute;ria Demogr&aacute;fica do Munic&iacute;pio de S&atilde;o Paulo</h1>
		</a> </div></td>
		<td align="right">
		
		<a href="../index.php"><img src="../img/botao_apresentacao_1.jpg" alt="P&aacute;gina Inicial" name="Image1" width="103" height="35" border="0" id="Image1" title="Página Inicial" onMouseOver="MM_swapImage('Image1','','../img/botao_apresentacao_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a><a href="../introducao.php"><img src="../img/botao_introducao_1.jpg" alt="Introdu&ccedil;&atilde;o" name="Image2" width="85" height="35" border="0" id="Image2" title="Introdu&ccedil;&atilde;o" onMouseOver="MM_swapImage('Image2','','../img/botao_introducao_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a><a href="../equipe.php"><img src="../img/botao_equipe_1.jpg" alt="Equipe T&eacute;cnica" name="Image3" width="108" height="35" border="0" id="Image3" title="Equipe T&eacute;cnica" onMouseOver="MM_swapImage('Image3','','../img/botao_equipe_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a><a href="../tabelas.php"><img src="../img/botao_dados_1.jpg" alt="Tabelas" name="Image4" width="76" height="35" border="0" id="Image4" title="Tabelas" onMouseOver="MM_swapImage('Image4','','../img/botao_dados_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a></td>
	</tr>
</table></td></tr>
	  
</table>

<div id="conteudo"> 
  <h1>Tabelas</h1>
  <p>&nbsp;</p>
  <table x:str="x:str" border="0" cellpadding="0" cellspacing="0" width="729" style='border-collapse:
 collapse;table-layout:fixed;width:564pt'>
    <col class="xl272" width="501" style='mso-width-source:userset;mso-width-alt:18322;
 width:376pt' />
    <col class="xl262" width="62" span="4" style='mso-width-source:userset;mso-width-alt:
 2267;width:47pt' />
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl245" width="521" style='height:12.75pt;width:376pt'>Estrangeiros
        por Principais Pa&iacute;ses de Origem</td>
      <td class="xl262" width="42" style='width:47pt'></td>
      <td class="xl262" width="62" style='width:47pt'></td>
      <td class="xl262" width="62" style='width:47pt'></td>
      <td class="xl262" width="65" style='width:47pt'></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl245" style='height:12.75pt'
  x:str="Munic&iacute;pio de S&atilde;o Paulo ">Munic&iacute;pio de S&atilde;o Paulo<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td colspan="4" class="xl262" style='mso-ignore:colspan'></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl245" style='height:12.75pt'>1970 a 2000</td>
      <td colspan="2" class="xl262" style='mso-ignore:colspan'></td>
      <td class="xl282"></td>
      <td class="xl262"></td>
    </tr>
    <tr height="18" style='height:13.5pt'>
      <td height="18" class="xl252" style='height:13.5pt'>&nbsp;</td>
      <td class="xl292">&nbsp;</td>
      <td class="xl292">&nbsp;</td>
      <td class="xl302">&nbsp;</td>
      <td class="xl292">&nbsp;</td>
    </tr>
    <tr height="18" style='height:13.5pt'>
      <td height="18" class="xl312" style='height:13.5pt;border-top:none'>MSP/ESTRANGEIROS</td>
      <td class="xl322" style='border-top:none' x:num="x:num">1970</td>
      <td class="xl322" style='border-top:none' x:num="x:num">1980</td>
      <td class="xl322" style='border-top:none' x:num="x:num">1991</td>
      <td class="xl322" style='border-top:none' x:num="x:num">2000</td>
    </tr>
    <tr class="xl245" height="17" style='height:12.75pt'>
      <td height="17" class="xl245" style='height:12.75pt'>MUNIC&Iacute;PIO DE S&Atilde;O PAULO</td>
      <td class="xl33" x:num="381697" x:fmla="=SUM(B7:B66)"><span
  style='mso-spacerun:yes'>&nbsp;</span>381.697 </td>
      <td class="xl33" x:num="325540" x:fmla="=SUM(C7:C66)"><span
  style='mso-spacerun:yes'>&nbsp;</span>325.540 </td>
      <td class="xl33" x:num="240461" x:fmla="=SUM(D7:D66)"><span
  style='mso-spacerun:yes'>&nbsp;</span>240.461 </td>
      <td class="xl34" x:num="195641.04364233997" x:fmla="=SUM(E7:E66)"><span
  style='mso-spacerun:yes'>&nbsp;</span>195.641 </td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="ALEMANHA  ">ALEMANHA<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl35" x:num="12920"><div align="center">12.920 </div></td>
      <td align="center" class="xl35" x:num="9912"><div align="center">9.912 </div></td>
      <td align="center" class="xl35" x:num="6494"><div align="center">6.494 </div></td>
      <td align="center" class="xl36" x:num="4526.6651935200007"><div align="center">4.527 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="ANGOLA  ">ANGOLA<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="804"><div align="center">804 </div></td>
      <td align="center" class="xl36" x:num="1190.9712446899998"><div align="center">1.191 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="ARGENTINA  ">ARGENTINA<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl35" x:num="5248"><div align="center">5.248 </div></td>
      <td align="center" class="xl35" x:num="7934"><div align="center">7.934 </div></td>
      <td align="center" class="xl35" x:num="6817"><div align="center">6.817 </div></td>
      <td align="center" class="xl36" x:num="5183.1606266899998"><div align="center">5.183 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="AUSTR&Aacute;LIA ">AUSTR&Aacute;LIA<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="68"><div align="center">68 </div></td>
      <td align="center" class="xl36" x:num="75.871965979999999"><div align="center">76 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="&Aacute;USTRIA  ">&Aacute;USTRIA<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl35" x:num="2919"><div align="center">2.919 </div></td>
      <td align="center" class="xl35"><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="1312"><div align="center">1.312 </div></td>
      <td align="center" class="xl36" x:num="880.37124714000015"><div align="center">880 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="B&Eacute;LGICA ">B&Eacute;LGICA<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="343"><div align="center">343 </div></td>
      <td align="center" class="xl36" x:num="258.65240722999999"><div align="center">259 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="BOL&Iacute;VIA ">BOL&Iacute;VIA<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35"><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="3213"><div align="center">3.213 </div></td>
      <td align="center" class="xl35" x:num="4525"><div align="center">4.525 </div></td>
      <td align="center" class="xl36" x:num="7722.4465952900018"><div align="center">7.722 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="BULG&Aacute;RIA  ">BULG&Aacute;RIA<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="181"><div align="center">181 </div></td>
      <td align="center" class="xl36" x:num="142.96093622000001"><div align="center">143 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="CANAD&Aacute; ">CANAD&Aacute;<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="247"><div align="center">247 </div></td>
      <td align="center" class="xl36" x:num="282.02008876999992"><div align="center">282 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="CHILE ">CHILE<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="7020"><div align="center">7.020 </div></td>
      <td align="center" class="xl36" x:num="5188.787877480001"><div align="center">5.189 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="CHINA  ">CHINA<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="4355"><div align="center">4.355 </div></td>
      <td align="center" class="xl36" x:num="4799.134057010001"><div align="center">4.799 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="COLOMBIA ">COLOMBIA<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="538"><div align="center">538 </div></td>
      <td align="center" class="xl36" x:num="649.53620379999995"><div align="center">650 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt'
  x:str="COR&Eacute;IA DO NORTE, COR&Eacute;IA DO SUL ">COR&Eacute;IA DO NORTE, COR&Eacute;IA DO SUL<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="7242"><div align="center">7.242 </div></td>
      <td align="center" class="xl36" x:num="7028.7828428100001"><div align="center">7.029 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="COSTA RICA ">COSTA
        RICA<span style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="118"><div align="center">118 </div></td>
      <td align="center" class="xl36" x:num="29.867017130000001"><div align="center">30 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="CUBA ">CUBA<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="151"><div align="center">151 </div></td>
      <td align="center" class="xl36" x:num="258.51212673000003"><div align="center">259 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="DINAMARCA  ">DINAMARCA<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'>-</td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="107"><div align="center">107 </div></td>
      <td align="center" class="xl36" x:num="129.50013607"><div align="center">130 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="EGITO ">EGITO<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="2440"><div align="center">2.440 </div></td>
      <td align="center" class="xl36" x:num="2125.5714374800004"><div align="center">2.126 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="EL SALVADOR  ">EL
        SALVADOR<span style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="66"><div align="center">66 </div></td>
      <td align="center" class="xl36" x:num="78.504521939999989"><div align="center">79 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="EQUADOR ">EQUADOR<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="188"><div align="center">188 </div></td>
      <td align="center" class="xl36" x:num="207.18676341999998"><div align="center">207 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="ESPANHA  ">ESPANHA<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl35" x:num="46563"><div align="center">46.563 </div></td>
      <td align="center" class="xl35" x:num="31702"><div align="center">31.702 </div></td>
      <td align="center" class="xl35" x:num="18620"><div align="center">18.620 </div></td>
      <td align="center" class="xl36" x:num="13782.170013089999"><div align="center">13.782 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="ESTADOS UNIDOS ">ESTADOS
        UNIDOS<span style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" x:num="3380"><div align="center">3.380 </div></td>
      <td align="center" class="xl35" x:num="3333"><div align="center">3.333 </div></td>
      <td align="center" class="xl35" x:num="2910"><div align="center">2.910 </div></td>
      <td align="center" class="xl36" x:num="2550.5046389000008"><div align="center">2.551 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="FINL&Acirc;NDIA  ">FINL&Acirc;NDIA<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="45"><div align="center">45 </div></td>
      <td align="center" class="xl36" x:num="64.334316749999999"><div align="center"><span
  style='mso-spacerun:yes'>6</span>4 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="FRAN&Ccedil;A  ">FRAN&Ccedil;A<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="2174"><div align="center">2.174 </div></td>
      <td align="center" class="xl36" x:num="2595.0893153700003"><div align="center">2.595 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="GR&Atilde;-BRETANHA  ">GR&Atilde;-BRETANHA<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="847"><div align="center">847 </div></td>
      <td align="center" class="xl36" x:num="736.03409549000003"><div align="center">736 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="GR&Eacute;CIA  ">GR&Eacute;CIA<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="1464"><div align="center">1.464 </div></td>
      <td align="center" class="xl36" x:num="1234.7324592600005"><div align="center">1.235 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="GUATEMALA ">GUATEMALA<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="15"><div align="center">15 </div></td>
      <td align="center" class="xl36" x:num="23.969400450000002"><div align="center">24 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="GUIANA ">GUIANA<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="60"><div align="center">60 </div></td>
      <td align="center" class="xl36" x:num="25.123351919999998"><div align="center">25 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="HOLANDA  ">HOLANDA<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="365"><div align="center">365 </div></td>
      <td align="center" class="xl36" x:num="520.6756051000001"><div align="center">521 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="HUNGRIA ">HUNGRIA<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="2305"><div align="center">2.305 </div></td>
      <td align="center" class="xl36" x:num="1375.1272126900003"><div align="center">1.375 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="&Iacute;NDIA  ">&Iacute;NDIA<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="225"><div align="center">225 </div></td>
      <td align="center" class="xl36" x:num="182.35426029999999"><div align="center"><span
  style='mso-spacerun:yes'>1</span>82 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt'>IRLANDA</td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="25"><div align="center"><span style='mso-spacerun:yes'>&nbsp;</span>25 </div></td>
      <td align="center" class="xl36" x:num="91.278674710000004"><div align="center">91 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="ISRAEL ">ISRAEL<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="1237"><div align="center">1.237 </div></td>
      <td align="center" class="xl36" x:num="898.26151419000007"><div align="center">898 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="IT&Aacute;LIA ">IT&Aacute;LIA<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" x:num="56698"><div align="center">56.698 </div></td>
      <td align="center" class="xl35" x:num="38925"><div align="center">38.925 </div></td>
      <td align="center" class="xl35" x:num="25112"><div align="center">25.112 </div></td>
      <td align="center" class="xl36" x:num="19785.877544889991"><div align="center"><span style='mso-spacerun:yes'>1</span>9.786 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt'
  x:str="IUGOSL&Aacute;VIA, B&Oacute;SNIA HERZEGOVINA, CRO&Aacute;CIA, ESLOV&Ecirc;NIA, MACED&Ocirc;NIA ">IUGOSL&Aacute;VIA,
        B&Oacute;SNIA HERZEGOVINA, CRO&Aacute;CIA, ESLOV&Ecirc;NIA, MACED&Ocirc;NIA<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="2437"><div align="center">2.437 </div></td>
      <td align="center" class="xl36" x:num="1510.3984930500008"><div align="center">1.510 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="JAMAICA ">JAMAICA<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl36" x:num="8.29943293"><div align="center">8 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="JAP&Atilde;O  ">JAP&Atilde;O<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl35" x:num="45731"><div align="center">45.731 </div></td>
      <td align="center" class="xl35" x:num="44103"><div align="center">44.103 </div></td>
      <td align="center" class="xl35" x:num="27941"><div align="center">27.941 </div></td>
      <td align="center" class="xl36" x:num="22005.474178370001"><div align="center">22.005 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="L&Iacute;BANO ">L&Iacute;BANO<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" x:num="6769"><div align="center">6.769 </div></td>
      <td align="center" class="xl35" x:num="5427"><div align="center">5.427 </div></td>
      <td align="center" class="xl35" x:num="5457"><div align="center">5.457 </div></td>
      <td align="center" class="xl36" x:num="4614.6987677500001"><div align="center">4.615 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="M&Eacute;XICO  ">M&Eacute;XICO<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="163"><div align="center">163 </div></td>
      <td align="center" class="xl36" x:num="279.61866303000005"><div align="center">280 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="MO&Ccedil;AMBIQUE  ">MO&Ccedil;AMBIQUE<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="199"><div align="center">199 </div></td>
      <td align="center" class="xl36" x:num="245.57649903000004"><div align="center">246 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="NICARAGU&Aacute; ">NICARAGU&Aacute;<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="25"><div align="center">25 </div></td>
      <td align="center" class="xl36" x:num="22.951417820000003"><div align="center">23 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="NORUEGA  ">NORUEGA<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="26"><div align="center">26 </div></td>
      <td align="center" class="xl36" x:num="10.66435821"><div align="center">11 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="PANAM&Aacute; ">PANAM&Aacute;<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="165"><div align="center">165 </div></td>
      <td align="center" class="xl36" x:num="68.293471109999999"><div align="center">68 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="PAQUIST&Atilde;O ">PAQUIST&Atilde;O<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl36" x:num="6.8514718500000003"><div align="center">7 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="PARAGUAI ">PARAGUAI<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35"><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="1607"><div align="center">1.607 </div></td>
      <td align="center" class="xl35" x:num="1435"><div align="center">1.435 </div></td>
      <td align="center" class="xl36" x:num="1419.5557572100001"><div align="center">1.420 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="PERU ">PERU<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="1104"><div align="center">1.104 </div></td>
      <td align="center" class="xl36" x:num="1834.1004659099997"><div align="center">1.834 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="POL&Ocirc;NIA ">POL&Ocirc;NIA<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" x:num="4996"><div align="center">4.996 </div></td>
      <td align="center" class="xl35" x:num="3358"><div align="center">3.358 </div></td>
      <td align="center" class="xl35" x:num="3704"><div align="center">3.704 </div></td>
      <td align="center" class="xl36" x:num="2158.59594354"><div align="center">2.159 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="PORTUGAL ">PORTUGAL<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" x:num="136497"><div align="center">136.497 </div></td>
      <td align="center" class="xl35" x:num="115179"><div align="center">115.179 </div></td>
      <td align="center" class="xl35" x:num="79611"><div align="center">79.611 </div></td>
      <td align="center" class="xl36" x:num="63274.495759690006"><div align="center">63.274 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="REP&Uacute;BLICA DOMINICANA ">REP&Uacute;BLICA
        DOMINICANA<span style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'>-</td>
      <td align="center" class="xl35" x:num="111"><div align="center">111 </div></td>
      <td align="center" class="xl36" x:num="23.716836639999997"><div align="center">24 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt'>REP&Uacute;BLICA TCHECA, ESLOV&Aacute;QUIA</td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'>-</td>
      <td align="center" class="xl35" x:num="574"><div align="center"><span style='mso-spacerun:yes'>5</span>74 </div></td>
      <td align="center" class="xl36" x:num="431.95749778999999"><div align="center">432 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="ROM&Ecirc;NIA  ">ROM&Ecirc;NIA<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl35" x:num="5193"><div align="center">5.193 </div></td>
      <td align="center" class="xl35" x:num="3419"><div align="center">3.419 </div></td>
      <td align="center" class="xl35" x:num="3029"><div align="center">3.029 </div></td>
      <td align="center" class="xl36" x:num="1728.9152616999997"><div align="center">1.729 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt'>R&Uacute;SSIA, GE&Oacute;RGIA, LET&Ocirc;NIA,
        LITU&Acirc;NIA, USBEQUIST&Atilde;O, TAJIQUIST&Atilde;O, TURCOM<span style='display:none'>ENIST&Atilde;O,
          UCR&Acirc;NIA,</span></td>
      <td align="center" class="xl35" x:num="10688"><div align="center">10.688 </div></td>
      <td align="center" class="xl35" x:num="5945"><div align="center">5.945 </div></td>
      <td align="center" class="xl35" x:num="4308"><div align="center">4.308 </div></td>
      <td align="center" class="xl36" x:num="2363.6344288700002"><div align="center">2.364 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="S&Iacute;RIA ">S&Iacute;RIA<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" x:num="3648"><div align="center">3.648 </div></td>
      <td align="center" class="xl35" x:num="1950"><div align="center">1.950 </div></td>
      <td align="center" class="xl35" x:num="1865"><div align="center">1.865 </div></td>
      <td align="center" class="xl36" x:num="1069.55979245"><div align="center">1.070 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="SU&Eacute;CIA ">SU&Eacute;CIA<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="165"><div align="center">165 </div></td>
      <td align="center" class="xl36" x:num="211.29961792"><div align="center">211 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="SU&Iacute;&Ccedil;A  ">SU&Iacute;&Ccedil;A<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="866"><div align="center">866 </div></td>
      <td align="center" class="xl36" x:num="698.32408085999987"><div align="center">698 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="TAIWAN  ">TAIWAN<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="1431"><div align="center">1.431 </div></td>
      <td align="center" class="xl36" x:num="1820.4528903800001"><div align="center">1.820 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="TURQUIA ">TURQUIA<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td align="center" class="xl35" x:num="645"><div align="center">645 </div></td>
      <td align="center" class="xl35"><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="364"><div align="center">364 </div></td>
      <td align="center" class="xl36" x:num="277.47330201"><div align="center">277 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="URUGUAI  ">URUGUAI<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl35" x:num="1426"><div align="center">1.426 </div></td>
      <td align="center" class="xl35" x:num="2715"><div align="center">2.715 </div></td>
      <td align="center" class="xl35" x:num="2309"><div align="center">2.309 </div></td>
      <td align="center" class="xl36" x:num="2276.9434173700001"><div align="center">2.277 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt' x:str="VENEZUELA  ">VENEZUELA<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" style='mso-ignore:colspan'><div align="center">-</div></td>
      <td align="center" class="xl35" x:num="284"><div align="center">284 </div></td>
      <td align="center" class="xl36" x:num="180.67802767000001"><div align="center">181 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl272" style='height:12.75pt'>OUTROS PA&Iacute;SES</td>
      <td align="center" class="xl35" x:num="37667"><div align="center">37.667 </div></td>
      <td align="center" class="xl35" x:num="44207"><div align="center">44.207 </div></td>
      <td align="center" class="xl35" x:num="2575"><div align="center">2.575 </div></td>
      <td align="center" class="xl36" x:num="2330"><div align="center">2.330 </div></td>
    </tr>
    <tr height="18" style='height:13.5pt'>
      <td height="18" class="xl39" style='height:13.5pt'
  x:str="PA&Iacute;S ESTRANGEIRO SEM ESPECIFICA&Ccedil;&Atilde;O  ">PA&Iacute;S ESTRANGEIRO SEM
        ESPECIFICA&Ccedil;&Atilde;O<span style='mso-spacerun:yes'>&nbsp;&nbsp;</span></td>
      <td align="center" class="xl40" x:num="709"><div align="center">709 </div></td>
      <td align="center" class="xl40" x:num="2611"><div align="center">2.611 </div></td>
      <td align="center" class="xl40" x:num="1893"><div align="center">1.893 </div></td>
      <td align="center" class="xl41" x:num="144.47811666999999"><div align="center">144 </div></td>
    </tr>
    <tr class="xl37" height="17" style='height:12.75pt'>
      <td height="17" class="xl37" style='height:12.75pt'>Fonte: IBGE, Censos
        Demogr&aacute;ficos</td>
      <td colspan="4" class="xl38" style='mso-ignore:colspan'></td>
    </tr>
    <![if supportMisalignedColumns]>
    <tr height="0" style='display:none'>
      <td width="521" style='width:376pt'></td>
      <td width="42" style='width:47pt'></td>
      <td width="62" style='width:47pt'></td>
      <td width="62" style='width:47pt'></td>
      <td width="65" style='width:47pt'></td>
    </tr>
    <![endif]>
  </table>
  <p>&nbsp;</p>
  <p><strong><img src="../img/seta-download.gif" width="11" height="12" /></strong><strong> </strong><a href="xls/est.xls" title="Clique para baixar a tabela no formato Excel (.xls)"><strong>FORMATO EXCEL (.XLS)</strong></a></p>
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">
</div>

</div>

<td><div id="assinatura">
<div style="text-align:center"><div>
</div></td>

</body>
</html>
