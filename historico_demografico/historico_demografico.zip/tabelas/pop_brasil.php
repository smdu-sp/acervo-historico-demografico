<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Hist&oacute;rico Demogr&aacute;fico do Munic&iacute;pio de S&atilde;o Paulo</title>
<link rel="stylesheet" type="text/css" href="../estilo_padrao.css">
<script language="JavaScript1.2" src="../funcoes.js"></script><style type="text/css">
<!--
.xl24 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl25 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl26 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl27 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl28 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl29 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl30 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl31 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl32 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl241 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl242 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl243 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl244 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl251 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl261 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl271 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl281 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl291 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl301 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl311 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl321 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl245 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl252 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl262 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl272 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl282 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl292 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl302 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl312 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl322 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl33 {mso-style-parent:style21;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl34 {mso-style-parent:style21;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl35 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl36 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl37 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl38 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl39 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl40 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl41 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl246 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl253 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl263 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl273 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl283 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl293 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl303 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl313 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl247 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl254 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl264 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl274 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl284 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl294 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl304 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl314 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl323 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl248 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl255 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl265 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl275 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:right;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl285 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl295 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl305 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl315 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.font6 {color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:italic;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl249 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl256 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl266 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl276 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl286 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl296 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl306 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:right;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl316 {mso-style-parent:style0;
	font-weight:700;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl324 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:Standard;
	text-align:center;}
.xl331 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl341 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;
	white-space:normal;}
.xl351 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:Standard;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl361 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;}
.font61 {color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:italic;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2410 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl257 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl267 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl277 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl287 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl297 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl307 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:right;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl317 {mso-style-parent:style0;
	font-weight:700;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl325 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:Standard;
	text-align:center;}
.xl332 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl342 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;
	white-space:normal;}
.xl352 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:Standard;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl362 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;}
.xl2411 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl258 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl268 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl278 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl288 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl298 {mso-style-parent:style19;
	color:black;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl308 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl318 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl326 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2412 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl259 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl269 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl279 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl289 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl299 {mso-style-parent:style19;
	color:black;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl309 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl319 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl327 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl333 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2413 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2510 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2610 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2710 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2810 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl2910 {mso-style-parent:style19;
	color:black;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl3010 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl3110 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl328 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl334 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2414 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2511 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2611 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2711 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2811 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl2911 {mso-style-parent:style19;
	color:black;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl3011 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:Fixed;
	text-align:center;}
.xl3111 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl329 {mso-style-parent:style19;
	color:black;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl335 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2415 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2512 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2612 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2712 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2812 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl2912 {mso-style-parent:style19;
	color:black;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:right;}
.xl3012 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3112 {mso-style-parent:style19;
	color:black;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:right;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3210 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.font9 {color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:italic;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2513 {mso-style-parent:style20;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2613 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2713 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2813 {mso-style-parent:style20;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;}
.xl2913 {mso-style-parent:style20;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:right;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3013 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl3113 {mso-style-parent:style22;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl3211 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"0\.0";
	text-align:center;}
.xl336 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-left:none;}
.xl343 {mso-style-parent:style22;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;

	border-left:none;}
.xl353 {mso-style-parent:style20;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl363 {mso-style-parent:style20;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl371 {mso-style-parent:style20;
	color:black;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;}
.xl381 {mso-style-parent:style20;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	mso-protection:unlocked visible;}
.xl401 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;}
.xl411 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;
	vertical-align:middle;}
.style1 {mso-style-parent: style20; font-family: Arial, sans-serif; mso-font-charset: 0; text-align: left; vertical-align: middle; font-weight: bold; }
.style2 {mso-style-parent: style20; font-family: Arial, sans-serif; mso-font-charset: 0; text-align: center; vertical-align: middle; font-weight: bold; }
.style3 {mso-style-parent: style20; font-family: Arial, sans-serif; mso-font-charset: 0; text-align: center; vertical-align: middle; font-weight: bold; }
-->
</style>
</head>

<body>

<div id="geral">

<table align="center" border="0" cellpadding="0" cellspacing="0" width="780">

    <tr><td><div id="header_prefeitura">
</div></div>
</div></td></tr>

    <tr><td><table width="778" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td><div id="tarja_laranja"> <a href="../index.php" title="Voltar para a p&aacute;gina inicial">
		<h1 class="semestilo">Hist&oacute;ria Demogr&aacute;fica do Munic&iacute;pio de S&atilde;o Paulo</h1>
		</a> </div></td>
		<td align="right">
		
		<a href="../index.php"><img src="../img/botao_apresentacao_1.jpg" alt="P&aacute;gina Inicial" name="Image1" width="103" height="35" border="0" id="Image1" title="Página Inicial" onMouseOver="MM_swapImage('Image1','','../img/botao_apresentacao_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a><a href="../introducao.php"><img src="../img/botao_introducao_1.jpg" alt="Introdu&ccedil;&atilde;o" name="Image2" width="85" height="35" border="0" id="Image2" title="Introdu&ccedil;&atilde;o" onMouseOver="MM_swapImage('Image2','','../img/botao_introducao_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a><a href="../equipe.php"><img src="../img/botao_equipe_1.jpg" alt="Equipe T&eacute;cnica" name="Image3" width="108" height="35" border="0" id="Image3" title="Equipe T&eacute;cnica" onMouseOver="MM_swapImage('Image3','','../img/botao_equipe_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a><a href="../tabelas.php"><img src="../img/botao_dados_1.jpg" alt="Tabelas" name="Image4" width="76" height="35" border="0" id="Image4" title="Tabelas" onMouseOver="MM_swapImage('Image4','','../img/botao_dados_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a></td>
	</tr>
</table></td></tr>
	  
</table>

<div id="conteudo"> 
  <h1>Tabelas</h1>
  <p>&nbsp;</p>
  <table x:str="x:str" border="0" cellpadding="0" cellspacing="0" width="768" style='border-collapse:
 collapse;table-layout:fixed;width:577pt'>
    <col class="xl2613" width="41" style='mso-width-source:userset;mso-width-alt:1499;
 width:31pt' />
    <col class="xl2613" width="79" style='mso-width-source:userset;mso-width-alt:2889;
 width:59pt' />
    <col class="xl2613" width="101" style='mso-width-source:userset;mso-width-alt:3693;
 width:76pt' />
    <col class="xl2613" width="79" style='mso-width-source:userset;mso-width-alt:2889;
 width:59pt' />
    <col class="xl2613" width="101" style='mso-width-source:userset;mso-width-alt:3693;
 width:76pt' />
    <col class="xl2613" width="79" style='mso-width-source:userset;mso-width-alt:2889;
 width:59pt' />
    <col class="xl2613" width="101" style='mso-width-source:userset;mso-width-alt:3693;
 width:76pt' />
    <col class="xl2613" width="86" style='mso-width-source:userset;mso-width-alt:3145;
 width:65pt' />
    <col class="xl2613" width="101" style='mso-width-source:userset;mso-width-alt:3693;
 width:76pt' />
    <col class="xl2613" width="79" span="247" style='mso-width-source:userset;mso-width-alt:
 2889;width:59pt' />
    <tr height="17" style='height:12.75pt'>
      <td colspan="9" height="17" class="xl363" width="768" style='height:12.75pt;
  width:577pt'>Popula&ccedil;&atilde;o nos Anos de Levantamento Censit&aacute;rio</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td colspan="9" height="17" class="xl363" style='height:12.75pt'>Munic&iacute;pio e<span
  style='mso-spacerun:yes'>&nbsp; </span>Regi&atilde;o Metropolitana de S&atilde;o Paulo, Estado
        de S&atilde;o Paulo e Brasil</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td colspan="9" height="17" class="xl363" style='height:12.75pt'><p>1872 a 2010</p></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2513" style='height:12.75pt'></td>
      <td colspan="8" class="xl2613" style='mso-ignore:colspan'></td>
    </tr>
    <tr height="18" style='height:13.5pt'>
      <td height="18" class="xl2713" style='height:13.5pt'>&nbsp;</td>
      <td class="xl2713">&nbsp;</td>
      <td class="xl2713">&nbsp;</td>
      <td class="xl2713">&nbsp;</td>
      <td class="xl2713">&nbsp;</td>
      <td class="xl2713">&nbsp;</td>
      <td class="xl2713">&nbsp;</td>
      <td class="xl2713">&nbsp;</td>
      <td class="xl2713">&nbsp;</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td rowspan="4" height="71" class="xl381" style='border-bottom:1.0pt solid black;
  height:53.25pt'>Anos</td>
      <td colspan="2" rowspan="2" class="xl401"><strong>Munic&iacute;pio de S&atilde;o Paulo</strong></td>
      <td colspan="2" rowspan="2" align="center" class="style1">Regi&atilde;o Metropolitana<span
  style='mso-spacerun:yes'>&nbsp; </span>de SP</td>
      <td colspan="2" rowspan="2" class="style2" x:str="Estado de S&atilde;o Paulo ">Estado de S&atilde;o
        Paulo<span style='mso-spacerun:yes'>&nbsp;</span></td>
      <td colspan="2" rowspan="2" class="style3">Brasil</td>
    </tr>
    <tr height="17" style='height:12.75pt'> </tr>
    <tr height="17" style='height:12.75pt'>
      <td rowspan="2" height="37" class="xl2813" style='border-bottom:1.0pt solid black;
  height:27.75pt' x:str="Popula&ccedil;&atilde;o ">Popula&ccedil;&atilde;o<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td class="xl2813">Taxa de</td>
      <td rowspan="2" class="xl2813" style='border-bottom:1.0pt solid black'
  x:str="Popula&ccedil;&atilde;o ">Popula&ccedil;&atilde;o<span style='mso-spacerun:yes'>&nbsp;</span></td>
      <td class="xl2813">Taxa de</td>
      <td rowspan="2" class="xl2813" style='border-bottom:1.0pt solid black'
  x:str="Popula&ccedil;&atilde;o ">Popula&ccedil;&atilde;o<span style='mso-spacerun:yes'>&nbsp;</span></td>
      <td class="xl2813">Taxa de</td>
      <td rowspan="2" class="xl2813" style='border-bottom:1.0pt solid black'
  x:str="Popula&ccedil;&atilde;o ">Popula&ccedil;&atilde;o<span style='mso-spacerun:yes'>&nbsp;</span></td>
      <td class="xl2813">Taxa de</td>
    </tr>
    <tr height="20" style='height:15.0pt'>
      <td height="20" class="xl2913" style='height:15.0pt'>Crescimento<font class="font9"><sup> (1)</sup></font></td>
      <td class="xl2913">Crescimento<font class="font9"><sup> (1)</sup></font></td>
      <td class="xl2913">Crescimento<font class="font9"><sup> (1)</sup></font></td>
      <td class="xl2913">Crescimento<font class="font9"><sup> (1)</sup></font></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3013" style='height:12.75pt' x:num="x:num">1872</td>
      <td class="xl3113" x:num="31385"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>31.385 </td>
      <td class="xl3013"></td>
      <td class="xl3013">-</td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="837354"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>837.354 </td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="10112061"><span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>10.112.061 </td>
      <td class="xl3013"></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" colspan="2" class="xl3013" style='height:12.75pt;mso-ignore:colspan'></td>
      <td class="xl3211" x:num="4.1218001530072712" x:fmla="=+((B12/B10)^(1/18)-1)*100">4,1</td>
      <td class="xl3013"></td>
      <td class="xl3013">-</td>
      <td class="xl3113"></td>
      <td class="xl3211" x:num="2.8340274996186965" x:fmla="=+((F12/F10)^(1/18)-1)*100">2,8</td>
      <td class="xl3113"></td>
      <td class="xl3211" x:num="2">2,0</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3013" style='height:12.75pt' x:num="x:num">1890</td>
      <td class="xl3113" x:num="64934"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>64.934 </td>
      <td class="xl3013"></td>
      <td class="xl3013">-</td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="1384753"><span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>1.384.753 </td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="14333915"><span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>14.333.915 </td>
      <td class="xl3013"></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3013" style='height:12.75pt'></td>
      <td class="xl3113"></td>
      <td class="xl3211" x:num="13.957083072807542" x:fmla="=+((B14/B12)^(1/10)-1)*100">14,0</td>
      <td class="xl3013"></td>
      <td class="xl3013">-</td>
      <td class="xl3113"></td>
      <td class="xl3013" x:num="5.1">5,1</td>
      <td class="xl3113"></td>
      <td class="xl3013" x:num="1.9">1,9</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3013" style='height:12.75pt' x:num="x:num">1900</td>
      <td class="xl3113" x:num="239820"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>239.820 </td>
      <td class="xl3013"></td>
      <td class="xl3013">-</td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="2282279"><span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>2.282.279 </td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="17318556"><span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>17.318.556 </td>
      <td class="xl3013"></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3013" style='height:12.75pt'></td>
      <td class="xl3113"></td>
      <td class="xl3013" x:num="4.5">4,5</td>
      <td class="xl3013"></td>
      <td class="xl3013">-</td>
      <td class="xl3113"></td>
      <td class="xl3013" x:num="3.6">3,6</td>
      <td class="xl3113"></td>
      <td class="xl3013" x:num="2.9">2,9</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3013" style='height:12.75pt' x:num="x:num">1920</td>
      <td class="xl3113" x:num="579033"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>579.033 </td>
      <td class="xl3013"></td>
      <td class="xl3013">-</td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="4592188"><span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>4.592.188 </td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="30635605"><span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>30.635.605 </td>
      <td class="xl3013"></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3013" style='height:12.75pt'></td>
      <td class="xl3113"></td>
      <td class="xl3013" x:num="4.2">4,2</td>
      <td class="xl3013"></td>
      <td class="xl3013">-</td>
      <td class="xl3113"></td>
      <td class="xl3013" x:num="2.3">2,3</td>
      <td class="xl3113"></td>
      <td class="xl3013" x:num="1.5">1,5</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3013" style='height:12.75pt' x:num="x:num">1940</td>
      <td class="xl3113" x:num="1326261"><span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>1.326.261 </td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="1568045"><span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>1.568.045 </td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="7180316"><span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>7.180.316 </td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="41236315"><span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>41.236.315 </td>
      <td class="xl3013"></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3013" style='height:12.75pt'></td>
      <td class="xl3113"></td>
      <td class="xl3211" x:num="5.1820826308122125" x:fmla="=+((B20/B18)^(1/10)-1)*100">5,2</td>
      <td class="xl3113"></td>
      <td class="xl3211" x:num="5.2786805887838906" x:fmla="=+((D20/D18)^(1/10)-1)*100">5,3</td>
      <td class="xl3113"></td>
      <td class="xl3013" x:num="2.4">2,4</td>
      <td class="xl3113"></td>
      <td class="xl3013" x:num="2.3">2,3</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3013" style='height:12.75pt' x:num="x:num">1950</td>
      <td class="xl3113" x:num="2198096"><span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>2.198.096 </td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="2622786"><span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>2.622.786 </td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="9134423"><span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>9.134.423 </td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="51944397"><span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>51.944.397 </td>
      <td class="xl3013"></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3013" style='height:12.75pt'></td>
      <td class="xl3113"></td>
      <td class="xl3211" x:num="5.5750084116717336" x:fmla="=+((B22/B20)^(1/10)-1)*100">5,6</td>
      <td class="xl3113"></td>
      <td class="xl3211" x:num="6.0952903626007027" x:fmla="=+((D22/D20)^(1/10)-1)*100">6,1</td>
      <td class="xl3113"></td>
      <td class="xl3013" x:num="3.6">3,6</td>
      <td class="xl3113"></td>
      <td class="xl3013" x:num="3.1">3,1</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3013" style='height:12.75pt' x:num="x:num">1960</td>
      <td class="xl3113" x:num="3781446"><span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>3.781.446 </td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="4739406"><span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>4.739.406 </td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="12974699"><span
  style='mso-spacerun:yes'>&nbsp;</span>12.974.699 </td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="70119071"><span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>70.119.071 </td>
      <td class="xl3013"></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3013" style='height:12.75pt'></td>
      <td class="xl3113"></td>
      <td class="xl3211" x:num="4.5924227723848521" x:fmla="=+((B24/B22)^(1/10)-1)*100">4,6</td>
      <td class="xl3113"></td>
      <td class="xl3211" x:num="5.5573815328864962" x:fmla="=+((D24/D22)^(1/10)-1)*100">5,6</td>
      <td class="xl3113"></td>
      <td class="xl3211" x:num="3.1962163259916965" x:fmla="=+((F24/F22)^(1/10)-1)*100">3,2</td>
      <td class="xl3113"></td>
      <td class="xl3013" x:num="2.9">2,9</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3013" style='height:12.75pt' x:num="x:num">1970</td>
      <td class="xl3113" x:num="5924615"><span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>5.924.615 </td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="8139730"><span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>8.139.730 </td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="17771948"><span
  style='mso-spacerun:yes'>&nbsp;</span>17.771.948 </td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="93139037"><span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>93.139.037 </td>
      <td class="xl3013"></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3013" style='height:12.75pt'></td>
      <td class="xl3113"></td>
      <td class="xl3211" x:num="3.667172803359553" x:fmla="=+((B26/B24)^(1/10)-1)*100">3,7</td>
      <td class="xl3113"></td>
      <td class="xl3211" x:num="4.4569100347737756" x:fmla="=+((D26/D24)^(1/10)-1)*100">4,5</td>
      <td class="xl3113"></td>
      <td class="xl3211" x:num="3.488278813072565" x:fmla="=+((F26/F24)^(1/10)-1)*100">3,5</td>
      <td class="xl3113"></td>
      <td class="xl3211" x:num="2.4808005576036907" x:fmla="=+((H26/H24)^(1/10)-1)*100">2,5</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3013" style='height:12.75pt' x:num="x:num">1980</td>
      <td class="xl3113" x:num="8493226"><span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>8.493.226 </td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="12588725"><span
  style='mso-spacerun:yes'>&nbsp;</span>12.588.725 </td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="25040712"><span
  style='mso-spacerun:yes'>&nbsp;</span>25.040.712 </td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="119002706"><span
  style='mso-spacerun:yes'>&nbsp;</span>119.002.706 </td>
      <td class="xl3013"></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3013" style='height:12.75pt'></td>
      <td class="xl3113"></td>
      <td class="xl3211" x:num="1.1639361372562496" x:fmla="=+((B28/B26)^(1/11)-1)*100">1,2</td>
      <td class="xl3113"></td>
      <td class="xl3211" x:num="1.8762937556663362" x:fmla="=+((D28/D26)^(1/11)-1)*100">1,9</td>
      <td class="xl3113"></td>
      <td class="xl3211" x:num="2.1343083290975118" x:fmla="=+((F28/F26)^(1/11)-1)*100">2,1</td>
      <td class="xl3113"></td>
      <td class="xl3211" x:num="1.9283424007966454" x:fmla="=+((H28/H26)^(1/11)-1)*100">1,9</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3013" style='height:12.75pt' x:num="x:num">1991</td>
      <td class="xl3113" x:num="9646185"><span style='mso-spacerun:yes'>&nbsp;&nbsp; </span>9.646.185 </td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="15444941"><span
  style='mso-spacerun:yes'>&nbsp;</span>15.444.941 </td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="31588925"><span
  style='mso-spacerun:yes'>&nbsp;</span>31.588.925 </td>
      <td class="xl3013"></td>
      <td class="xl3113" x:num="146825475"><span
  style='mso-spacerun:yes'>&nbsp;</span>146.825.475 </td>
      <td class="xl3013"></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3013" style='height:12.75pt'></td>
      <td class="xl3113"></td>
      <td class="xl3211" x:num="0.87638861338827923" x:fmla="=+((B30/B28)^(1/9)-1)*100">0,9</td>
      <td class="xl3013"></td>
      <td class="xl3211" x:num="1.6391639515658918" x:fmla="=+((D30/D28)^(1/9)-1)*100">1,6</td>
      <td class="xl3013"></td>
      <td class="xl3211" x:num="1.7822141362251243" x:fmla="=+((F30/F28)^(1/9)-1)*100">1,8</td>
      <td class="xl3013"></td>
      <td class="xl3211" x:num="1.6283572067882002" x:fmla="=+((H30/H28)^(1/9)-1)*100">1,6</td>
    </tr>
    <tr height="18" style='height:13.5pt'>
      <td height="18" class="xl336" style='height:13.5pt' x:num="x:num">2000</td>
      <td class="xl343" x:num="10434252"><span
  style='mso-spacerun:yes'>&nbsp;</span>10.434.252 </td>
      <td class="xl336">&nbsp;</td>
      <td class="xl343" x:num="17878703"><span
  style='mso-spacerun:yes'>&nbsp;</span>17.878.703 </td>
      <td class="xl336">&nbsp;</td>
      <td class="xl343" x:num="37032403"><span
  style='mso-spacerun:yes'>&nbsp;</span>37.032.403 </td>
      <td class="xl336">&nbsp;</td>
      <td class="xl343" x:num="169799170"><span
  style='mso-spacerun:yes'>&nbsp;</span>169.799.170 </td>
      <td class="xl336">&nbsp;</td>
    </tr>
        <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3013" style='height:12.75pt'></td>
      <td class="xl3113"></td>
      <td class="xl3211" x:num="0.87638861338827923" x:fmla="=+((B30/B28)^(1/9)-1)*100">0,8</td>
      <td class="xl3013"></td>
      <td class="xl3211" x:num="1.6391639515658918" x:fmla="=+((D30/D28)^(1/9)-1)*100">1,0</td>
      <td class="xl3013"></td>
      <td class="xl3211" x:num="1.7822141362251243" x:fmla="=+((F30/F28)^(1/9)-1)*100">1,1</td>
      <td class="xl3013"></td>
      <td class="xl3211" x:num="1.6283572067882002" x:fmla="=+((H30/H28)^(1/9)-1)*100">1,2</td>
    </tr>
    <tr height="18" style='height:13.5pt'>
      <td height="18" class="xl336" style='height:13.5pt' x:num="x:num">2010</td>
      <td class="xl343" x:num="10434252"><span
  style='mso-spacerun:yes'>&nbsp;</span>11.253.503 </td>
      <td class="xl336">&nbsp;</td>
      <td class="xl343" x:num="17878703"><span
  style='mso-spacerun:yes'>&nbsp;</span>19.683.975 </td>
      <td class="xl336">&nbsp;</td>
      <td class="xl343" x:num="37032403"><span
  style='mso-spacerun:yes'>&nbsp;</span>41.262.799 </td>
      <td class="xl336">&nbsp;</td>
      <td class="xl343" x:num="169799170"><span
  style='mso-spacerun:yes'>&nbsp;</span>190.755.799 </td>
      <td class="xl336">&nbsp;</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td colspan="9" height="17" class="xl371" style='height:12.75pt'>Fonte: IBGE, Censos
        Demogr&aacute;ficos</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td colspan="9" height="17" class="xl353" style='height:12.75pt'>(1) Taxa de
        Crescimento Geom&eacute;trico Anual</td>
    </tr>
    <![if supportMisalignedColumns]>
    <tr height="0" style='display:none'>
      <td width="41" style='width:31pt'></td>
      <td width="79" style='width:59pt'></td>
      <td width="101" style='width:76pt'></td>
      <td width="79" style='width:59pt'></td>
      <td width="101" style='width:76pt'></td>
      <td width="79" style='width:59pt'></td>
      <td width="101" style='width:76pt'></td>
      <td width="86" style='width:65pt'></td>
      <td width="101" style='width:76pt'></td>
    </tr>
    <![endif]>
  </table>
  <p>&nbsp;</p>
  <p><strong><img src="../img/seta-download.gif" width="11" height="12" /></strong><strong> </strong><a href="xls/pop_brasil.xls" title="Clique para baixar a tabela no formato Excel (.xls)"><strong>FORMATO EXCEL (.XLS)</strong></a></p>
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">
</div>

</div>

<td><div id="assinatura">
<div style="text-align:center"><div>
</div></td>

</body>
</html>
