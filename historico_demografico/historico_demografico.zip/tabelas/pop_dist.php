<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Hist&oacute;rico Demogr&aacute;fico do Munic&iacute;pio de S&atilde;o Paulo</title>
<link rel="stylesheet" type="text/css" href="../estilo_padrao.css" />
<script language="JavaScript1.2" src="../funcoes.js" type="text/javascript"></script>
<style type="text/css">
<!--
.xl24 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl25 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl26 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl27 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl28 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl29 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl30 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl31 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl32 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl241 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl242 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl243 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl244 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl251 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl261 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl271 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl281 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl291 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl301 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl311 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl321 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl245 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl252 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl262 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl272 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl282 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl292 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl302 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl312 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl322 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl33 {mso-style-parent:style21;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl34 {mso-style-parent:style21;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl35 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl36 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl37 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl38 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl39 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl40 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl41 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl246 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl253 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl263 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl273 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl283 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl293 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl303 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl313 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl247 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl254 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl264 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl274 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl284 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl294 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl304 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl314 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl323 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl248 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl255 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl265 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl275 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:right;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl285 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl295 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl305 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl315 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.font6 {color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:italic;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl249 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl256 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl266 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl276 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl286 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl296 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl306 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:right;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl316 {mso-style-parent:style0;
	font-weight:700;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl324 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:Standard;
	text-align:center;}
.xl331 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl341 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;
	white-space:normal;}
.xl351 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:Standard;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl361 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;}
.font61 {color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:italic;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2410 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl257 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl267 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl277 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl287 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl297 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl307 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:right;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl317 {mso-style-parent:style0;
	font-weight:700;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl325 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:Standard;
	text-align:center;}
.xl332 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl342 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;
	white-space:normal;}
.xl352 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:Standard;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl362 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;}
.xl2411 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl258 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl268 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl278 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl288 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl298 {mso-style-parent:style19;
	color:black;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl308 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl318 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl326 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2412 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl259 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl269 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl279 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl289 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl299 {mso-style-parent:style19;
	color:black;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl309 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl319 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl327 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl333 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2413 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2510 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2610 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2710 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2810 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl2910 {mso-style-parent:style19;
	color:black;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl3010 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl3110 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl328 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl334 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2414 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2511 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2611 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2711 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2811 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl2911 {mso-style-parent:style19;
	color:black;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl3011 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:Fixed;
	text-align:center;}
.xl3111 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl329 {mso-style-parent:style19;
	color:black;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl335 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2415 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2512 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2612 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2712 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2812 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl2912 {mso-style-parent:style19;
	color:black;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:right;}
.xl3012 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3112 {mso-style-parent:style19;
	color:black;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:right;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3210 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.font9 {color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:italic;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2513 {mso-style-parent:style20;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2613 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2713 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2813 {mso-style-parent:style20;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;}
.xl2913 {mso-style-parent:style20;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:right;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3013 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl3113 {mso-style-parent:style22;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl3211 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"0\.0";
	text-align:center;}
.xl336 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl343 {mso-style-parent:style22;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl353 {mso-style-parent:style20;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl363 {mso-style-parent:style20;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl371 {mso-style-parent:style20;
	color:black;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;}
.xl381 {mso-style-parent:style20;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	mso-protection:unlocked visible;}
.xl401 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;}
.xl411 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;
	vertical-align:middle;}
.font7 {color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2416 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2514 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2614 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl2714 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl2814 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2914 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3014 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;}
.xl3114 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3212 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl337 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;}
.xl2417 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl2515 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2615 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl2715 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2815 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl2915 {mso-style-parent:style21;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl3015 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl3115 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl3213 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl338 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl344 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl354 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";}
.xl364 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;}
.xl372 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";}
.xl382 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl391 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;}
.xl402 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl412 {mso-style-parent:style0;
	color:black;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;}
.xl43 {mso-style-parent:style0;
	color:black;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;}
-->
</style>
</head>

<body>

<div id="geral">

<table align="center" border="0" cellpadding="0" cellspacing="0" width="780">

    <tr><td><div id="header_prefeitura">
</div></div>
</div></td></tr>

    <tr><td><table width="778" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td><div id="tarja_laranja"> <a href="../index.php" title="Voltar para a p&aacute;gina inicial">
		<h1 class="semestilo">Hist&oacute;ria Demogr&aacute;fica do Munic&iacute;pio de S&atilde;o Paulo</h1>
		</a> </div></td>
		<td align="right">
		
		<a href="../index.php"><img src="../img/botao_apresentacao_1.jpg" alt="P&aacute;gina Inicial" name="Image1" width="103" height="35" border="0" id="Image1" title="Página Inicial" onMouseOver="MM_swapImage('Image1','','../img/botao_apresentacao_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a><a href="../introducao.php"><img src="../img/botao_introducao_1.jpg" alt="Introdu&ccedil;&atilde;o" name="Image2" width="85" height="35" border="0" id="Image2" title="Introdu&ccedil;&atilde;o" onMouseOver="MM_swapImage('Image2','','../img/botao_introducao_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a><a href="../equipe.php"><img src="../img/botao_equipe_1.jpg" alt="Equipe T&eacute;cnica" name="Image3" width="108" height="35" border="0" id="Image3" title="Equipe T&eacute;cnica" onMouseOver="MM_swapImage('Image3','','../img/botao_equipe_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a><a href="../tabelas.php"><img src="../img/botao_dados_1.jpg" alt="Tabelas" name="Image4" width="76" height="35" border="0" id="Image4" title="Tabelas" onMouseOver="MM_swapImage('Image4','','../img/botao_dados_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a></td>
	</tr>
</table></td></tr>
	  
</table>

<div id="conteudo"> 
  <h1>Tabelas</h1>
  <p>&nbsp;</p>
  <table x:str="x:str" border="0" cellpadding="0" cellspacing="0" width="612" style='border-collapse:
 collapse;table-layout:fixed;width:459pt'>
    <col class="xl2615" width="189" style='mso-width-source:userset;mso-width-alt:6912;
 width:142pt' />
    <col class="xl2417" width="72" style='mso-width-source:userset;mso-width-alt:2633;
 width:54pt' />
    <col class="xl3115" width="72" span="3" style='mso-width-source:userset;mso-width-alt:
 2633;width:54pt' />
    <col class="xl3015" width="64" style='width:48pt' />
    <col class="xl3015" width="71" style='mso-width-source:userset;mso-width-alt:2596;
 width:53pt' />
    <tr height="17" style='height:12.75pt'>
      <td colspan="8" height="17" class="xl2815" width="612" style='height:12.75pt;
  width:459pt'>Popula&ccedil;&atilde;o nos Anos de Levantamento Censit&aacute;rio</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td colspan="8" height="17" class="xl2815" style='height:12.75pt'>Munic&iacute;pio de S&atilde;o
        Paulo, Subprefeituras e Distritos Municipais</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td colspan="8" height="17" class="xl2815" style='height:12.75pt'>1950, 1960, 1970,
        1980, 1991, 2000 e 2010</td>
    </tr>
    <tr height="18" style='height:13.5pt'>
      <td height="18" class="xl344" style='height:13.5pt'>&nbsp;</td>
      <td class="xl2515">&nbsp;</td>
      <td class="xl338">&nbsp;</td>
      <td class="xl338">&nbsp;</td>
      <td class="xl338">&nbsp;</td>
      <td class="xl3213">&nbsp;</td>
      <td class="xl3213">&nbsp;</td>
      <td class="xl3213">&nbsp;</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td rowspan="2" height="35" class="xl412" style='border-bottom:1.0pt solid black;
  height:26.25pt;border-top:none'>Unidades Territoriais</td>
      <td colspan="7" class="xl43">Popula&ccedil;&atilde;o</td>
    </tr>
    <tr height="18" style='height:13.5pt'>
      <td height="18" class="xl2715" style='height:13.5pt' x:num="x:num">1950</td>
      <td class="xl2715" x:num="x:num">1960</td>
      <td class="xl2715" x:num="x:num">1970</td>
      <td class="xl2715" x:num="x:num">1980</td>
      <td class="xl2715" x:num="x:num">1991</td>
      <td class="xl2715" x:num="x:num">2000</td>
      <td class="xl2715" x:num="x:num">2010</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2815" style='height:12.75pt'>MSP</td>
      <td class="xl2915" x:num="2151313"><span
  style='mso-spacerun:yes'>&nbsp;</span>2.151.313 </td>
      <td class="xl2915" x:num="3667899"><span
  style='mso-spacerun:yes'>&nbsp;</span>3.667.899 </td>
      <td class="xl2915" x:num="5924615"><span
  style='mso-spacerun:yes'>&nbsp;</span>5.924.615 </td>
      <td class="xl2915" x:num="8493226"><span
  style='mso-spacerun:yes'>&nbsp;</span>8.493.226 </td>
      <td class="xl354" align="right" x:num="9646185">9.646.185</td>
      <td class="xl354" align="right" x:num="10434252">10.434.252</td>
      <td class="xl354" align="right" x:num="10434252">11.253.503</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Aricanduva/Formosa/Carr&atilde;o</td>
      <td class="xl2915" x:num="112431.07387954372"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>112.431 </td>
      <td class="xl2915" x:num="194577.85839949359"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>194.578 </td>
      <td class="xl2915" x:num="265532.90710639127"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>265.533 </td>
      <td class="xl2915" x:num="298115.66269357642"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>298.116 </td>
      <td class="xl354" align="right" x:num="281788">281.788</td>
      <td class="xl354" align="right" x:num="266838">266.838</td>
      <td class="xl354" align="right" x:num="266838">267.702</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Aricanduva</td>
      <td class="xl3115" x:num="32317.746811202269"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>32.318 </td>
      <td class="xl3115" x:num="58075.602710458617"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>58.076 </td>
      <td class="xl3115" x:num="81577.395521274055"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>81.577 </td>
      <td class="xl3115" x:num="92790.124907955658"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>92.790 </td>
      <td class="xl3115" x:num="96512"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>96.512 </td>
      <td class="xl372" align="right" x:num="94813">94.813</td>
      <td class="xl372" align="right" x:num="94813">89.622</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Carr&atilde;o</td>
      <td class="xl3115" x:num="34556.342977846325"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>34.556 </td>
      <td class="xl3115" x:num="62098.402392709708"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>62.098 </td>
      <td class="xl3115" x:num="87228.125009489173"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>87.228 </td>
      <td class="xl3115" x:num="99217.541371574072"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>99.218 </td>
      <td class="xl3115" x:num="87336"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>87.336 </td>
      <td class="xl372" align="right" x:num="78175">78.175</td>
      <td class="xl372" align="right" x:num="78175">83.281</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Vila Formosa</td>
      <td class="xl3115" x:num="45556.98409049512"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>45.557 </td>
      <td class="xl3115" x:num="74403.853296325266"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>74.404 </td>
      <td class="xl3115" x:num="96727.386575628014"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>96.727 </td>
      <td class="xl3115" x:num="106107.99641404665"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>106.108 </td>
      <td class="xl3115" x:num="97940"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>97.940 </td>
      <td class="xl372" align="right" x:num="93850">93.850</td>
      <td class="xl372" align="right" x:num="93850">94.799</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Butant&atilde;</td>
      <td class="xl2915" x:num="24372.108713052436"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>24.372 </td>
      <td class="xl2915" x:num="60628.770620385767"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>60.629 </td>
      <td class="xl2915" x:num="156692.52467877802"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>156.693 </td>
      <td class="xl2915" x:num="285031.31497292483"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>285.031 </td>
      <td class="xl2915" x:num="366737"><span style='mso-spacerun:yes'>&nbsp; </span>366.737 </td>
      <td class="xl354" align="right" x:num="377576">377.576</td>
      <td class="xl354" align="right" x:num="377576">428.217</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Butant&atilde;</td>
      <td class="xl3115" x:num="5126.5292484986821"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>5.127 </td>
      <td class="xl3115" x:num="12329.442490577254"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>12.329 </td>
      <td class="xl3115" x:num="31531.947479137281"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>31.532 </td>
      <td class="xl3115" x:num="56933.700238937679"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>56.934 </td>
      <td class="xl3115" x:num="58019"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>58.019 </td>
      <td class="xl372" align="right" x:num="52649">52.649</td>
      <td class="xl372" align="right" x:num="52649">54.196</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Morumbi</td>
      <td class="xl3115" x:num="3120.8718331837395"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>3.121 </td>
      <td class="xl3115" x:num="8902.3989222054461"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>8.902 </td>
      <td class="xl3115" x:num="18724.452923780729"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>18.724 </td>
      <td class="xl3115" x:num="31076.703927555907"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>31.077 </td>
      <td class="xl3115" x:num="40031"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>40.031 </td>
      <td class="xl372" align="right" x:num="34588">34.588</td>
      <td class="xl372" align="right" x:num="34588">46.957</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Raposo Tavares</td>
      <td class="xl3115" x:num="4445.4406973171253"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>4.445 </td>
      <td class="xl3115" x:num="10691.405971963261"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>10.691 </td>
      <td class="xl3115" x:num="27342.749020786952"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>27.343 </td>
      <td class="xl3115" x:num="49369.734536313619"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>49.370 </td>
      <td class="xl3115" x:num="82890"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>82.890 </td>
      <td class="xl372" align="right" x:num="91204">91.204</td>
      <td class="xl372" align="right" x:num="91204">100.164</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Rio Pequeno</td>
      <td class="xl3115" x:num="7635.5558683409599"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>7.636 </td>
      <td class="xl3115" x:num="18363.719857810094"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>18.364 </td>
      <td class="xl3115" x:num="46964.317366384668"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>46.964 </td>
      <td class="xl3115" x:num="84798.199306693656"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>84.798 </td>
      <td class="xl3115" x:num="102791"><span style='mso-spacerun:yes'>&nbsp; </span>102.791 </td>
      <td class="xl372" align="right" x:num="111756">111.756</td>
      <td class="xl372" align="right" x:num="111756">118.459</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Vila S&ocirc;nia</td>
      <td class="xl3115" x:num="4043.7110657119297"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>4.044 </td>
      <td class="xl3115" x:num="10341.80337782971"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>10.342 </td>
      <td class="xl3115" x:num="32129.057888688374"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>32.129 </td>
      <td class="xl3115" x:num="62852.976963423935"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>62.853 </td>
      <td class="xl3115" x:num="83006"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>83.006 </td>
      <td class="xl372" align="right" x:num="87379">87.379</td>
      <td class="xl372" align="right" x:num="87379">108.441</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Campo Limpo</td>
      <td class="xl2915" x:num="12702.535236950494"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>12.703 </td>
      <td class="xl2915" x:num="34810.061837152403"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>34.810 </td>
      <td class="xl2915" x:num="123903.11722241093"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>123.903 </td>
      <td class="xl2915" x:num="261333.16086685006"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>261.333 </td>
      <td class="xl2915" x:num="395544"><span style='mso-spacerun:yes'>&nbsp; </span>395.544 </td>
      <td class="xl354" align="right" x:num="505969">505.969</td>
      <td class="xl354" align="right" x:num="505969">607.105</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Campo Limpo</td>
      <td class="xl3115" x:num="5932.4012375233324"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>5.932 </td>
      <td class="xl3115" x:num="15802.50164157586"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>15.803 </td>
      <td class="xl3115" x:num="54555.195742168238"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>54.555 </td>
      <td class="xl3115" x:num="110555.97306546383"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>110.556 </td>
      <td class="xl3115" x:num="159471"><span style='mso-spacerun:yes'>&nbsp; </span>159.471 </td>
      <td class="xl372" align="right" x:num="191527">191.527</td>
      <td class="xl372" align="right" x:num="191527">211.361</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Cap&atilde;o Redondo</td>
      <td class="xl3115" x:num="5153.2025471068337"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>5.153 </td>
      <td class="xl3115" x:num="14536.221420239775"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>14.536 </td>
      <td class="xl3115" x:num="57259.003686474331"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>57.259 </td>
      <td class="xl3115" x:num="128193.53347818123"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>128.194 </td>
      <td class="xl3115" x:num="193497"><span style='mso-spacerun:yes'>&nbsp; </span>193.497 </td>
      <td class="xl372" align="right" x:num="240793">240.793</td>
      <td class="xl372" align="right" x:num="240793">268.729</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Vila Andrade</td>
      <td class="xl3115" x:num="1616.9314523203286"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>1.617 </td>
      <td class="xl3115" x:num="4471.3387753367715"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>4.471 </td>
      <td class="xl3115" x:num="12088.917793768356"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>12.089 </td>
      <td class="xl3115" x:num="22583.654323204999"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>22.584 </td>
      <td class="xl3115" x:num="42576"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>42.576 </td>
      <td class="xl372" align="right" x:num="73649">73.649</td>
      <td class="xl372" align="right" x:num="73649">127.015</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Capela do Socorro</td>
      <td class="xl2915" x:num="6582.5621670208538"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>6.583 </td>
      <td class="xl2915" x:num="19347.319648431894"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>19.347 </td>
      <td class="xl2915" x:num="103792.95119689206"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>103.793 </td>
      <td class="xl2915" x:num="281029.33868425677"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>281.029 </td>
      <td class="xl2915" x:num="405769"><span style='mso-spacerun:yes'>&nbsp; </span>405.769 </td>
      <td class="xl354" align="right" x:num="563922">563.922</td>
      <td class="xl354" align="right" x:num="563922">594.930</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Cidade Dutra</td>
      <td class="xl3115" x:num="2134.9614944067807"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>2.135 </td>
      <td class="xl3115" x:num="7780.9463381452533"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>7.781 </td>
      <td class="xl3115" x:num="45168.172313222822"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>45.168 </td>
      <td class="xl3115" x:num="122989.86183010596"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>122.990 </td>
      <td class="xl3115" x:num="168821"><span style='mso-spacerun:yes'>&nbsp; </span>168.821 </td>
      <td class="xl372" align="right" x:num="191389">191.389</td>
      <td class="xl372" align="right" x:num="191389">196.360</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Graja&uacute;</td>
      <td class="xl3115" x:num="3740.4296907933158"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>3.740 </td>
      <td class="xl3115" x:num="8989.0624426872619"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>8.989 </td>
      <td class="xl3115" x:num="43663.562559406571"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>43.664 </td>
      <td class="xl3115" x:num="117301.10214704061"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>117.301 </td>
      <td class="xl3115" x:num="193754"><span style='mso-spacerun:yes'>&nbsp; </span>193.754 </td>
      <td class="xl372" align="right" x:num="333436">333.436</td>
      <td class="xl372" align="right" x:num="333436">360.787</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Socorro</td>
      <td class="xl3115" x:num="707.17098182075745"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>707 </td>
      <td class="xl3115" x:num="2577.3108675993781"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>2.577 </td>
      <td class="xl3115" x:num="14961.216324262658"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>14.961 </td>
      <td class="xl3115" x:num="40738.374707110168"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>40.738 </td>
      <td class="xl3115" x:num="43194"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>43.194 </td>
      <td class="xl372" align="right" x:num="39097">39.097</td>
      <td class="xl372" align="right" x:num="39097">37.783</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Casa Verde/Cachoeirinha</td>
      <td class="xl2915" x:num="98662.239976933226"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>98.662 </td>
      <td class="xl2915" x:num="179682.3559357312"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>179.682 </td>
      <td class="xl2915" x:num="252351.62060266724"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>252.352 </td>
      <td class="xl2915" x:num="298092.61098943424"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>298.093 </td>
      <td class="xl2915" x:num="312670"><span style='mso-spacerun:yes'>&nbsp; </span>312.670 </td>
      <td class="xl354" align="right" x:num="313323">313.323</td>
      <td class="xl354" align="right" x:num="313323">309.376</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Cachoeirinha</td>
      <td class="xl3115" x:num="32461.406443678268"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>32.461 </td>
      <td class="xl3115" x:num="58830.731406216561"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>58.831 </td>
      <td class="xl3115" x:num="85047.737859940142"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>85.048 </td>
      <td class="xl3115" x:num="105726.13992369287"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>105.726 </td>
      <td class="xl3115" x:num="125852"><span style='mso-spacerun:yes'>&nbsp; </span>125.852 </td>
      <td class="xl372" align="right" x:num="147649">147.649</td>
      <td class="xl372" align="right" x:num="147649">143.523</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Casa Verde</td>
      <td class="xl3115" x:num="43371.130391136336"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>43.371 </td>
      <td class="xl3115" x:num="74348.833972984285"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>74.349 </td>
      <td class="xl3115" x:num="92721.534544763577"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>92.722 </td>
      <td class="xl3115" x:num="103455.04594169391"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>103.455 </td>
      <td class="xl3115" x:num="96396"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>96.396 </td>
      <td class="xl372" align="right" x:num="83629">83.629</td>
      <td class="xl372" align="right" x:num="83629">85.624</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Lim&atilde;o</td>
      <td class="xl3115" x:num="22829.703142118633"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>22.830 </td>
      <td class="xl3115" x:num="46502.790556530337"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>46.503 </td>
      <td class="xl3115" x:num="74582.348197963525"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>74.582 </td>
      <td class="xl3115" x:num="88911.425124047455"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>88.911 </td>
      <td class="xl3115" x:num="90422"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>90.422 </td>
      <td class="xl372" align="right" x:num="82045">82.045</td>
      <td class="xl372" align="right" x:num="82045">80.229</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Cidade Ademar</td>
      <td class="xl2915" x:num="20414.822828737808"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>20.415 </td>
      <td class="xl2915" x:num="51348.416169435091"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>51.348 </td>
      <td class="xl2915" x:num="153255.1749604246"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>153.255 </td>
      <td class="xl2915" x:num="282707.10184659844"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>282.707 </td>
      <td class="xl2915" x:num="316795"><span style='mso-spacerun:yes'>&nbsp; </span>316.795 </td>
      <td class="xl354" align="right" x:num="370797">370.797</td>
      <td class="xl354" align="right" x:num="370797">410.998</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Cidade Ademar</td>
      <td class="xl3115" x:num="17031.125466250451"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>17.031 </td>
      <td class="xl3115" x:num="42335.053622901491"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>42.335 </td>
      <td class="xl3115" x:num="122138.21834340681"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>122.138 </td>
      <td class="xl3115" x:num="219648.66404190805"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>219.649 </td>
      <td class="xl3115" x:num="230794"><span style='mso-spacerun:yes'>&nbsp; </span>230.794 </td>
      <td class="xl372" align="right" x:num="243372">243.372</td>
      <td class="xl372" align="right" x:num="243372">266.681</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Pedreira</td>
      <td class="xl3115" x:num="3383.6973624873581"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>3.384 </td>
      <td class="xl3115" x:num="9013.3625465336008"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>9.013 </td>
      <td class="xl3115" x:num="31116.956617017786"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>31.117 </td>
      <td class="xl3115" x:num="63058.437804690373"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>63.058 </td>
      <td class="xl3115" x:num="86001"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>86.001 </td>
      <td class="xl372" align="right" x:num="127425">127.425</td>
      <td class="xl372" align="right" x:num="127425">144.317</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Cidade Tiradentes</td>
      <td class="xl2915" x:num="598.88081353676762"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>599 </td>
      <td class="xl2915" x:num="1418.1607734100287"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>1.418 </td>
      <td class="xl2915" x:num="4296.3211672383441"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>4.296 </td>
      <td class="xl2915" x:num="8603.2968850304733"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>8.603 </td>
      <td class="xl2915" x:num="96281"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>96.281 </td>
      <td class="xl354" align="right" x:num="190657">190.657</td>
      <td class="xl354" align="right" x:num="190657">211.501</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Cidade Tiradentes</td>
      <td class="xl3115" x:num="598.88081353676762"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>599 </td>
      <td class="xl372" align="right" x:num="1418.1607734100287">1.418</td>
      <td class="xl3115" x:num="4296.3211672383441"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>4.296 </td>
      <td class="xl3115" x:num="8603.2968850304733"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>8.603 </td>
      <td class="xl3115" x:num="96281"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>96.281 </td>
      <td class="xl372" align="right" x:num="190657">190.657</td>
      <td class="xl372" align="right" x:num="190657">211.501</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Ermelino Matarazzo</td>
      <td class="xl2915" x:num="19039.812846337423"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>19.040 </td>
      <td class="xl354" align="right" x:num="67160.022924663179">67.160</td>
      <td class="xl2915" x:num="112031.23159943994"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>112.031 </td>
      <td class="xl2915" x:num="177306.69252491335"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>177.307 </td>
      <td class="xl2915" x:num="198311"><span style='mso-spacerun:yes'>&nbsp; </span>198.311 </td>
      <td class="xl354" align="right" x:num="204951">204.951</td>
      <td class="xl354" align="right" x:num="204951">207.509</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Ermelino Matarazzo</td>
      <td class="xl3115" x:num="10834.773700719783"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>10.835 </td>
      <td class="xl3115" x:num="38218.004346815556"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>38.218 </td>
      <td class="xl3115" x:num="50871.877048913339"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>50.872 </td>
      <td class="xl3115" x:num="80512.586832277259"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>80.513 </td>
      <td class="xl3115" x:num="95609"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>95.609 </td>
      <td class="xl372" align="right" x:num="106838">106.838</td>
      <td class="xl372" align="right" x:num="106838">113.615</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Ponte Rasa</td>
      <td class="xl3115" x:num="8205.0391456176403"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>8.205 </td>
      <td class="xl3115" x:num="28942.018577847615"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>28.942 </td>
      <td class="xl3115" x:num="61159.354550526601"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>61.159 </td>
      <td class="xl3115" x:num="96794.105692636091"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>96.794 </td>
      <td class="xl3115" x:num="102702"><span style='mso-spacerun:yes'>&nbsp; </span>102.702 </td>
      <td class="xl372" align="right" x:num="98113">98.113</td>
      <td class="xl372" align="right" x:num="98113">93.894</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Freguesia/Brasil&acirc;ndia</td>
      <td class="xl2915" x:num="36815.414828545312"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>36.815 </td>
      <td class="xl2915" x:num="94744.02999653999"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>94.744 </td>
      <td class="xl2915" x:num="218762.58133137668"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>218.763 </td>
      <td class="xl2915" x:num="317019.06233809632"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>317.019 </td>
      <td class="xl2915" x:num="354263"><span style='mso-spacerun:yes'>&nbsp; </span>354.263 </td>
      <td class="xl354" align="right" x:num="392251">392.251</td>
      <td class="xl354" align="right" x:num="392251">407.245</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Brasil&acirc;ndia</td>
      <td class="xl3115" x:num="19328.82604849344"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>19.329 </td>
      <td class="xl3115" x:num="49742.502793054256"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>49.743 </td>
      <td class="xl3115" x:num="114854.71235801518"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>114.855 </td>
      <td class="xl3115" x:num="166441.32188993951"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>166.441 </td>
      <td class="xl3115" x:num="201591"><span style='mso-spacerun:yes'>&nbsp; </span>201.591 </td>
      <td class="xl372" align="right" x:num="247328">247.328</td>
      <td class="xl372" align="right" x:num="247328">264.918</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Freguesia do &Oacute;</td>
      <td class="xl3115" x:num="17486.588780051869"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>17.487 </td>
      <td class="xl3115" x:num="45001.527203485741"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>45.002 </td>
      <td class="xl3115" x:num="103907.86897336152"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>103.908 </td>
      <td class="xl3115" x:num="150577.74044815684"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>150.578 </td>
      <td class="xl3115" x:num="152672"><span style='mso-spacerun:yes'>&nbsp; </span>152.672 </td>
      <td class="xl372" align="right" x:num="144923">144.923</td>
      <td class="xl372" align="right" x:num="144923">142.327</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Guaianases</td>
      <td class="xl2915" x:num="6704.4471096027828"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>6.704 </td>
      <td class="xl2915" x:num="17289.765728143124"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>17.290 </td>
      <td class="xl2915" x:num="59749.309529286271"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>59.749 </td>
      <td class="xl2915" x:num="119834.78510665816"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>119.835 </td>
      <td class="xl2915" x:num="194180"><span style='mso-spacerun:yes'>&nbsp; </span>194.180 </td>
      <td class="xl354" align="right" x:num="256319">256.319</td>
      <td class="xl354" align="right" x:num="256319">268.508</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Guaianases</td>
      <td class="xl3115" x:num="3509.564357427023"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>3.510 </td>
      <td class="xl3115" x:num="8310.7129014000584"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>8.311 </td>
      <td class="xl3115" x:num="25177.322925996934"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>25.177 </td>
      <td class="xl3115" x:num="50417.083702769451"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>50.417 </td>
      <td class="xl3115" x:num="81373"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>81.373 </td>
      <td class="xl372" align="right" x:num="98546">98.546</td>
      <td class="xl372" align="right" x:num="98546">103.996</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Lajeado</td>
      <td class="xl3115" x:num="3194.8827521757603"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>3.195 </td>
      <td class="xl3115" x:num="8979.0528267430673"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>8.979 </td>
      <td class="xl3115" x:num="34571.986603289333"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>34.572 </td>
      <td class="xl3115" x:num="69417.701403888714"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>69.418 </td>
      <td class="xl3115" x:num="112807"><span style='mso-spacerun:yes'>&nbsp; </span>112.807 </td>
      <td class="xl372" align="right" x:num="157773">157.773</td>
      <td class="xl372" align="right" x:num="157773">164.512</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Ipiranga</td>
      <td class="xl2915" x:num="190612.15931812697"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>190.612 </td>
      <td class="xl2915" x:num="272223.39923313481"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>272.223 </td>
      <td class="xl2915" x:num="344958.59648296714"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>344.959 </td>
      <td class="xl2915" x:num="398027.76193343161"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>398.028 </td>
      <td class="xl2915" x:num="423168"><span style='mso-spacerun:yes'>&nbsp; </span>423.168 </td>
      <td class="xl354" align="right" x:num="429235">429.235</td>
      <td class="xl354" align="right" x:num="429235">463.804</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Cursino</td>
      <td class="xl3115" x:num="25462.717335380043"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>25.463 </td>
      <td class="xl3115" x:num="52021.344909865576"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>52.021 </td>
      <td class="xl3115" x:num="90462.343021625944"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>90.462 </td>
      <td class="xl3115" x:num="116473.24529393771"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>116.473 </td>
      <td class="xl3115" x:num="110435"><span style='mso-spacerun:yes'>&nbsp; </span>110.435 </td>
      <td class="xl372" align="right" x:num="102089">102.089</td>
      <td class="xl372" align="right" x:num="102089">109.088</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Ipiranga</td>
      <td class="xl3115" x:num="94691.510468934095"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>94.692 </td>
      <td class="xl3115" x:num="109546.00652724823"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>109.546 </td>
      <td class="xl3115" x:num="111939.16097676034"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>111.939 </td>
      <td class="xl3115" x:num="117587.74507680746"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>117.588 </td>
      <td class="xl3115" x:num="101533"><span style='mso-spacerun:yes'>&nbsp; </span>101.533 </td>
      <td class="xl372" align="right" x:num="98863">98.863</td>
      <td class="xl372" align="right" x:num="98863">106.865</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Sacom&atilde;</td>
      <td class="xl3115" x:num="70457.931513812815"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>70.458 </td>
      <td class="xl3115" x:num="110656.04779602098"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>110.656 </td>
      <td class="xl3115" x:num="142557.09248458091"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>142.557 </td>
      <td class="xl3115" x:num="163966.77156268642"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>163.967 </td>
      <td class="xl3115" x:num="211200"><span style='mso-spacerun:yes'>&nbsp; </span>211.200 </td>
      <td class="xl372" align="right" x:num="228283">228.283</td>
      <td class="xl372" align="right" x:num="228283">247.851</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Itaim Paulista</td>
      <td class="xl2915" x:num="12721.750035631332"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>12.722 </td>
      <td class="xl2915" x:num="32598.613297676882"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>32.599 </td>
      <td class="xl2915" x:num="102778.92011068728"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>102.779 </td>
      <td class="xl2915" x:num="202709.67048949661"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>202.710 </td>
      <td class="xl2915" x:num="287569"><span style='mso-spacerun:yes'>&nbsp; </span>287.569 </td>
      <td class="xl354" align="right" x:num="359215">359.215</td>
      <td class="xl354" align="right" x:num="359215">373.127</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Itaim Paulista</td>
      <td class="xl3115" x:num="6077.3404318567345"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>6.077 </td>
      <td class="xl3115" x:num="16864.529236953331"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>16.865 </td>
      <td class="xl3115" x:num="55112.478008604528"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>55.112 </td>
      <td class="xl3115" x:num="107258.57712513879"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>107.259 </td>
      <td class="xl3115" x:num="163269"><span style='mso-spacerun:yes'>&nbsp; </span>163.269 </td>
      <td class="xl372" align="right" x:num="212733">212.733</td>
      <td class="xl372" align="right" x:num="212733">224.074</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Vila Curu&ccedil;&aacute;</td>
      <td class="xl3115" x:num="6644.4096037745985"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>6.644 </td>
      <td class="xl3115" x:num="15734.084060723551"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>15.734 </td>
      <td class="xl3115" x:num="47666.44210208275"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>47.666 </td>
      <td class="xl3115" x:num="95451.093364357803"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>95.451 </td>
      <td class="xl3115" x:num="124300"><span style='mso-spacerun:yes'>&nbsp; </span>124.300 </td>
      <td class="xl372" align="right" x:num="146482">146.482</td>
      <td class="xl372" align="right" x:num="146482">149.053</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Itaquera</td>
      <td class="xl2915" x:num="15245.645688460178"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>15.246 </td>
      <td class="xl2915" x:num="36964.695412496054"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>36.965 </td>
      <td class="xl2915" x:num="129313.95204198548"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>129.314 </td>
      <td class="xl2915" x:num="256383.05796433779"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>256.383 </td>
      <td class="xl2915" x:num="431191"><span style='mso-spacerun:yes'>&nbsp; </span>431.191 </td>
      <td class="xl354" align="right" x:num="489502">489.502</td>
      <td class="xl354" align="right" x:num="489502">523.848</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Cidade L&iacute;der</td>
      <td class="xl3115" x:num="7254.461563802005"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>7.254 </td>
      <td class="xl372" align="right" x:num="15064.077708119259">15.064</td>
      <td class="xl3115" x:num="38420.406299538517"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>38.420 </td>
      <td class="xl3115" x:num="70508.14723461018"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>70.508 </td>
      <td class="xl3115" x:num="97370"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>97.370 </td>
      <td class="xl372" align="right" x:num="116841">116.841</td>
      <td class="xl372" align="right" x:num="116841">126.597</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Itaquera</td>
      <td class="xl3115" x:num="5070.3333837311393"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>5.070 </td>
      <td class="xl3115" x:num="15245.096288172832"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>15.245 </td>
      <td class="xl3115" x:num="63070.066129018975"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>63.070 </td>
      <td class="xl3115" x:num="126727.24464514307"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>126.727 </td>
      <td class="xl3115" x:num="175366"><span style='mso-spacerun:yes'>&nbsp; </span>175.366 </td>
      <td class="xl372" align="right" x:num="201512">201.512</td>
      <td class="xl372" align="right" x:num="201512">204.871</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Jos&eacute; Bonif&aacute;cio</td>
      <td class="xl3115" x:num="1187.5932140734419"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>1.188 </td>
      <td class="xl3115" x:num="2706.078732217472"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>2.706 </td>
      <td class="xl3115" x:num="11312.791550016178"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>11.313 </td>
      <td class="xl3115" x:num="24048.940908236975"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>24.049 </td>
      <td class="xl3115" x:num="103712"><span style='mso-spacerun:yes'>&nbsp; </span>103.712 </td>
      <td class="xl372" align="right" x:num="107082">107.082</td>
      <td class="xl372" align="right" x:num="107082">124.122</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Parque do Carmo</td>
      <td class="xl3115" x:num="1733.2575268535918"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>1.733 </td>
      <td class="xl3115" x:num="3949.4426839864923"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>3.949 </td>
      <td class="xl3115" x:num="16510.688063411817"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>16.511 </td>
      <td class="xl3115" x:num="35098.725176347529"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>35.099 </td>
      <td class="xl3115" x:num="54743"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>54.743 </td>
      <td class="xl372" align="right" x:num="64067">64.067</td>
      <td class="xl372" align="right" x:num="64067">68.258</td>
    </tr>
    <tr height="17" style='page-break-before:always;height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Jabaquara</td>
      <td class="xl2915" x:num="26853.544864021424"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>26.854 </td>
      <td class="xl2915" x:num="72546.247776326243"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>72.546 </td>
      <td class="xl2915" x:num="141761.89861952103"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>141.762 </td>
      <td class="xl2915" x:num="196150.95953706882"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>196.151 </td>
      <td class="xl2915" x:num="214350"><span style='mso-spacerun:yes'>&nbsp; </span>214.350 </td>
      <td class="xl354" align="right" x:num="214095">214.095</td>
      <td class="xl354" align="right" x:num="214095">223.780</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Jabaquara</td>
      <td class="xl3115" x:num="26853.544864021424"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>26.854 </td>
      <td class="xl3115" x:num="72546.247776326243"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>72.546 </td>
      <td class="xl3115" x:num="141761.89861952103"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>141.762 </td>
      <td class="xl3115" x:num="196150.95953706882"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>196.151 </td>
      <td class="xl3115" x:num="214350"><span style='mso-spacerun:yes'>&nbsp; </span>214.350 </td>
      <td class="xl372" align="right" x:num="214095">214.095</td>
      <td class="xl372" align="right" x:num="214095">223.780</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Ja&ccedil;an&atilde;/Trememb&eacute;</td>
      <td class="xl2915" x:num="35112.94794554761"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>35.113 </td>
      <td class="xl2915" x:num="85555.798842392309"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>85.556 </td>
      <td class="xl2915" x:num="137607.57314237783"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>137.608 </td>
      <td class="xl2915" x:num="176894.76859437424"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>176.895 </td>
      <td class="xl2915" x:num="211905"><span style='mso-spacerun:yes'>&nbsp; </span>211.905 </td>
      <td class="xl354" align="right" x:num="255612">255.612</td>
      <td class="xl354" align="right" x:num="255612">291.867</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Ja&ccedil;an&atilde;</td>
      <td class="xl3115" x:num="15895.503296633697"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>15.896 </td>
      <td class="xl3115" x:num="38730.797671968779"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>38.731 </td>
      <td class="xl3115" x:num="62294.445795850319"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>62.294 </td>
      <td class="xl3115" x:num="80079.615693608444"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>80.080 </td>
      <td class="xl3115" x:num="86830"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>86.830 </td>
      <td class="xl372" align="right" x:num="91809">91.809</td>
      <td class="xl372" align="right" x:num="91809">94.609</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Trememb&eacute;</td>
      <td class="xl3115" x:num="19217.444648913915"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>19.217 </td>
      <td class="xl3115" x:num="46825.001170423537"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>46.825 </td>
      <td class="xl3115" x:num="75313.12734652753"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>75.313 </td>
      <td class="xl3115" x:num="96815.15290076581"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>96.815 </td>
      <td class="xl3115" x:num="125075"><span style='mso-spacerun:yes'>&nbsp; </span>125.075 </td>
      <td class="xl372" align="right" x:num="163803">163.803</td>
      <td class="xl372" align="right" x:num="163803">197.258</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Lapa</td>
      <td class="xl2915" x:num="162030.2743850087"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>162.030 </td>
      <td class="xl2915" x:num="212109.77862597676"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>212.110 </td>
      <td class="xl2915" x:num="257378.85512144468"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>257.379 </td>
      <td class="xl2915" x:num="319806.31404327689"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>319.806 </td>
      <td class="xl2915" x:num="296122"><span style='mso-spacerun:yes'>&nbsp; </span>296.122 </td>
      <td class="xl354" align="right" x:num="270656">270.656</td>
      <td class="xl354" align="right" x:num="270656">305.526</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Barra Funda</td>
      <td class="xl3115" x:num="11614.951848165203"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>11.615 </td>
      <td class="xl3115" x:num="14041.087670536015"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>14.041 </td>
      <td class="xl3115" x:num="15407.009271376159"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>15.407 </td>
      <td class="xl3115" x:num="17894.135902298942"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>17.894 </td>
      <td class="xl3115" x:num="15977"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>15.977 </td>
      <td class="xl372" align="right" x:num="12965">12.965</td>
      <td class="xl372" align="right" x:num="12965">14.383</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Jaguara</td>
      <td class="xl3115" x:num="5902.3336111243125"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>5.902 </td>
      <td class="xl3115" x:num="15975.841823601098"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>15.976 </td>
      <td class="xl3115" x:num="23779.272348344664"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>23.779 </td>
      <td class="xl3115" x:num="32770.503057996437"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>32.771 </td>
      <td class="xl3115" x:num="29798"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>29.798 </td>
      <td class="xl372" align="right" x:num="25713">25.713</td>
      <td class="xl372" align="right" x:num="25713">24.895</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Jaguar&eacute;</td>
      <td class="xl3115" x:num="3589.8158723863785"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>3.590 </td>
      <td class="xl3115" x:num="8633.6049605707485"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>8.634 </td>
      <td class="xl3115" x:num="22080.023357129932"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>22.080 </td>
      <td class="xl3115" x:num="39867.421189741632"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>39.867 </td>
      <td class="xl3115" x:num="44361"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>44.361 </td>
      <td class="xl372" align="right" x:num="42479">42.479</td>
      <td class="xl372" align="right" x:num="42479">49.863</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Lapa</td>
      <td class="xl3115" x:num="50903.967009522479"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>50.904 </td>
      <td class="xl3115" x:num="62975.515942167709"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>62.976 </td>
      <td class="xl3115" x:num="70980.952929111649"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>70.981 </td>
      <td class="xl3115" x:num="83704.746731953652"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>83.705 </td>
      <td class="xl3115" x:num="70319"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>70.319 </td>
      <td class="xl372" align="right" x:num="60184">60.184</td>
      <td class="xl372" align="right" x:num="60184">65.739</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Perdizes</td>
      <td class="xl3115" x:num="71390.624086812983"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>71.391 </td>
      <td class="xl3115" x:num="88320.452204822504"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>88.320 </td>
      <td class="xl3115" x:num="99547.733223582225"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>99.548 </td>
      <td class="xl3115" x:num="117392.3067156028"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>117.392 </td>
      <td class="xl3115" x:num="108840"><span style='mso-spacerun:yes'>&nbsp; </span>108.840 </td>
      <td class="xl372" align="right" x:num="102445">102.445</td>
      <td class="xl372" align="right" x:num="102445">111.161</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Vila Leopoldina</td>
      <td class="xl3115" x:num="18628.581956997332"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>18.629 </td>
      <td class="xl3115" x:num="22163.27602427869"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>22.163 </td>
      <td class="xl3115" x:num="25583.863991900045"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>25.584 </td>
      <td class="xl3115" x:num="28177.200445683451"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>28.177 </td>
      <td class="xl3115" x:num="26827"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>26.827 </td>
      <td class="xl372" align="right" x:num="26870">26.870</td>
      <td class="xl372" align="right" x:num="26870">39.485</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>M'Boi Mirim</td>
      <td class="xl2915" x:num="10902.440295704597"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>10.902 </td>
      <td class="xl2915" x:num="30753.746764384818"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>30.754 </td>
      <td class="xl2915" x:num="121140.75924180314"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>121.141 </td>
      <td class="xl2915" x:num="271214.32395975728"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>271.214 </td>
      <td class="xl2915" x:num="382657"><span style='mso-spacerun:yes'>&nbsp; </span>382.657 </td>
      <td class="xl354" align="right" x:num="484966">484.966</td>
      <td class="xl354" align="right" x:num="484966">563.305</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Jardim &Acirc;ngela</td>
      <td class="xl3115" x:num="4324.5790518341637"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>4.325 </td>
      <td class="xl3115" x:num="12198.829382727294"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>12.199 </td>
      <td class="xl3115" x:num="48051.883388601542"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>48.052 </td>
      <td class="xl3115" x:num="107580.29873512186"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>107.580 </td>
      <td class="xl3115" x:num="178373"><span style='mso-spacerun:yes'>&nbsp; </span>178.373 </td>
      <td class="xl372" align="right" x:num="245805">245.805</td>
      <td class="xl372" align="right" x:num="245805">295.434</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Jardim S&atilde;o Lu&iacute;s</td>
      <td class="xl3115" x:num="6577.8612438704322"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>6.578 </td>
      <td class="xl3115" x:num="18554.917381657524"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>18.555 </td>
      <td class="xl3115" x:num="73088.875853201593"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>73.089 </td>
      <td class="xl3115" x:num="163634.02522463544"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>163.634 </td>
      <td class="xl3115" x:num="204284"><span style='mso-spacerun:yes'>&nbsp; </span>204.284 </td>
      <td class="xl372" align="right" x:num="239161">239.161</td>
      <td class="xl372" align="right" x:num="239161">267.871</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Mooca</td>
      <td class="xl2915" x:num="262890.40013650572"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>262.890 </td>
      <td class="xl2915" x:num="334692.06050393381"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>334.692 </td>
      <td class="xl2915" x:num="384799.82186796656"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>384.800 </td>
      <td class="xl2915" x:num="409374.21161137085"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>409.374 </td>
      <td class="xl2915" x:num="353470"><span style='mso-spacerun:yes'>&nbsp; </span>353.470 </td>
      <td class="xl354" align="right" x:num="308161">308.161</td>
      <td class="xl354" align="right" x:num="308161">343.980</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>&Aacute;gua Rasa</td>
      <td class="xl3115" x:num="38958.631040568143"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>38.959 </td>
      <td class="xl3115" x:num="66763.174320343678"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>66.763 </td>
      <td class="xl3115" x:num="96186.544382280947"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>96.187 </td>
      <td class="xl3115" x:num="112608.57698211601"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>112.609 </td>
      <td class="xl3115" x:num="95099"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>95.099 </td>
      <td class="xl372" align="right" x:num="85896">85.896</td>
      <td class="xl372" align="right" x:num="85896">84.963</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Bel&eacute;m</td>
      <td class="xl3115" x:num="56722.02741407101"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>56.722 </td>
      <td class="xl3115" x:num="62881.238483480389"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>62.881 </td>
      <td class="xl3115" x:num="60030.778521234737"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>60.031 </td>
      <td class="xl3115" x:num="57195.286968550106"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>57.195 </td>
      <td class="xl3115" x:num="49697"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>49.697 </td>
      <td class="xl372" align="right" x:num="39622">39.622</td>
      <td class="xl372" align="right" x:num="39622">45.057</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Br&aacute;s</td>
      <td class="xl3115" x:num="55097.061517319205"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>55.097 </td>
      <td class="xl3115" x:num="48874.686112267198"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>48.875 </td>
      <td class="xl3115" x:num="41005.595030976445"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>41.006 </td>
      <td class="xl3115" x:num="38629.644902112013"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>38.630 </td>
      <td class="xl3115" x:num="33536"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>33.536 </td>
      <td class="xl372" align="right" x:num="25158">25.158</td>
      <td class="xl372" align="right" x:num="25158">29.265</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Mo&oacute;ca</td>
      <td class="xl3115" x:num="46678.893124892435"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>46.679 </td>
      <td class="xl3115" x:num="61973.404057512787"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>61.973 </td>
      <td class="xl3115" x:num="74385.731443801647"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>74.386 </td>
      <td class="xl3115" x:num="84582.715985365416"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>84.583 </td>
      <td class="xl3115" x:num="71999"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>71.999 </td>
      <td class="xl372" align="right" x:num="63280">63.280</td>
      <td class="xl372" align="right" x:num="63280">75.724</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Pari</td>
      <td class="xl3115" x:num="31311.71606829769"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>31.312 </td>
      <td class="xl3115" x:num="33706.28676081563"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>33.706 </td>
      <td class="xl3115" x:num="29914.199173118661"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>29.914 </td>
      <td class="xl3115" x:num="26968.489350232994"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>26.968 </td>
      <td class="xl3115" x:num="21299"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>21.299 </td>
      <td class="xl372" align="right" x:num="14824">14.824</td>
      <td class="xl372" align="right" x:num="14824">17.299</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Tatuap&eacute;</td>
      <td class="xl3115" x:num="34122.070971357258"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>34.122 </td>
      <td class="xl3115" x:num="60493.270769514143"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>60.493 </td>
      <td class="xl3115" x:num="83276.973316554126"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>83.277 </td>
      <td class="xl3115" x:num="89389.497422994289"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>89.389 </td>
      <td class="xl3115" x:num="81840"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>81.840 </td>
      <td class="xl372" align="right" x:num="79381">79.381</td>
      <td class="xl372" align="right" x:num="79381">91.672</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Parelheiros</td>
      <td class="xl2915" x:num="1759.2347003187751"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>1.759 </td>
      <td class="xl2915" x:num="3328.2962214862082"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>3.328 </td>
      <td class="xl2915" x:num="13664.369043771621"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>13.664 </td>
      <td class="xl2915" x:num="36150.083334828072"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>36.150 </td>
      <td class="xl2915" x:num="61586"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>61.586 </td>
      <td class="xl354" align="right" x:num="111240">111.240</td>
      <td class="xl354" align="right" x:num="111240">137.441</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Marsilac</td>
      <td class="xl3115" x:num="1208.7662803908897"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>1.209 </td>
      <td class="xl3115" x:num="1322.0936517800963"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>1.322 </td>
      <td class="xl3115" x:num="2018.4201545628114"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>2.018 </td>
      <td class="xl3115" x:num="4438.9564193615988"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>4.439 </td>
      <td class="xl3115" x:num="5992"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp; </span>5.992 </td>
      <td class="xl372" align="right" x:num="8404">8.404</td>
      <td class="xl372" align="right" x:num="8404">8.258</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Parelheiros</td>
      <td class="xl3115" x:num="550.46841992788552"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>550 </td>
      <td class="xl3115" x:num="2006.2025697061119"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>2.006 </td>
      <td class="xl3115" x:num="11645.94888920881"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>11.646 </td>
      <td class="xl3115" x:num="31711.12691546647"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>31.711 </td>
      <td class="xl3115" x:num="55594"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>55.594 </td>
      <td class="xl372" align="right" x:num="102836">102.836</td>
      <td class="xl372" align="right" x:num="102836">131.183</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Penha</td>
      <td class="xl2915" x:num="105014.65214135069"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>105.015 </td>
      <td class="xl2915" x:num="206463.01140878876"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>206.463 </td>
      <td class="xl2915" x:num="336279.40796587517"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>336.279 </td>
      <td class="xl2915" x:num="462665.74259585835"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>462.666 </td>
      <td class="xl2915" x:num="475630"><span style='mso-spacerun:yes'>&nbsp; </span>475.630 </td>
      <td class="xl354" align="right" x:num="475879">475.879</td>
      <td class="xl354" align="right" x:num="475879">474.659</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Artur Alvim</td>
      <td class="xl3115" x:num="16548.587565342346"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>16.549 </td>
      <td class="xl3115" x:num="35396.294668537594"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>35.396 </td>
      <td class="xl3115" x:num="68637.067504937775"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>68.637 </td>
      <td class="xl3115" x:num="107130.28938034803"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>107.130 </td>
      <td class="xl3115" x:num="118531"><span style='mso-spacerun:yes'>&nbsp; </span>118.531 </td>
      <td class="xl372" align="right" x:num="111210">111.210</td>
      <td class="xl372" align="right" x:num="111210">105.269</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Canga&iacute;ba</td>
      <td class="xl3115" x:num="13494.720263957035"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>13.495 </td>
      <td class="xl3115" x:num="34742.200651649124"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>34.742 </td>
      <td class="xl3115" x:num="65637.781969052026"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>65.638 </td>
      <td class="xl3115" x:num="97792.344706789198"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>97.792 </td>
      <td class="xl3115" x:num="115070"><span style='mso-spacerun:yes'>&nbsp; </span>115.070 </td>
      <td class="xl372" align="right" x:num="137442">137.442</td>
      <td class="xl372" align="right" x:num="137442">136.623</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Penha</td>
      <td class="xl3115" x:num="55506.849247950384"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>55.507 </td>
      <td class="xl3115" x:num="96315.008679416991"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>96.315 </td>
      <td class="xl3115" x:num="127641.67092041376"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>127.642 </td>
      <td class="xl3115" x:num="140213.49381627192"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>140.213 </td>
      <td class="xl3115" x:num="133006"><span style='mso-spacerun:yes'>&nbsp; </span>133.006 </td>
      <td class="xl372" align="right" x:num="124292">124.292</td>
      <td class="xl372" align="right" x:num="124292">127.820</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Vila Matilde</td>
      <td class="xl3115" x:num="19464.495064100924"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>19.464 </td>
      <td class="xl3115" x:num="40009.507409185062"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>40.010 </td>
      <td class="xl3115" x:num="74362.887571471612"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>74.363 </td>
      <td class="xl3115" x:num="117529.61469244915"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>117.530 </td>
      <td class="xl3115" x:num="109023"><span style='mso-spacerun:yes'>&nbsp; </span>109.023 </td>
      <td class="xl372" align="right" x:num="102935">102.935</td>
      <td class="xl372" align="right" x:num="102935">104.947</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Perus</td>
      <td class="xl2915" x:num="4791.9709904784404"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>4.792 </td>
      <td class="xl2915" x:num="7985.7334337789935"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>7.986 </td>
      <td class="xl2915" x:num="23441.52439204459"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>23.442 </td>
      <td class="xl2915" x:num="41546.186600089495"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>41.546 </td>
      <td class="xl2915" x:num="58709"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>58.709 </td>
      <td class="xl354" align="right" x:num="109116">109.116</td>
      <td class="xl354" align="right" x:num="109116">146.046</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Anhanguera</td>
      <td class="xl3115" x:num="428.78680125296052"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>429 </td>
      <td class="xl3115" x:num="1030.3710006282708"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>1.030 </td>
      <td class="xl3115" x:num="2626.36487845176"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>2.626 </td>
      <td class="xl3115" x:num="5349.9998569772451"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>5.350 </td>
      <td class="xl3115" x:num="12408"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>12.408 </td>
      <td align="right" class="xl3115" x:num="38427"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp; </span>38.427 </td>
      <td align="right" class="xl3115" x:num="38427">65.859</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Perus</td>
      <td class="xl3115" x:num="4363.1841892254797"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>4.363 </td>
      <td class="xl3115" x:num="6955.3624331507226"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>6.955 </td>
      <td class="xl3115" x:num="20815.159513592829"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>20.815 </td>
      <td class="xl3115" x:num="36196.186743112252"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>36.196 </td>
      <td class="xl3115" x:num="46301"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>46.301 </td>
      <td class="xl372" align="right" x:num="70689">70.689</td>
      <td class="xl372" align="right" x:num="70689">80.187</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Pinheiros</td>
      <td class="xl2915" x:num="169003.47625613117"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>169.003 </td>
      <td class="xl2915" x:num="247079.06427247476"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>247.079 </td>
      <td class="xl2915" x:num="297644.31479637162"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>297.644 </td>
      <td class="xl2915" x:num="378617.22479778563"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>378.617 </td>
      <td class="xl2915" x:num="339630"><span style='mso-spacerun:yes'>&nbsp; </span>339.630 </td>
      <td class="xl354" align="right" x:num="272574">272.574</td>
      <td class="xl354" align="right" x:num="272574">289.743</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Alto de Pinheiros</td>
      <td class="xl3115" x:num="29528.656328634133"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>29.529 </td>
      <td class="xl3115" x:num="38371.250219218884"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>38.371 </td>
      <td class="xl3115" x:num="44573.352866648936"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>44.573 </td>
      <td class="xl3115" x:num="51177.789939458424"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>51.178 </td>
      <td class="xl3115" x:num="50351"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>50.351 </td>
      <td class="xl372" align="right" x:num="44454">44.454</td>
      <td class="xl372" align="right" x:num="44454">43.117</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Itaim Bibi</td>
      <td class="xl3115" x:num="31562.761868010315"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>31.563 </td>
      <td class="xl3115" x:num="61917.046651154931"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>61.917 </td>
      <td class="xl3115" x:num="84922.682757188304"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>84.923 </td>
      <td class="xl3115" x:num="114955.84181258449"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>114.956 </td>
      <td class="xl3115" x:num="107497"><span style='mso-spacerun:yes'>&nbsp; </span>107.497 </td>
      <td class="xl372" align="right" x:num="81456">81.456</td>
      <td class="xl372" align="right" x:num="81456">92.570</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Jardim Paulista</td>
      <td class="xl3115" x:num="60681.458255750025"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>60.681 </td>
      <td class="xl3115" x:num="79503.973048925283"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>79.504 </td>
      <td class="xl3115" x:num="91051.239304555813"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>91.051 </td>
      <td class="xl3115" x:num="117804.23064614186"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>117.804 </td>
      <td class="xl3115" x:num="103138"><span style='mso-spacerun:yes'>&nbsp; </span>103.138 </td>
      <td class="xl372" align="right" x:num="83667">83.667</td>
      <td class="xl372" align="right" x:num="83667">88.692</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Pinheiros</td>
      <td class="xl3115" x:num="47230.599803736688"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>47.231 </td>
      <td class="xl3115" x:num="67286.794353175646"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>67.287 </td>
      <td class="xl3115" x:num="77097.039867978587"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>77.097 </td>
      <td class="xl3115" x:num="94679.362399600854"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>94.679 </td>
      <td class="xl3115" x:num="78644"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>78.644 </td>
      <td class="xl372" align="right" x:num="62997">62.997</td>
      <td class="xl372" align="right" x:num="62997">65.364</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Pirituba</td>
      <td class="xl2915" x:num="31505.419919178123"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>31.505 </td>
      <td class="xl2915" x:num="84232.237391217481"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>84.232 </td>
      <td class="xl2915" x:num="176695.46822192252"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>176.695 </td>
      <td class="xl2915" x:num="249551.73555422912"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>249.552 </td>
      <td class="xl2915" x:num="315876"><span style='mso-spacerun:yes'>&nbsp; </span>315.876 </td>
      <td class="xl354" align="right" x:num="390530">390.530</td>
      <td class="xl354" align="right" x:num="390530">437.592</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Jaragu&aacute;</td>
      <td class="xl3115" x:num="5098.3937468369231"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>5.098 </td>
      <td class="xl3115" x:num="12970.350421465038"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>12.970 </td>
      <td class="xl3115" x:num="29530.718764384506"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>29.531 </td>
      <td class="xl3115" x:num="47416.353172272444"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>47.416 </td>
      <td class="xl3115" x:num="93185"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>93.185 </td>
      <td class="xl372" align="right" x:num="145900">145.900</td>
      <td class="xl372" align="right" x:num="145900">184.818</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Pirituba</td>
      <td class="xl3115" x:num="16217.609215573713"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>16.218 </td>
      <td class="xl3115" x:num="43681.919252486645"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>43.682 </td>
      <td class="xl3115" x:num="96396.937758042186"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>96.397 </td>
      <td class="xl3115" x:num="132678.59330582703"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>132.679 </td>
      <td class="xl3115" x:num="152305"><span style='mso-spacerun:yes'>&nbsp; </span>152.305 </td>
      <td class="xl372" align="right" x:num="161796">161.796</td>
      <td class="xl372" align="right" x:num="161796">167.931</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>S&atilde;o Domingos</td>
      <td class="xl3115" x:num="10189.416956767487"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>10.189 </td>
      <td class="xl3115" x:num="27579.967717265794"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>27.580 </td>
      <td class="xl3115" x:num="50767.811699495811"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>50.768 </td>
      <td class="xl3115" x:num="69456.789076129644"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>69.457 </td>
      <td class="xl3115" x:num="70386"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>70.386 </td>
      <td class="xl372" align="right" x:num="82834">82.834</td>
      <td class="xl372" align="right" x:num="82834">84.843</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Santana/Tucuruvi</td>
      <td class="xl2915" x:num="79287.648085744891"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>79.288 </td>
      <td class="xl2915" x:num="165318.52944514999"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>165.319 </td>
      <td class="xl2915" x:num="264714.61282969418"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>264.715 </td>
      <td class="xl2915" x:num="342814.92152110126"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>342.815 </td>
      <td class="xl2915" x:num="353585"><span style='mso-spacerun:yes'>&nbsp; </span>353.585 </td>
      <td class="xl354" align="right" x:num="327135">327.135</td>
      <td class="xl354" align="right" x:num="327135">324.815</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Mandaqui</td>
      <td class="xl3115" x:num="19130.520281474557"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>19.131 </td>
      <td class="xl3115" x:num="41255.793028068656"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>41.256 </td>
      <td class="xl3115" x:num="66910.748471674407"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>66.911 </td>
      <td class="xl3115" x:num="88202.835783679737"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>88.203 </td>
      <td class="xl3115" x:num="104022"><span style='mso-spacerun:yes'>&nbsp; </span>104.022 </td>
      <td class="xl372" align="right" x:num="103113">103.113</td>
      <td class="xl372" align="right" x:num="103113">107.580</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Santana</td>
      <td class="xl3115" x:num="35087.353217580756"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>35.087 </td>
      <td class="xl3115" x:num="69998.685027409461"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>69.999 </td>
      <td class="xl3115" x:num="110120.02947372003"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>110.120 </td>
      <td class="xl3115" x:num="139025.82992895119"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>139.026 </td>
      <td class="xl3115" x:num="137679"><span style='mso-spacerun:yes'>&nbsp; </span>137.679 </td>
      <td class="xl372" align="right" x:num="124654">124.654</td>
      <td class="xl372" align="right" x:num="124654">118.797</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Tucuruvi</td>
      <td class="xl3115" x:num="25069.774586689578"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>25.070 </td>
      <td class="xl3115" x:num="54064.051389671884"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>54.064 </td>
      <td class="xl3115" x:num="87683.834884299693"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>87.684 </td>
      <td class="xl3115" x:num="115586.25580847035"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>115.586 </td>
      <td class="xl3115" x:num="111884"><span style='mso-spacerun:yes'>&nbsp; </span>111.884 </td>
      <td class="xl372" align="right" x:num="99368">99.368</td>
      <td class="xl372" align="right" x:num="99368">98.438</td>
    </tr>
    <tr height="17" style='page-break-before:always;height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Santo Amaro</td>
      <td class="xl2915" x:num="19037.847641712418"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>19.038 </td>
      <td class="xl2915" x:num="60218.133418780199"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>60.218 </td>
      <td class="xl2915" x:num="137064.38977303688"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>137.064 </td>
      <td class="xl2915" x:num="239370.90030747536"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>239.371 </td>
      <td class="xl2915" x:num="235560"><span style='mso-spacerun:yes'>&nbsp; </span>235.560 </td>
      <td class="xl354" align="right" x:num="218558">218.558</td>
      <td class="xl354" align="right" x:num="218558">238.025</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Campo Belo</td>
      <td class="xl3115" x:num="9170.7132376667105"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>9.171 </td>
      <td class="xl3115" x:num="32275.435540605318"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>32.275 </td>
      <td class="xl3115" x:num="52958.577989027654"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>52.959 </td>
      <td class="xl3115" x:num="75630.636794185077"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>75.631 </td>
      <td class="xl3115" x:num="77952"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>77.952 </td>
      <td class="xl372" align="right" x:num="66646">66.646</td>
      <td class="xl372" align="right" x:num="66646">65.752</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Campo Grande</td>
      <td class="xl3115" x:num="3782.2096478161461"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>3.782 </td>
      <td class="xl3115" x:num="10074.904204111268"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>10.075 </td>
      <td class="xl3115" x:num="34781.731614746583"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>34.782 </td>
      <td class="xl3115" x:num="70485.095530468097"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>70.485 </td>
      <td class="xl3115" x:num="82052"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>82.052 </td>
      <td class="xl372" align="right" x:num="91373">91.373</td>
      <td class="xl372" align="right" x:num="91373">100.713</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Santo Amaro</td>
      <td class="xl3115" x:num="6084.9247562295641"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>6.085 </td>
      <td class="xl3115" x:num="17867.793674063611"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>17.868 </td>
      <td class="xl3115" x:num="49324.080169262634"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>49.324 </td>
      <td class="xl3115" x:num="93255.167982822168"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>93.255 </td>
      <td class="xl3115" x:num="75556"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>75.556 </td>
      <td class="xl372" align="right" x:num="60539">60.539</td>
      <td class="xl372" align="right" x:num="60539">71.560</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>S&atilde;o Mateus</td>
      <td class="xl2915" x:num="29585.696596682021"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>29.586 </td>
      <td class="xl2915" x:num="57823.127375382464"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>57.823 </td>
      <td class="xl2915" x:num="134416.08896437992"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>134.416 </td>
      <td class="xl2915" x:num="221458.7239410652"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>221.459 </td>
      <td class="xl2915" x:num="300446"><span style='mso-spacerun:yes'>&nbsp; </span>300.446 </td>
      <td class="xl354" align="right" x:num="381718">381.718</td>
      <td class="xl354" align="right" x:num="381718">426.764</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Iguatemi</td>
      <td class="xl3115" x:num="1695.0872757516936"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>1.695 </td>
      <td class="xl3115" x:num="3882.2226993258118"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>3.882 </td>
      <td class="xl3115" x:num="15620.137710841753"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>15.620 </td>
      <td class="xl3115" x:num="32595.109656915316"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>32.595 </td>
      <td class="xl3115" x:num="59820"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>59.820 </td>
      <td class="xl372" align="right" x:num="101780">101.780</td>
      <td class="xl372" align="right" x:num="101780">127.662</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>S&atilde;o Mateus</td>
      <td class="xl3115" x:num="25105.995985742717"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>25.106 </td>
      <td class="xl3115" x:num="47833.450698535504"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>47.833 </td>
      <td class="xl3115" x:num="86044.815614580599"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>86.045 </td>
      <td class="xl3115" x:num="118420.61316994125"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>118.421 </td>
      <td class="xl3115" x:num="150764"><span style='mso-spacerun:yes'>&nbsp; </span>150.764 </td>
      <td class="xl372" align="right" x:num="154850">154.850</td>
      <td class="xl372" align="right" x:num="154850">155.140</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>S&atilde;o Rafael</td>
      <td class="xl3115" x:num="2784.6133351876128"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>2.785 </td>
      <td class="xl3115" x:num="6107.4539775211424"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>6.107 </td>
      <td class="xl3115" x:num="32751.135638957578"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>32.751 </td>
      <td class="xl3115" x:num="70443.00111420863"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>70.443 </td>
      <td class="xl3115" x:num="89862"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>89.862 </td>
      <td class="xl372" align="right" x:num="125088">125.088</td>
      <td class="xl372" align="right" x:num="125088">143.992</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>S&atilde;o Miguel</td>
      <td class="xl2915" x:num="12063.620288946215"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>12.064 </td>
      <td class="xl2915" x:num="40455.801704431142"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>40.456 </td>
      <td class="xl2915" x:num="138084.69992957555"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>138.085 </td>
      <td class="xl2915" x:num="260942.28414444072"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>260.942 </td>
      <td class="xl2915" x:num="322581"><span style='mso-spacerun:yes'>&nbsp; </span>322.581 </td>
      <td class="xl354" align="right" x:num="378438">378.438</td>
      <td class="xl354" align="right" x:num="378438">369.496</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Jardim Helena</td>
      <td class="xl3115" x:num="3841.1254150571576"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>3.841 </td>
      <td class="xl3115" x:num="13542.015394679103"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>13.542 </td>
      <td class="xl3115" x:num="48254.529196736279"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>48.255 </td>
      <td class="xl3115" x:num="91079.287561410107"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>91.079 </td>
      <td class="xl3115" x:num="118381"><span style='mso-spacerun:yes'>&nbsp; </span>118.381 </td>
      <td class="xl372" align="right" x:num="139106">139.106</td>
      <td class="xl372" align="right" x:num="139106">135.043</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt' x:str="S&atilde;o Miguel ">S&atilde;o
        Miguel<span style='mso-spacerun:yes'>&nbsp;</span></td>
      <td class="xl3115" x:num="4008.2512597582581"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>4.008 </td>
      <td class="xl3115" x:num="12051.707802542582"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>12.052 </td>
      <td class="xl3115" x:num="49858.786963757178"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>49.859 </td>
      <td class="xl3115" x:num="100181.70395351714"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>100.182 </td>
      <td class="xl3115" x:num="102964"><span style='mso-spacerun:yes'>&nbsp; </span>102.964 </td>
      <td class="xl372" align="right" x:num="97373">97.373</td>
      <td class="xl372" align="right" x:num="97373">92.081</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Vila Jacu&iacute;</td>
      <td class="xl3115" x:num="4214.2436141307981"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>4.214 </td>
      <td class="xl3115" x:num="14862.07850720946"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>14.862 </td>
      <td class="xl3115" x:num="39971.383769082109"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>39.971 </td>
      <td class="xl3115" x:num="69681.292629513482"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>69.681 </td>
      <td class="xl3115" x:num="101236"><span style='mso-spacerun:yes'>&nbsp; </span>101.236 </td>
      <td class="xl372" align="right" x:num="141959">141.959</td>
      <td class="xl372" align="right" x:num="141959">142.372</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>S&eacute;</td>
      <td class="xl2915" x:num="350946.88380054466"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>350.947 </td>
      <td class="xl2915" x:num="432707.50304802251"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>432.708 </td>
      <td class="xl2915" x:num="445174.51602287369"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>445.175 </td>
      <td class="xl2915" x:num="526170.18076329783"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>526.170 </td>
      <td class="xl2915" x:num="458677"><span style='mso-spacerun:yes'>&nbsp; </span>458.677 </td>
      <td class="xl354" align="right" x:num="373914">373.914</td>
      <td class="xl354" align="right" x:num="373914">431.106</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Bela Vista</td>
      <td class="xl3115" x:num="46339.997886580335"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>46.340 </td>
      <td class="xl3115" x:num="57363.949979456731"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>57.364 </td>
      <td class="xl3115" x:num="64703.704723953037"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>64.704 </td>
      <td class="xl3115" x:num="85415.584078499189"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>85.416 </td>
      <td class="xl3115" x:num="71825"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>71.825 </td>
      <td class="xl372" align="right" x:num="63190">63.190</td>
      <td class="xl372" align="right" x:num="63190">69.460</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Bom Retiro</td>
      <td class="xl3115" x:num="45879.845543089432"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>45.880 </td>
      <td class="xl3115" x:num="53893.178144013167"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>53.893 </td>
      <td class="xl3115" x:num="45662.220161347279"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>45.662 </td>
      <td class="xl3115" x:num="47587.737581329442"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>47.588 </td>
      <td class="xl3115" x:num="36136"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>36.136 </td>
      <td class="xl372" align="right" x:num="26598">26.598</td>
      <td class="xl372" align="right" x:num="26598">33.892</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Cambuci</td>
      <td class="xl3115" x:num="35499.388597158606"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>35.499 </td>
      <td class="xl3115" x:num="39788.655065459381"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>39.789 </td>
      <td class="xl3115" x:num="39727.196466868016"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>39.727 </td>
      <td class="xl3115" x:num="44850.598276457786"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>44.851 </td>
      <td class="xl3115" x:num="37069"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>37.069 </td>
      <td class="xl372" align="right" x:num="28717">28.717</td>
      <td class="xl372" align="right" x:num="28717">36.948</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Consola&ccedil;&atilde;o</td>
      <td class="xl3115" x:num="38228.145800978979"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>38.228 </td>
      <td class="xl3115" x:num="52181.886688710489"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>52.182 </td>
      <td class="xl3115" x:num="60600.336983777772"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>60.600 </td>
      <td class="xl3115" x:num="77338.467396712076"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>77.338 </td>
      <td class="xl3115" x:num="66590"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>66.590 </td>
      <td class="xl372" align="right" x:num="54522">54.522</td>
      <td class="xl372" align="right" x:num="54522">57.365</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Liberdade</td>
      <td class="xl3115" x:num="55522.580211608911"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>55.523 </td>
      <td class="xl3115" x:num="68209.872397503874"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>68.210 </td>
      <td class="xl3115" x:num="71502.971923543912"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>71.503 </td>
      <td class="xl3115" x:num="82471.98168435492"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>82.472 </td>
      <td class="xl3115" x:num="76245"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>76.245 </td>
      <td class="xl372" align="right" x:num="61875">61.875</td>
      <td class="xl372" align="right" x:num="61875">69.092</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Rep&uacute;blica</td>
      <td class="xl3115" x:num="35994.44359516797"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>35.994 </td>
      <td class="xl3115" x:num="48346.491922973051"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>48.346 </td>
      <td class="xl3115" x:num="50347.837229237273"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>50.348 </td>
      <td class="xl3115" x:num="60998.818151994965"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>60.999 </td>
      <td class="xl3115" x:num="57797"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>57.797 </td>
      <td class="xl372" align="right" x:num="47718">47.718</td>
      <td class="xl372" align="right" x:num="47718">56.981</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Santa Cec&iacute;lia</td>
      <td class="xl3115" x:num="63460.036179778945"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>63.460 </td>
      <td class="xl3115" x:num="80580.615604504244"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>80.581 </td>
      <td class="xl3115" x:num="83074.888541298074"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>83.075 </td>
      <td class="xl3115" x:num="94542.054422754503"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>94.542 </td>
      <td class="xl3115" x:num="85829"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>85.829 </td>
      <td class="xl372" align="right" x:num="71179">71.179</td>
      <td class="xl372" align="right" x:num="71179">83.717</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>S&eacute;</td>
      <td class="xl3115" x:num="30022.445986181476"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>30.022 </td>
      <td class="xl3115" x:num="32342.853245401519"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>32.343 </td>
      <td class="xl3115" x:num="29555.359992848364"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>29.555 </td>
      <td class="xl3115" x:num="32964.939171194936"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>32.965 </td>
      <td class="xl3115" x:num="27186"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>27.186 </td>
      <td class="xl372" align="right" x:num="20115">20.115</td>
      <td class="xl372" align="right" x:num="20115">23.651</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Vila Maria/Vila Guilherme</td>
      <td class="xl2915" x:num="79608.529905880758"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>79.609 </td>
      <td class="xl2915" x:num="182670.79704078622"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>182.671 </td>
      <td class="xl2915" x:num="286929.18514745298"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>286.929 </td>
      <td class="xl2915" x:num="362503.08135445853"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>362.503 </td>
      <td class="xl2915" x:num="340427"><span style='mso-spacerun:yes'>&nbsp; </span>340.427 </td>
      <td class="xl354" align="right" x:num="304393">304.393</td>
      <td class="xl354" align="right" x:num="304393">297.713</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Vila Guilherme</td>
      <td class="xl3115" x:num="15079.285218454421"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>15.079 </td>
      <td class="xl3115" x:num="33602.595952376156"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>33.603 </td>
      <td class="xl3115" x:num="55020.564809622061"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>55.021 </td>
      <td class="xl3115" x:num="68410.442157679994"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>68.410 </td>
      <td class="xl3115" x:num="61625"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>61.625 </td>
      <td class="xl372" align="right" x:num="49984">49.984</td>
      <td class="xl372" align="right" x:num="49984">54.331</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Vila Maria</td>
      <td class="xl3115" x:num="32370.592410902642"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>32.371 </td>
      <td class="xl3115" x:num="70710.804566777893"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>70.711 </td>
      <td class="xl3115" x:num="105878.92604486954"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>105.879 </td>
      <td class="xl3115" x:num="132081.25349414503"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>132.081 </td>
      <td class="xl3115" x:num="122662"><span style='mso-spacerun:yes'>&nbsp; </span>122.662 </td>
      <td class="xl372" align="right" x:num="113845">113.845</td>
      <td class="xl372" align="right" x:num="113845">113.463</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Vila Medeiros</td>
      <td class="xl3115" x:num="32158.652276523699"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>32.159 </td>
      <td class="xl3115" x:num="78357.396521632167"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>78.357 </td>
      <td class="xl3115" x:num="126029.69429296136"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>126.030 </td>
      <td class="xl3115" x:num="162011.3857026335"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>162.011 </td>
      <td class="xl3115" x:num="156140"><span style='mso-spacerun:yes'>&nbsp; </span>156.140 </td>
      <td class="xl372" align="right" x:num="140564">140.564</td>
      <td class="xl372" align="right" x:num="140564">129.919</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Vila Mariana</td>
      <td class="xl2915" x:num="117435.66458980669"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>117.436 </td>
      <td class="xl2915" x:num="201477.04729194456"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>201.477 </td>
      <td class="xl2915" x:num="278005.25457327254"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>278.005 </td>
      <td class="xl2915" x:num="351604.63653528085"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>351.605 </td>
      <td class="xl2915" x:num="336758"><span style='mso-spacerun:yes'>&nbsp; </span>336.758 </td>
      <td class="xl354" align="right" x:num="313036">313.036</td>
      <td class="xl354" align="right" x:num="313036">344.632</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Moema</td>
      <td class="xl3115" x:num="33988.166230025512"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>33.988 </td>
      <td class="xl3115" x:num="49619.94893614592"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>49.620 </td>
      <td class="xl3115" x:num="57374.86419450352"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>57.375 </td>
      <td class="xl3115" x:num="72161.85644480362"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>72.162 </td>
      <td class="xl3115" x:num="77340"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>77.340 </td>
      <td class="xl372" align="right" x:num="71276">71.276</td>
      <td class="xl372" align="right" x:num="71276">83.368</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Sa&uacute;de</td>
      <td class="xl3115" x:num="29010.754288570184"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>29.011 </td>
      <td class="xl3115" x:num="63138.776236918042"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>63.139 </td>
      <td class="xl3115" x:num="104871.94033200473"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>104.872 </td>
      <td class="xl3115" x:num="136220.53775965946"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>136.221 </td>
      <td class="xl3115" x:num="126596"><span style='mso-spacerun:yes'>&nbsp; </span>126.596 </td>
      <td class="xl372" align="right" x:num="118077">118.077</td>
      <td class="xl372" align="right" x:num="118077">130.780</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Vila Mariana</td>
      <td class="xl3115" x:num="54436.744071210989"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>54.437 </td>
      <td class="xl3115" x:num="88718.322118880591"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>88.718 </td>
      <td class="xl3115" x:num="115758.45004676428"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>115.758 </td>
      <td class="xl3115" x:num="143222.2423308178"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>143.222 </td>
      <td class="xl3115" x:num="132822"><span style='mso-spacerun:yes'>&nbsp; </span>132.822 </td>
      <td class="xl372" align="right" x:num="123683">123.683</td>
      <td class="xl372" align="right" x:num="123683">130.484</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl364" style='height:12.75pt'>Vila Prudente/Sapopemba</td>
      <td class="xl2915" x:num="96579.294013957377"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>96.579 </td>
      <td class="xl2915" x:num="179688.61545804763"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>179.689 </td>
      <td class="xl2915" x:num="322393.05231606989"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>322.393 </td>
      <td class="xl2915" x:num="460196.2035086361"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>460.196 </td>
      <td class="xl2915" x:num="523950"><span style='mso-spacerun:yes'>&nbsp; </span>523.950 </td>
      <td class="xl354" align="right" x:num="523676">523.676</td>
      <td class="xl354" align="right" x:num="523676">531.113</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>S&atilde;o Lucas</td>
      <td class="xl3115" x:num="29536.083062912265"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>29.536 </td>
      <td class="xl3115" x:num="62556.590022865457"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>62.557 </td>
      <td class="xl3115" x:num="113504.20899564934"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>113.504 </td>
      <td class="xl3115" x:num="156429.86655622919"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>156.430 </td>
      <td class="xl3115" x:num="152036"><span style='mso-spacerun:yes'>&nbsp; </span>152.036 </td>
      <td class="xl372" align="right" x:num="139333">139.333</td>
      <td class="xl372" align="right" x:num="139333">142.347</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3015" style='height:12.75pt'>Sapopemba</td>
      <td class="xl3115" x:num="20806.214526349031"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>20.806 </td>
      <td class="xl3115" x:num="44325.660442172266"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>44.326 </td>
      <td class="xl3115" x:num="107192.33160290297"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>107.192 </td>
      <td class="xl3115" x:num="178989.46692728589"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>178.989 </td>
      <td class="xl3115" x:num="257617"><span style='mso-spacerun:yes'>&nbsp; </span>257.617 </td>
      <td class="xl372" align="right" x:num="282239">282.239</td>
      <td class="xl372" align="right" x:num="282239">284.524</td>
    </tr>
    <tr height="18" style='height:13.5pt'>
      <td height="18" class="xl3213" style='height:13.5pt'>Vila Prudente</td>
      <td class="xl338" x:num="46236.996424696074"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>46.237 </td>
      <td class="xl338" x:num="72806.364993009905"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>72.806 </td>
      <td class="xl338" x:num="101696.51171751757"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>101.697 </td>
      <td class="xl338" x:num="124776.87002512102"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp; </span>124.777 </td>
      <td class="xl338" x:num="114297"><span style='mso-spacerun:yes'>&nbsp; </span>114.297 </td>
      <td class="xl382" align="right" x:num="102104">102.104</td>
      <td class="xl382" align="right" x:num="102104">104.242</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td colspan="8" height="17" class="xl391" style='height:12.75pt'>Fonte: IBGE -
        Censos Demogr&aacute;ficos, 1950, 1960, 1970, 1980, 1991, 2000, 2010</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td colspan="8" height="17" class="xl402" style='height:12.75pt'><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Sinopses Preliminares dos Censos
        Demogr&aacute;ficos de 1950 e 1960</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td colspan="8" height="17" class="xl402" style='height:12.75pt'
  x:str="           Sempla/Dipro - Retroestimativas e Recomposi&ccedil;&atilde;o dos Distritos para os anos 1950,1960 e 1970 "><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>SMDU / Dipro - Retroestimativas e
        Recomposi&ccedil;&atilde;o dos Distritos para os anos 1950,1960 e 1970<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
    </tr>
        <tr height="17" style='height:12.75pt'>
      <td colspan="8" height="17" class="xl402" style='height:12.75pt'
  x:str="           Sempla/Dipro - Retroestimativas e Recomposi&ccedil;&atilde;o dos Distritos para os anos 1950,1960 e 1970 "><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Elabora&ccedil;&atilde;o<span
  style='mso-spacerun:yes'>: Secretaria Municipal de Desenvolvimento Urbano / SMDU - Departamento de Estat&iacute;stica e Produ&ccedil;&atilde;o de Informa&ccedil;&atilde;o / Dipro</span></td>
    </tr>
    <![if supportMisalignedColumns]>
    <tr height="0" style='display:none'>
      <td width="189" style='width:142pt'></td>
      <td width="72" style='width:54pt'></td>
      <td width="72" style='width:54pt'></td>
      <td width="72" style='width:54pt'></td>
      <td width="72" style='width:54pt'></td>
      <td width="64" style='width:48pt'></td>
      <td width="71" style='width:53pt'></td>
      <td width="71" style='width:53pt'></td>
    </tr>
    <![endif]>
  </table>
  <p>&nbsp;</p>
  <p><strong><img src="../img/seta-download.gif" width="11" height="12" /></strong><strong> </strong><a href="xls/pop_dist.xls" title="Clique para baixar a tabela no formato Excel (.xls)"><strong>FORMATO EXCEL (.XLS)</strong></a></p>
  <p align="center">  </p>
  <p align="center">  </p>
  <p align="center">  </p>
  <p align="center">  </p>
  <p align="center">  </p>
  <p align="center">  </p>
  <p align="center">  </p>
  <p align="center">  </p>
  <p align="center">  </p>
  <p align="center"></p>
</div>

</div>

<td><div id="assinatura">
<div style="text-align:center"><div>
</div></td>

</body>
</html>
