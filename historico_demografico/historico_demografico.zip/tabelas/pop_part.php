<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Hist&oacute;rico Demogr&aacute;fico do Munic&iacute;pio de S&atilde;o Paulo</title>
<link rel="stylesheet" type="text/css" href="../estilo_padrao.css">
<script language="JavaScript1.2" src="../funcoes.js"></script><style type="text/css">
<!--
.xl24 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl25 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl26 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl27 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl28 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl29 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl30 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl31 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl32 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl241 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl242 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl243 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl244 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl251 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl261 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl271 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl281 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl291 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl301 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl311 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl321 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl252 {mso-style-parent:style20;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl262 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl272 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl282 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;
	mso-protection:unlocked visible;}
.xl292 {mso-style-parent:style22;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0\.0_\)\;_\(* \\\(\#\,\#\#0\.0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl302 {mso-style-parent:style22;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0\.0_\)\;_\(* \\\(\#\,\#\#0\.0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:right;}
.xl312 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl322 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl33 {mso-style-parent:style22;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0\.0_\)\;_\(* \\\(\#\,\#\#0\.0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:right;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl34 {mso-style-parent:style22;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0\.0_\)\;_\(* \\\(\#\,\#\#0\.0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl35 {mso-style-parent:style20;
	color:black;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl36 {mso-style-parent:style20;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl37 {mso-style-parent:style20;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;
	mso-protection:unlocked visible;}
.xl40 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;}
.xl42 {mso-style-parent:style20;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;}
.xl3221 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl341 {mso-style-parent:style22;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0\.0_\)\;_\(* \\\(\#\,\#\#0\.0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
-->
</style>
</head>

<body onload="MM_preloadImages('../img/botao_apresentacao_2.jpg','../img/botao_introducao_2.jpg','../img/botao_equipe_2.jpg','../img/botao_dados_2.jpg')">

<div id="geral">

<table align="center" border="0" cellpadding="0" cellspacing="0" width="780">

    <tr><td><div id="header_prefeitura">
</div></div>
</div></td></tr>

    <tr><td><table width="778" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td><div id="tarja_laranja"> <a href="../index.php" title="Voltar para a p&aacute;gina inicial">
		<h1 class="semestilo">Hist&oacute;ria Demogr&aacute;fica do Munic&iacute;pio de S&atilde;o Paulo</h1>
		</a> </div></td>
		<td align="right">
		
		<a href="../index.php"><img src="../img/botao_apresentacao_1.jpg" alt="P&aacute;gina Inicial" name="Image1" width="103" height="35" border="0" id="Image1" title="Página Inicial" onMouseOver="MM_swapImage('Image1','','../img/botao_apresentacao_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a><a href="../introducao.php"><img src="../img/botao_introducao_1.jpg" alt="Introdu&ccedil;&atilde;o" name="Image2" width="85" height="35" border="0" id="Image2" title="Introdu&ccedil;&atilde;o" onMouseOver="MM_swapImage('Image2','','../img/botao_introducao_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a><a href="../equipe.php"><img src="../img/botao_equipe_1.jpg" alt="Equipe T&eacute;cnica" name="Image3" width="108" height="35" border="0" id="Image3" title="Equipe T&eacute;cnica" onMouseOver="MM_swapImage('Image3','','../img/botao_equipe_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a><a href="../tabelas.php"><img src="../img/botao_dados_1.jpg" alt="Tabelas" name="Image4" width="76" height="35" border="0" id="Image4" title="Tabelas" onMouseOver="MM_swapImage('Image4','','../img/botao_dados_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a></td>
	</tr>
</table></td></tr>
	  
</table>

<div id="conteudo"> 
  <h1>Tabelas</h1>
  <p>&nbsp;</p>
  <table x:str="x:str" border="0" cellpadding="0" cellspacing="0" width="535" style='border-collapse:
 collapse;table-layout:fixed;width:401pt'>
    <col class="xl262" width="47" style='mso-width-source:userset;mso-width-alt:1718;
 width:35pt' />
    <col class="xl262" width="216" style='mso-width-source:userset;mso-width-alt:7899;
 width:162pt' />
    <col class="xl262" width="136" span="2" style='mso-width-source:userset;mso-width-alt:
 4973;width:102pt' />
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl252" colspan="4" width="535" style='height:12.75pt;
  mso-ignore:colspan;width:401pt'>Participa&ccedil;&atilde;o do Munic&iacute;pio de S&atilde;o Paulo no
        Total da Popula&ccedil;&atilde;o</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl252" colspan="4" style='height:12.75pt;mso-ignore:colspan'>Munic&iacute;pio
        e Regi&atilde;o Metropolitana de S&atilde;o Paulo, Estado de S&atilde;o Paulo e Brasil</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl252" colspan="2" style='height:12.75pt;mso-ignore:colspan'>1872
        a 2010</td>
      <td colspan="2" class="xl262" style='mso-ignore:colspan'></td>
    </tr>
    <tr height="18" style='height:13.5pt'>
      <td height="18" class="xl272" style='height:13.5pt'>&nbsp;</td>
      <td class="xl272">&nbsp;</td>
      <td class="xl272">&nbsp;</td>
      <td class="xl272">&nbsp;</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td rowspan="4" height="69" class="xl37" style='border-bottom:1.0pt solid black;
  height:51.75pt;border-top:none'>Anos</td>
      <td rowspan="2" class="xl40" style='border-top:none'>Regi&atilde;o Metropolitana de S&atilde;o
        Paulo</td>
      <td rowspan="2" class="xl40" style='border-top:none' x:str="Estado de S&atilde;o Paulo ">Estado
        de S&atilde;o Paulo<span style='mso-spacerun:yes'>&nbsp;</span></td>
      <td rowspan="2" class="xl40" style='border-top:none' x:str="Estado de S&atilde;o Paulo ">Brasil<span style='mso-spacerun:yes'></span></td>
    </tr>
    <tr height="17" style='height:12.75pt'> </tr>
    <tr height="17" style='height:12.75pt'>
      <td rowspan="2" height="35" class="xl42" style='border-bottom:1.0pt solid black;
  height:26.25pt'>Participa&ccedil;&atilde;o (%)</td>
      <td rowspan="2" class="xl42" style='border-bottom:1.0pt solid black'>Participa&ccedil;&atilde;o
        (%)</td>
      <td rowspan="2" class="xl42" style='border-bottom:1.0pt solid black'>Participa&ccedil;&atilde;o
        (%)</td>
    </tr>
    <tr height="18" style='height:13.5pt'> </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" align="center" class="xl282" style='height:12.75pt' x:num="x:num">1872</td>
      <td align="center" class="xl292" x:str="-"><div align="center"><span style='mso-spacerun:yes'>&nbsp;</span>-<span
  style='mso-spacerun:yes'>&nbsp;</span></div></td>
      <td align="center" class="xl292" x:num="3.7481160894914218">3,7 </td>
      <td align="center" class="xl302" x:num="0.31037194099204901"><div align="center">0,3 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" align="center" class="xl282" style='height:12.75pt' x:num="x:num">1890</td>
      <td align="center" class="xl292" x:str="-"><div align="center"><span style='mso-spacerun:yes'>&nbsp;</span>-<span
  style='mso-spacerun:yes'>&nbsp;</span></div></td>
      <td align="center" class="xl292" x:num="4.6892117222349396">4,7 </td>
      <td align="center" class="xl302" x:num="0.45300952321818566"><div align="center">0,5 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" align="center" class="xl282" style='height:12.75pt' x:num="x:num">1900</td>
      <td align="center" class="xl292" x:str="-"><div align="center"><span style='mso-spacerun:yes'>&nbsp;</span>-<span
  style='mso-spacerun:yes'>&nbsp;</span></div></td>
      <td align="center" class="xl292" x:num="10.507917743623807">10,5 </td>
      <td align="center" class="xl302" x:num="1.3847574820903084"><div align="center">1,4 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" align="center" class="xl282" style='height:12.75pt' x:num="x:num">1920</td>
      <td align="center" class="xl292" x:str="-"><div align="center"><span style='mso-spacerun:yes'>&nbsp;</span>-<span
  style='mso-spacerun:yes'>&nbsp;</span></div></td>
      <td align="center" class="xl292" x:num="12.609087432831585"><span
  style='mso-spacerun:yes'>1</span>2,6 </td>
      <td align="center" class="xl302" x:num="1.8900654973192141"><div align="center">1,9 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" align="center" class="xl282" style='height:12.75pt' x:num="x:num">1940</td>
      <td align="center" class="xl292" x:num="84.580544563453216"><div align="center">84,6</div></td>
      <td align="center" class="xl292" x:num="18.4707887508015">18,5 </td>
      <td align="center" class="xl302" x:num="3.2162451955272919"><div align="center">3,2 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" align="center" class="xl282" style='height:12.75pt' x:num="x:num">1950</td>
      <td align="center" class="xl302" x:num="83.807676264857292"><div align="center">83,8 </div></td>
      <td align="center" class="xl292" x:num="24.063873547349406">24,1 </td>
      <td align="center" class="xl302" x:num="4.231632528143507"><div align="center">4,2 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" align="center" class="xl282" style='height:12.75pt' x:num="x:num">1960</td>
      <td align="center" class="xl302" x:num="79.787340438865129"><div align="center">79,8 </div></td>
      <td align="center" class="xl292" x:num="29.144768599256139">29,1 </td>
      <td align="center" class="xl302" x:num="5.3928923273954954"><div align="center">5,4 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" align="center" class="xl282" style='height:12.75pt' x:num="x:num">1970</td>
      <td align="center" class="xl302" x:num="72.786382349291685"><div align="center">72,8 </div></td>
      <td align="center" class="xl292" x:num="33.33689137510418">33,3 </td>
      <td align="center" class="xl302" x:num="6.3610438660644517"><div align="center">6,4 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" align="center" class="xl282" style='height:12.75pt' x:num="x:num">1980</td>
      <td align="center" class="xl302" x:num="67.466927746852832"><div align="center">67,5 </div></td>
      <td align="center" class="xl292" x:num="33.917669753160375">33,9 </td>
      <td align="center" class="xl302" x:num="7.1370024140459467"><div align="center">7,1 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" align="center" class="xl312" style='height:12.75pt' x:num="x:num">1991</td>
      <td align="center" class="xl302" x:num="62.455304944188519"><div align="center">62,5 </div></td>
      <td align="center" class="xl292" x:num="30.53660420542959">30,5 </td>
      <td align="center" class="xl302" x:num="6.569830610117215"><div align="center">6,6 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" align="center" class="xl312" style='height:12.75pt' x:num="x:num">2000</td>
      <td align="center" class="xl302" x:num="62.455304944188519"><div align="center">58,4</div></td>
      <td align="center" class="xl292" x:num="30.53660420542959">28,2</td>
      <td align="center" class="xl302" x:num="6.569830610117215"><div align="center">6,1</div></td>
    </tr>
    <tr height="18" style='height:13.5pt'>
      <td height="18" align="center" class="xl322" style='height:13.5pt' x:num="x:num">2010</td>
      <td align="center" class="xl33" x:num="58.361347576499256"><div align="center">57,2</div></td>
      <td align="center" class="xl34" x:num="28.17600575366389">27,3 </td>
      <td align="center" class="xl33" x:num="6.1450547726470042"><div align="center">5,9 </div></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" colspan="2" align="center" class="xl35" style='height:12.75pt;mso-ignore:colspan'>Fonte:
        IBGE, Censos Demogr&aacute;ficos</td>
      <td colspan="2" align="center" class="xl262" style='mso-ignore:colspan'></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl36" colspan="2" style='height:12.75pt;mso-ignore:colspan'>(1)
        Taxa de Crescimento Geom&eacute;trico Anual</td>
      <td colspan="2" class="xl262" style='mso-ignore:colspan'></td>
    </tr>
    <![if supportMisalignedColumns]>
    <tr height="0" style='display:none'>
      <td width="47" style='width:35pt'></td>
      <td width="216" style='width:162pt'></td>
      <td width="136" style='width:102pt'></td>
      <td width="136" style='width:102pt'></td>
    </tr>
    <![endif]>
  </table>
  <p>&nbsp;</p>
  <p><strong><img src="../img/seta-download.gif" width="11" height="12" /></strong><strong> </strong><a href="xls/pop_part.xls" title="Clique para baixar a tabela no formato Excel (.xls)"><strong>FORMATO EXCEL (.XLS)</strong></a></p>
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">
</div>

</div>

<td><div id="assinatura">
<div style="text-align:center"><div>
</div></td>

</body>
</html>
