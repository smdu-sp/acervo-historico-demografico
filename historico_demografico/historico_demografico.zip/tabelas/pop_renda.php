<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Hist&oacute;rico Demogr&aacute;fico do Munic&iacute;pio de S&atilde;o Paulo</title>
<link rel="stylesheet" type="text/css" href="../estilo_padrao.css">
<script language="JavaScript1.2" src="../funcoes.js"></script><style type="text/css">
<!--
.xl24 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl25 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl26 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl27 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl28 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl29 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl30 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl31 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl32 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl241 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl242 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl243 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl244 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl251 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl261 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl271 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl281 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl291 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl301 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl311 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl321 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl252 {mso-style-parent:style20;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl262 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl272 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl282 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;
	mso-protection:unlocked visible;}
.xl292 {mso-style-parent:style22;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0\.0_\)\;_\(* \\\(\#\,\#\#0\.0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl302 {mso-style-parent:style22;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0\.0_\)\;_\(* \\\(\#\,\#\#0\.0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:right;}
.xl312 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl322 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl33 {mso-style-parent:style22;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0\.0_\)\;_\(* \\\(\#\,\#\#0\.0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:right;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl34 {mso-style-parent:style22;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0\.0_\)\;_\(* \\\(\#\,\#\#0\.0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl35 {mso-style-parent:style20;
	color:black;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl36 {mso-style-parent:style20;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl37 {mso-style-parent:style20;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;
	mso-protection:unlocked visible;}
.xl40 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;}
.xl42 {mso-style-parent:style20;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;}
.font5452 {color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Univers, sans-serif;
	mso-font-charset:0;}
.font6452 {color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Univers;
	mso-generic-font-family:auto;
	mso-font-charset:0;}
.xl15452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Arial;
	mso-generic-font-family:auto;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:general;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl22452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:9.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:Univers, sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:center;
	vertical-align:middle;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl23452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:7.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Univers, sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:center;
	vertical-align:middle;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:normal;}
.xl24452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:Univers, sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:left;
	vertical-align:middle;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl26452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Univers, sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:center;
	vertical-align:middle;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:normal;}
.xl27452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Univers, sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:normal;}
.xl28452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Univers, sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:normal;}
.xl29452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:Univers, sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:left;
	vertical-align:middle;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl30452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:7.0pt;
	font-weight:400;
	font-style:italic;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:general;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl31452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:7.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:general;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl32452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:7.0pt;
	font-weight:400;
	font-style:italic;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:0;
	text-align:general;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl33452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:black;
	font-size:7.0pt;
	font-weight:400;
	font-style:italic;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:general;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl34452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:general;
	vertical-align:bottom;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl35452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:general;
	vertical-align:bottom;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl36452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Univers, sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:normal;}
.xl37452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Univers;
	mso-generic-font-family:auto;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:general;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl38452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Univers;
	mso-generic-font-family:auto;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:general;
	vertical-align:bottom;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl39452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Univers;
	mso-generic-font-family:auto;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	vertical-align:bottom;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl40452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Univers;
	mso-generic-font-family:auto;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	vertical-align:bottom;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl41452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Univers, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	vertical-align:bottom;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl42452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Univers, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	vertical-align:bottom;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl43452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Univers;
	mso-generic-font-family:auto;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:general;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl44452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Univers;
	mso-generic-font-family:auto;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:general;
	vertical-align:bottom;
	border-top:none;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl45452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Univers, sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:normal;}
.xl47452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Univers;
	mso-generic-font-family:auto;
	mso-font-charset:0;
	mso-number-format:Standard;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl49452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Univers;
	mso-generic-font-family:auto;
	mso-font-charset:0;
	mso-number-format:"\#\#\#\\ \#\#\#\\ \#\#\#\\ \#\#0\.00_ \;\\-\#\#\#\\ \#\#\#\\ \#\#\#\\ \#\#0_ \;\0022- \0022";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl51452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Univers, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\#\#\\ \#\#\#\\ \#\#\#\\ \#\#0_ \;\\-\#\#\#\\ \#\#\#\\ \#\#\#\\ \#\#0_ \;\0022- \0022";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl53452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Univers, sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:normal;}
.xl56452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Univers;
	mso-generic-font-family:auto;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl58452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Univers;
	mso-generic-font-family:auto;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl61452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl64452 {padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Univers, sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:normal;}
-->
</style>
</head>

<body onload="MM_preloadImages('../img/botao_apresentacao_2.jpg','../img/botao_introducao_2.jpg','../img/botao_equipe_2.jpg','../img/botao_dados_2.jpg')">

<div id="geral">

<table align="center" border="0" cellpadding="0" cellspacing="0" width="780">

    <tr><td><div id="header_prefeitura">
</div></div>
</div></td></tr>

    <tr><td><table width="778" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td><div id="tarja_laranja"> <a href="../index.php" title="Voltar para a p&aacute;gina inicial">
		<h1 class="semestilo">Hist&oacute;ria Demogr&aacute;fica do Munic&iacute;pio de S&atilde;o Paulo</h1>
		</a> </div></td>
		<td align="right">
		
		<a href="../index.php"><img src="../img/botao_apresentacao_1.jpg" alt="P&aacute;gina Inicial" name="Image1" width="103" height="35" border="0" id="Image1" title="Página Inicial" onMouseOver="MM_swapImage('Image1','','../img/botao_apresentacao_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a><a href="../introducao.php"><img src="../img/botao_introducao_1.jpg" alt="Introdu&ccedil;&atilde;o" name="Image2" width="85" height="35" border="0" id="Image2" title="Introdu&ccedil;&atilde;o" onMouseOver="MM_swapImage('Image2','','../img/botao_introducao_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a><a href="../equipe.php"><img src="../img/botao_equipe_1.jpg" alt="Equipe T&eacute;cnica" name="Image3" width="108" height="35" border="0" id="Image3" title="Equipe T&eacute;cnica" onMouseOver="MM_swapImage('Image3','','../img/botao_equipe_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a><a href="../tabelas.php"><img src="../img/botao_dados_1.jpg" alt="Tabelas" name="Image4" width="76" height="35" border="0" id="Image4" title="Tabelas" onMouseOver="MM_swapImage('Image4','','../img/botao_dados_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a></td>
	</tr>
</table></td></tr>
	  
</table>

<div id="conteudo"> 
  <h1>Tabelas</h1>
  <p>&nbsp;</p>
  <table x:str="x:str" border="0" cellpadding="0" cellspacing="0" width="472" style='border-collapse:
 collapse;table-layout:fixed;width:355pt'>
    <col width="145" style='mso-width-source:userset;mso-width-alt:5302;width:109pt' />
    <col width="91" style='mso-width-source:userset;mso-width-alt:3328;width:68pt' />
    <col width="86" span="2" style='mso-width-source:userset;mso-width-alt:3145;
 width:65pt' />
    <col width="64" style='width:48pt' />
    <tr height="20" style='mso-height-source:userset;height:15.0pt'>
      <td height="20" class="xl29452" colspan="4" width="408" style='height:15.0pt;
  width:307pt' x:str="Domic&iacute;lios  e Moradores segundo Classes de Rendimento ">Domic&iacute;lios<span
  style='mso-spacerun:yes'>&nbsp; </span>e Moradores segundo Classes de
        Rendimento<span style='mso-spacerun:yes'>&nbsp;</span></td>
      <td width="64" style='width:48pt'></td>
    </tr>
    <tr height="20" style='mso-height-source:userset;height:15.0pt'>
      <td height="20" class="xl29452" colspan="5" style='height:15.0pt'
  x:str="Nominal Mensal da Pessoa Respons&aacute;vel pelo Domic&iacute;lio                                                         ">Nominal
        Mensal da Pessoa Respons&aacute;vel pelo Domic&iacute;lio<span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span
  style='display:none'><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span></td>
    </tr>
    <tr height="20" style='mso-height-source:userset;height:15.0pt'>
      <td height="20" class="xl29452" colspan="2" style='height:15.0pt'
  x:str="Munic&iacute;pio de S&atilde;o Paulo ">Munic&iacute;pio de S&atilde;o Paulo<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td class="xl26452" width="86" style='width:65pt'></td>
      <td class="xl26452" width="86" style='width:65pt'></td>
      <td width="64" style='width:48pt'></td>
    </tr>
    <tr height="20" style='mso-height-source:userset;height:15.0pt'>
      <td height="20" class="xl29452" style='height:15.0pt'>1991 e 2000</td>
      <td class="xl26452" width="91" style='width:68pt'></td>
      <td class="xl26452" width="86" style='width:65pt'></td>
      <td class="xl26452" width="86" style='width:65pt'></td>
      <td width="64" style='width:48pt'></td>
    </tr>
    <tr height="20" style='mso-height-source:userset;height:15.0pt'>
      <td height="20" class="xl24452" style='height:15.0pt'></td>
      <td class="xl26452" width="91" style='width:68pt'></td>
      <td class="xl26452" width="86" style='width:65pt'></td>
      <td class="xl26452" width="86" style='width:65pt'></td>
      <td width="64" style='width:48pt'></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td colspan="2" rowspan="2" height="34" class="xl58452" style='border-bottom:.5pt solid black;
  height:25.5pt' x:str="Classes  de Rendimento ">Classes<span
  style='mso-spacerun:yes'>&nbsp; </span>de Rendimento<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td rowspan="2" class="xl56452" style='border-bottom:.5pt solid black' x:num="x:num">1991</td>
      <td rowspan="2" class="xl56452" style='border-bottom:.5pt solid black' x:num="x:num">2000</td>
      <td></td>
    </tr>
    <tr height="17">
      <td height="17"></td>
    </tr>
    <tr height="17">
      <td rowspan="2" height="34" class="xl26452" width="145" style='border-bottom:.5pt solid black;
  height:25.5pt;width:109pt'>Total<font class="font6452"><sup>(1)</sup></font></td>
      <td class="xl36452" width="91" style='width:68pt'>Domic&iacute;lios</td>
      <td align="center" class="xl43452" x:num="2539953"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>2.539.953</td>
      <td class="xl44452" x:num="2985977"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>2.985.977 </td>
      <td></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl28452" width="91" style='height:12.75pt;width:68pt'>Moradores</td>
      <td align="center" class="xl37452" x:num="9527426"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>9.527.426</td>
      <td class="xl38452" x:num="10338932"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>10.338.932 </td>
      <td></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td rowspan="2" height="34" class="xl64452" width="145" style='border-bottom:.5pt solid black;
  height:25.5pt;border-top:none;width:109pt'>Rendimento</td>
      <td rowspan="2" class="xl45452" width="91" style='border-bottom:.5pt solid black;
  border-top:none;width:68pt'>M&eacute;dio<font class="font6452"><sup>(2)</sup></font></td>
      <td rowspan="2" class="xl47452" style='border-bottom:.5pt solid black;border-top:
  none' x:num="258946.1">258.946,10</td>
      <td rowspan="2" class="xl49452" style='border-bottom:.5pt solid black;border-top:
  none' x:num="1479.69"><span style='mso-spacerun:yes'>&nbsp; </span>1 479,69 </td>
      <td></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl15452" style='height:12.75pt'></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td rowspan="2" height="34" class="xl53452" width="145" style='border-bottom:.5pt solid black;
  height:25.5pt;border-top:none;width:109pt'>At&eacute;<span
  style='mso-spacerun:yes'>&nbsp; </span>1 s.m<font class="font6452"><sup>.(3)</sup></font></td>
      <td class="xl27452" width="91" style='border-top:none;width:68pt'>Domic&iacute;lios</td>
      <td align="center" class="xl34452" style='border-top:none' x:num="153894"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>153.894</td>
      <td class="xl39452" style='border-top:none' x:num="191484"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>191.484 </td>
      <td></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl28452" width="91" style='height:12.75pt;width:68pt'>Moradores</td>
      <td align="center" class="xl35452" x:num="523246"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>523.246 </td>
      <td class="xl40452" x:num="608815"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>608.815 </td>
      <td></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td rowspan="2" height="34" class="xl53452" width="145" style='border-bottom:.5pt solid black;
  height:25.5pt;border-top:none;width:109pt'>Mais de 1 at&eacute; 2 s. m.</td>
      <td class="xl27452" width="91" style='border-top:none;width:68pt'>Domic&iacute;lios</td>
      <td align="center" class="xl34452" style='border-top:none' x:num="409815"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>409.815</td>
      <td class="xl39452" style='border-top:none' x:num="342359"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>342.359 </td>
      <td></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl28452" width="91" style='height:12.75pt;width:68pt'>Moradores</td>
      <td align="center" class="xl35452" x:num="1536061"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>1.536.061</td>
      <td class="xl40452" x:num="1208022"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>1.208.022 </td>
      <td></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td rowspan="2" height="34" class="xl53452" width="145" style='border-bottom:.5pt solid black;
  height:25.5pt;border-top:none;width:109pt'
  x:str="Mais de
2 a 3 s.m.                                                                 ">Mais
        de<br />
        2 a 3 s.m. </td>
      <td class="xl27452" width="91" style='border-top:none;width:68pt'>Domic&iacute;lios</td>
      <td align="center" class="xl34452" style='border-top:none' x:num="379866"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>379.866</td>
      <td class="xl39452" style='border-top:none' x:num="350981"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>350.981 </td>
      <td></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl28452" width="91" style='height:12.75pt;width:68pt'>Moradores</td>
      <td align="center" class="xl35452" x:num="1468132"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>1.468.132</td>
      <td class="xl40452" x:num="1234346"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>1.234.346 </td>
      <td></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td rowspan="2" height="34" class="xl53452" width="145" style='border-bottom:.5pt solid black;
  height:25.5pt;border-top:none;width:109pt'
  x:str="Mais de
3 a 5 s.m.                                                                 ">Mais
        de<br />
        3 a 5 s.m. <span
  style='mso-spacerun:yes'></span></td>
      <td class="xl27452" width="91" style='border-top:none;width:68pt'>Domic&iacute;lios</td>
      <td align="center" class="xl34452" style='border-top:none' x:num="454781"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>454.781</td>
      <td class="xl39452" style='border-top:none' x:num="535157"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>535.157 </td>
      <td></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl28452" width="91" style='height:12.75pt;width:68pt'>Moradores</td>
      <td align="center" class="xl35452" x:num="1748761"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>1.748.761</td>
      <td class="xl40452" x:num="1898533"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>1.898.533 </td>
      <td></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td rowspan="2" height="34" class="xl53452" width="145" style='border-bottom:.5pt solid black;
  height:25.5pt;border-top:none;width:109pt'
  x:str="Mais de
5 a 10 s.m.                                                                ">Mais
        de<br />
        5 a 10 s.m.</td>
      <td class="xl27452" width="91" style='border-top:none;width:68pt'>Domic&iacute;lios</td>
      <td align="center" class="xl34452" style='border-top:none' x:num="512343"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>512.343</td>
      <td class="xl39452" style='border-top:none' x:num="625626"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>625.626 </td>
      <td></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl28452" width="91" style='height:12.75pt;width:68pt'>Moradores</td>
      <td align="center" class="xl35452" x:num="1928468"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>1.928.468</td>
      <td class="xl40452" x:num="2171250"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>2.171.250 </td>
      <td></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td rowspan="2" height="34" class="xl53452" width="145" style='border-bottom:.5pt solid black;
  height:25.5pt;border-top:none;width:109pt'
  x:str="Mais de
10 a 15 s.m.                                                                ">Mais
        de<br />
        10 a 15 s.m. <span
  style='mso-spacerun:yes'></span></td>
      <td class="xl27452" width="91" style='border-top:none;width:68pt'>Domic&iacute;lios</td>
      <td align="center" class="xl34452" style='border-top:none' x:num="197457"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>197.457</td>
      <td class="xl39452" style='border-top:none' x:num="191987"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>191.987 </td>
      <td></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl28452" width="91" style='height:12.75pt;width:68pt'>Moradores</td>
      <td align="center" class="xl35452" x:num="712733"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>712.733</td>
      <td class="xl40452" x:num="634757"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>634.757 </td>
      <td></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td rowspan="2" height="34" class="xl53452" width="145" style='border-bottom:.5pt solid black;
  height:25.5pt;border-top:none;width:109pt'
  x:str="Mais de
15 a 20 s.m.                                                                 ">Mais
        de<br />
        15 a 20 s.m.</td>
      <td class="xl27452" width="91" style='border-top:none;width:68pt'>Domic&iacute;lios</td>
      <td align="center" class="xl34452" style='border-top:none' x:num="90922"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>90.922</td>
      <td class="xl39452" style='border-top:none' x:num="155078"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>155.078 </td>
      <td></td>
    </tr>
    <tr height="17" style='mso-height-source:userset;height:12.75pt'>
      <td height="17" class="xl28452" width="91" style='height:12.75pt;width:68pt'>Moradores</td>
      <td align="center" class="xl35452" x:num="324397"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>324.397</td>
      <td class="xl40452" x:num="501503"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>501.503 </td>
      <td></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td rowspan="2" height="34" class="xl53452" width="145" style='border-bottom:.5pt solid black;
  height:25.5pt;border-top:none;width:109pt'
  x:str="Mais de
20 a 30 s.m.                                                                 ">Mais
        de<br />
        20 a 30 s.m. </td>
      <td rowspan="2" class="xl27452" width="91" style='border-bottom:.5pt solid black;
  border-top:none;width:68pt'>Domic&iacute;lios</td>
      <td rowspan="2" class="xl61452" style='border-bottom:.5pt solid black;border-top:
  none' x:num="179250"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>179.250</td>
      <td class="xl39452" style='border-top:none;border-left:none' x:num="103542"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>103.542 </td>
      <td></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl40452" style='height:12.75pt;border-left:none'
  x:num="326834"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>326.834 </td>
      <td></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td rowspan="2" height="34" class="xl53452" width="145" style='border-bottom:.5pt solid black;
  height:25.5pt;border-top:none;width:109pt'
  x:str="Mais de
30 s.m.                                                                     ">Mais
        de<br />
        30 s.m. </td>
      <td rowspan="2" class="xl27452" width="91" style='border-bottom:.5pt solid black;
  border-top:none;width:68pt'>Moradores</td>
      <td rowspan="2" class="xl61452" style='border-bottom:.5pt solid black;border-top:
  none' x:num="678022"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>678.022 </td>
      <td class="xl39452" style='border-top:none;border-left:none' x:num="178445"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>178.445 </td>
      <td></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl40452" style='height:12.75pt;border-left:none'
  x:num="598072"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>598.072 </td>
      <td></td>
    </tr>
    <tr height="17" style='mso-height-source:userset;height:12.75pt'>
      <td rowspan="2" height="34" class="xl51452" style='border-bottom:.5pt solid black;
  height:25.5pt;border-top:none'>Sem Rendimento <font class="font6452"><sup>(4)</sup></font></td>
      <td class="xl27452" width="91" style='border-top:none;border-left:none;
  width:68pt'>Domic&iacute;lios</td>
      <td align="center" class="xl34452" style='border-top:none' x:num="123638"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>123.638 </td>
      <td class="xl39452" style='border-top:none' x:num="311318"><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>311.318 </td>
      <td></td>
    </tr>
    <tr height="17" style='mso-height-source:userset;height:12.75pt'>
      <td height="17" class="xl28452" width="91" style='height:12.75pt;border-left:none;
  width:68pt'>Moradores</td>
      <td align="center" class="xl35452" x:num="483413"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>483.413</td>
      <td class="xl40452" x:num="1156800"><span style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>1.156.800 </td>
      <td></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td rowspan="2" height="34" class="xl51452" style='border-bottom:.5pt solid black;
  height:25.5pt;border-top:none'>Sem Declara&ccedil;&atilde;o<br />
      <br /></td>
      <td class="xl27452" width="91" style='border-top:none;border-left:none;
  width:68pt'>Domic&iacute;lios<br /></td>
      <td align="center" class="xl34452" style='border-top:none' x:num="37987">37.987<br /></td>
      <td class="xl41452" style='border-top:none' x:str="-"><span
  style='mso-spacerun:yes'>&nbsp;</span>-<span style='mso-spacerun:yes'>&nbsp;<br />
      </span></td>
      <td></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl28452" width="91" style='height:12.75pt;border-left:none;
  width:68pt'>Moradores</td>
      <td align="center" class="xl35452" x:num="124193">24.193</td>
      <td class="xl42452" x:str="-"><span style='mso-spacerun:yes'>&nbsp;</span>-<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
      <td></td>
    </tr>
    <tr height="13" style='mso-height-source:userset;height:9.95pt'>
      <td height="13" class="xl30452" style='height:9.95pt'>Fonte: IBGE - Censo 1991</td>
      <td class="xl31452"></td>
      <td class="xl31452"></td>
      <td class="xl31452"></td>
      <td></td>
    </tr>
    <tr height="13" style='mso-height-source:userset;height:9.95pt'>
      <td height="13" class="xl32452" colspan="5" style='height:9.95pt'>Elabora&ccedil;&atilde;o:
        Secretaria Municipal de Planejamento Urbano/Sempla - Departamento de
        Informa&ccedil;&otilde;es/Deinfo</td>
    </tr>
    <tr height="13" style='mso-height-source:userset;height:9.95pt'>
      <td height="13" class="xl33452" colspan="4" style='height:9.95pt'>(1) refere-se aos
        domic&iacute;lios particulares permanentes. Exclui os domic&iacute;lios improvisados.</td>
      <td></td>
    </tr>
    <tr height="13" style='mso-height-source:userset;height:9.95pt'>
      <td height="13" class="xl30452" colspan="4" style='height:9.95pt'
  x:str="(2) Rendimento M&eacute;dio da Pessoa Respons&aacute;vel pelo Domic&iacute;lio. Valores em Cruzeiros (Cr$) ">(2)
        Rendimento M&eacute;dio da Pessoa Respons&aacute;vel pelo Domic&iacute;lio. Valores em Cruzeiros
        (Cr$)<span style='mso-spacerun:yes'>&nbsp;</span></td>
      <td></td>
    </tr>
    <tr height="13" style='mso-height-source:userset;height:9.95pt'>
      <td height="13" class="xl30452" colspan="3" style='height:9.95pt'><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp; </span>em setembro/1991 e em Reais (R$) em
        setembro/2000</td>
      <td class="xl31452"></td>
      <td></td>
    </tr>
    <tr height="13" style='mso-height-source:userset;height:9.95pt'>
      <td height="13" class="xl30452" colspan="3" style='height:9.95pt'>(3) Valores do
        Sal&aacute;rio M&iacute;nimo: set/1991= Cr$ 36.161,60 e set /2000= R$ 151,00</td>
      <td class="xl31452"></td>
      <td></td>
    </tr>
    <tr height="13" style='mso-height-source:userset;height:9.95pt'>
      <td height="13" class="xl30452" colspan="4" style='height:9.95pt'>(4)Inclusive os
        domic&iacute;lios cuja pessoa respons&aacute;vel recebia somente em benef&iacute;cios.</td>
      <td></td>
    </tr>
    <![if supportMisalignedColumns]>
    <tr height="0" style='display:none'>
      <td width="145" style='width:109pt'></td>
      <td width="91" style='width:68pt'></td>
      <td width="86" style='width:65pt'></td>
      <td width="86" style='width:65pt'></td>
      <td width="64" style='width:48pt'></td>
    </tr>
    <![endif]>
  </table>
  <p>&nbsp;</p>
  <p><strong><img src="../img/seta-download.gif" width="11" height="12" /></strong><strong> </strong><a href="xls/pop_renda.xls" title="Clique para baixar a tabela no formato Excel (.xls)"><strong>FORMATO EXCEL (.XLS)</strong></a></p>
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">
</div>

</div>

<td><div id="assinatura">
<div style="text-align:center"><div>
</div></td>

</body>
</html>
