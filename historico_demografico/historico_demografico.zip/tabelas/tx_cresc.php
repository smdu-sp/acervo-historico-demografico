<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Hist&oacute;rico Demogr&aacute;fico do Munic&iacute;pio de S&atilde;o Paulo</title>
<link rel="stylesheet" type="text/css" href="../estilo_padrao.css">
<script language="JavaScript1.2" src="../funcoes.js"></script><style type="text/css">
<!--
.xl24 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl25 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl26 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl27 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl28 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl29 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl30 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl31 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl32 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl241 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl242 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl243 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl244 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl251 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl261 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl271 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl281 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl291 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl301 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl311 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl321 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl245 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl252 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl262 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl272 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl282 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl292 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl302 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl312 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl322 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl33 {mso-style-parent:style21;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl34 {mso-style-parent:style21;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl35 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl36 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl37 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl38 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl39 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl40 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl41 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl246 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl253 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl263 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl273 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl283 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl293 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl303 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl313 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl247 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl254 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl264 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl274 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl284 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl294 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl304 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl314 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl323 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl248 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl255 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl265 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl275 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:right;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl285 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl295 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl305 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl315 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.font6 {color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:italic;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl249 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl256 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl266 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl276 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl286 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl296 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl306 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:right;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl316 {mso-style-parent:style0;
	font-weight:700;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl324 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:Standard;
	text-align:center;}
.xl331 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl341 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;
	white-space:normal;}
.xl351 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:Standard;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl361 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;}
.font61 {color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:italic;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2410 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl257 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl267 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl277 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl287 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl297 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl307 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:right;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl317 {mso-style-parent:style0;
	font-weight:700;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl325 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:Standard;
	text-align:center;}
.xl332 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl342 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;
	white-space:normal;}
.xl352 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:Standard;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl362 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;}
.xl2411 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl258 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl268 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl278 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl288 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl298 {mso-style-parent:style19;
	color:black;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl308 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl318 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl326 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2412 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl259 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl269 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl279 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl289 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl299 {mso-style-parent:style19;
	color:black;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl309 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl319 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl327 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl333 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2413 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2510 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2610 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2710 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2810 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl2910 {mso-style-parent:style19;
	color:black;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl3010 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl3110 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl328 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl334 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2414 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2511 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2611 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2711 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2811 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl2911 {mso-style-parent:style19;
	color:black;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl3011 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:Fixed;
	text-align:center;}
.xl3111 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl329 {mso-style-parent:style19;
	color:black;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl335 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2415 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2512 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2612 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2712 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2812 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl2912 {mso-style-parent:style19;
	color:black;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:right;}
.xl3012 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3112 {mso-style-parent:style19;
	color:black;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:right;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3210 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.font9 {color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:italic;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2513 {mso-style-parent:style20;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2613 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2713 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2813 {mso-style-parent:style20;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;}
.xl2913 {mso-style-parent:style20;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:right;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3013 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl3113 {mso-style-parent:style22;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl3211 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"0\.0";
	text-align:center;}
.xl336 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl343 {mso-style-parent:style22;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl353 {mso-style-parent:style20;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl363 {mso-style-parent:style20;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl371 {mso-style-parent:style20;
	color:black;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;}
.xl381 {mso-style-parent:style20;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	mso-protection:unlocked visible;}
.xl401 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;}
.xl411 {mso-style-parent:style20;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;
	vertical-align:middle;}
.font7 {color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2416 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2514 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2614 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl2714 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl2814 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2914 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3014 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;}
.xl3114 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3212 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl337 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;}
.xl2417 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl2515 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2615 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl2715 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2815 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl2915 {mso-style-parent:style21;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl3015 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl3115 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl3213 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl338 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl344 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl354 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";}
.xl364 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;}
.xl372 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";}
.xl382 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl391 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;}
.xl402 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl412 {mso-style-parent:style0;
	color:black;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;}
.xl43 {mso-style-parent:style0;
	color:black;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;}
.font71 {color:windowtext;
	font-size:10.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:Arial;
	mso-generic-font-family:auto;
	mso-font-charset:0;}
.xl2418 {mso-style-parent:style0;
	font-weight:700;}
.xl2516 {mso-style-parent:style0;
	font-weight:700;
	text-align:center;}
.xl2616 {mso-style-parent:style0;
	font-weight:700;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2716 {mso-style-parent:style0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2816 {mso-style-parent:style19;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl2916 {mso-style-parent:style19;
	mso-number-format:"_\(* \#\,\#\#0\.00_\)\;_\(* \\\(\#\,\#\#0\.00\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl3016 {mso-style-parent:style19;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3116 {mso-style-parent:style19;
	mso-number-format:"_\(* \#\,\#\#0\.00_\)\;_\(* \\\(\#\,\#\#0\.00\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3311 {mso-style-parent:style0;
	font-style:italic;
	text-align:left;}
.xl3411 {mso-style-parent:style0;
	text-align:left;}
.xl2419 {mso-style-parent:style0;
	font-weight:700;}
.xl2517 {mso-style-parent:style0;
	font-weight:700;
	text-align:center;}
.xl2617 {mso-style-parent:style0;
	font-weight:700;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2717 {mso-style-parent:style0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2817 {mso-style-parent:style19;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl2917 {mso-style-parent:style19;
	mso-number-format:"_\(* \#\,\#\#0\.00_\)\;_\(* \\\(\#\,\#\#0\.00\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl3017 {mso-style-parent:style19;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3117 {mso-style-parent:style19;
	mso-number-format:"_\(* \#\,\#\#0\.00_\)\;_\(* \\\(\#\,\#\#0\.00\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3214 {mso-style-parent:style0;
	font-style:italic;}
.font8 {color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2518 {mso-style-parent:style18;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2618 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2718 {mso-style-parent:style18;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2818 {mso-style-parent:style18;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2918 {mso-style-parent:style18;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;}
.xl3018 {mso-style-parent:style18;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3118 {mso-style-parent:style18;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl3215 {mso-style-parent:style18;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";}
.xl339 {mso-style-parent:style18;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0\.0";
	text-align:center;}
.xl345 {mso-style-parent:style18;
	color:red;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";}
.xl355 {mso-style-parent:style18;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl365 {mso-style-parent:style18;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl373 {mso-style-parent:style18;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl383 {mso-style-parent:style18;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0\.0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl392 {mso-style-parent:style18;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl403 {mso-style-parent:style18;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:left;}
.xl413 {mso-style-parent:style18;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;}
.xl2420 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2519 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl2619 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2719 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl2819 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl2919 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl3019 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3119 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3216 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;}
.xl3310 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl346 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl356 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;}
.xl2421 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2520 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2620 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2720 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl2820 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2920 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl3020 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl3120 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:Fixed;
	text-align:center;}
.xl3217 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3312 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl347 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:Fixed;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl357 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2422 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2521 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl2621 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"0\.0";}
.xl2721 {mso-style-parent:style0;
	color:red;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"0\.0";}
.xl2821 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2921 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"0\.0";}
.xl3021 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3121 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3218 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"0\.0";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3313 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl348 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl358 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl366 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";}
.xl374 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl384 {mso-style-parent:style19;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl393 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl404 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";}
.xl414 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl42 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:right;}
.xl431 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"0\.0";}
.xl44 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl45 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl46 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl47 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl48 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl49 {mso-style-parent:style0;
	font-size:8.0pt;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl50 {mso-style-parent:style0;
	font-size:8.0pt;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl51 {mso-style-parent:style0;
	font-size:8.0pt;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"0\.0";}
.xl52 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl53 {mso-style-parent:style0;
	font-size:8.0pt;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"0\.0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl54 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl55 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl56 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl57 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0\.0_\)\;_\(* \\\(\#\,\#\#0\.0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl58 {mso-style-parent:style0;
	font-size:8.0pt;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl59 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0\.0_\)\;_\(* \\\(\#\,\#\#0\.0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl60 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"0\.0";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.font10 {color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2423 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl2522 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2622 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2722 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:0;}
.xl2822 {mso-style-parent:style0;
	color:black;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2922 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;
	vertical-align:middle;}
.xl3022 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;}
.xl3122 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl3219 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	white-space:normal;}
.xl3314 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl349 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl359 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	vertical-align:middle;}
.xl367 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:Standard;
	vertical-align:middle;}
.xl375 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\#\#\\ \#\#\#\\ \#\#\#\\ \#\#0\.00_ \;\\-\#\#\#\\ \#\#\#\\ \#\#\#\\ \#\#0_ \;\0022- \0022";}
.xl385 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;}
.xl394 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\#\#\\ \#\#\#\\ \#\#\#\\ \#\#0_ \;\\-\#\#\#\\ \#\#\#\\ \#\#\#\\ \#\#0_ \;\0022- \0022";
	text-align:center;}
.xl405 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\#\#\\ \#\#\#\\ \#\#\#\\ \#\#0_ \;\\-\#\#\#\\ \#\#\#\\ \#\#\#\\ \#\#0_ \;\0022- \0022";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl415 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl421 {mso-style-parent:style19;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";
	text-align:center;
	vertical-align:middle;}
.xl2424 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2523 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl2623 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2723 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";}
.xl2823 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\#\#\\ \#\#\#\\ \#\#\#\\ \#\#0_ \;\\-\#\#\#\\ \#\#\#\\ \#\#\#\\ \#\#0_ \;\0022- \0022";
	text-align:left;
	vertical-align:top;}
.xl3023 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";}
.xl3123 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\#\#\\ \#\#\#\\ \#\#\#\\ \#\#0_ \;\\-\#\#\#\\ \#\#\#\\ \#\#\#\\ \#\#0_ \;\0022- \0022";}
.xl3220 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl3315 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl3410 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3510 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl368 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl376 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl386 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;
	white-space:normal;}
.xl395 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2425 {mso-style-parent:style0;
	font-size:10.0pt;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2524 {mso-style-parent:style0;
	font-size:10.0pt;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2624 {mso-style-parent:style0;
	font-size:10.0pt;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2724 {mso-style-parent:style0;
	font-size:10.0pt;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;}
.xl2824 {mso-style-parent:style0;
	font-size:10.0pt;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2923 {mso-style-parent:style0;
	font-size:10.0pt;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl3024 {mso-style-parent:style0;
	font-size:10.0pt;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";}
.xl3124 {mso-style-parent:style0;
	font-size:10.0pt;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0\.0";
	text-align:center;}
.xl3221 {mso-style-parent:style0;
	color:red;
	font-size:10.0pt;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";}
.xl3316 {mso-style-parent:style0;
	font-size:10.0pt;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3412 {mso-style-parent:style0;
	font-size:10.0pt;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0\.0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3511 {mso-style-parent:style0;
	font-size:10.0pt;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl369 {mso-style-parent:style0;
	font-size:10.0pt;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;}
.font62 {color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2525 {mso-style-parent:style18;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2625 {mso-style-parent:style18;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";}
.xl2725 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2825 {mso-style-parent:style18;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2924 {mso-style-parent:style18;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3025 {mso-style-parent:style18;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl3125 {mso-style-parent:style18;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl3222 {mso-style-parent:style18;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3317 {mso-style-parent:style18;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";}
.xl3413 {mso-style-parent:style18;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl3512 {mso-style-parent:style18;
	color:red;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";}
.xl3610 {mso-style-parent:style18;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl377 {mso-style-parent:style18;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl387 {mso-style-parent:style18;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;
	border-top:1.0pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;}
.font63 {color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2426 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2526 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl2626 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
.xl2726 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";}
.xl2826 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"0\.0";}
.xl2925 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl3026 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3126 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3223 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3318 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"0\.0";
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2427 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl2527 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:Fixed;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2627 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:right;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2727 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl2827 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:Fixed;
	text-align:center;}
.xl2926 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;}
.xl3027 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:Fixed;
	text-align:center;}
.xl3127 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3224 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:Fixed;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3319 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl3414 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;}
.xl3513 {mso-style-parent:style0;
	font-weight:700;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;}
.xl3611 {mso-style-parent:style21;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022??_\)\;_\(\@_\)";}
.xl378 {mso-style-parent:style0;
	font-style:italic;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:left;}
.xl388 {mso-style-parent:style0;
	color:black;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:middle;}
.xl406 {mso-style-parent:style0;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	text-align:center;}
-->
</style>
</head>

<body>

<div id="geral">

<table align="center" border="0" cellpadding="0" cellspacing="0" width="780">

    <tr><td><div id="header_prefeitura">
</div></div>
</div></td></tr>

    <tr><td><table width="778" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td><div id="tarja_laranja"> <a href="../index.php" title="Voltar para a p&aacute;gina inicial">
		<h1 class="semestilo">Hist&oacute;ria Demogr&aacute;fica do Munic&iacute;pio de S&atilde;o Paulo</h1>
		</a> </div></td>
		<td align="right">
		
		<a href="../index.php"><img src="../img/botao_apresentacao_1.jpg" alt="P&aacute;gina Inicial" name="Image1" width="103" height="35" border="0" id="Image1" title="Página Inicial" onMouseOver="MM_swapImage('Image1','','../img/botao_apresentacao_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a><a href="../introducao.php"><img src="../img/botao_introducao_1.jpg" alt="Introdu&ccedil;&atilde;o" name="Image2" width="85" height="35" border="0" id="Image2" title="Introdu&ccedil;&atilde;o" onMouseOver="MM_swapImage('Image2','','../img/botao_introducao_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a><a href="../equipe.php"><img src="../img/botao_equipe_1.jpg" alt="Equipe T&eacute;cnica" name="Image3" width="108" height="35" border="0" id="Image3" title="Equipe T&eacute;cnica" onMouseOver="MM_swapImage('Image3','','../img/botao_equipe_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a><a href="../tabelas.php"><img src="../img/botao_dados_1.jpg" alt="Tabelas" name="Image4" width="76" height="35" border="0" id="Image4" title="Tabelas" onMouseOver="MM_swapImage('Image4','','../img/botao_dados_2.jpg',1)" onMouseOut="MM_swapImgRestore()"></a></td>
	</tr>
</table></td></tr>
	  
</table>

<div id="conteudo"> 
  <h1>Tabelas</h1>
  <p>&nbsp;</p>
  <table x:str="x:str" border="0" cellpadding="0" cellspacing="0" width="926" style='border-collapse:
 collapse;table-layout:fixed;width:392pt'>
    <col class="xl3319" width="189" style='mso-width-source:userset;mso-width-alt:6912;
 width:142pt' />
    <col class="xl3611" width="67" span="3" style='mso-width-source:userset;mso-width-alt:
 2450;width:50pt' />
    <col class="xl2926" width="67" span="2" style='mso-width-source:userset;mso-width-alt:
 2450;width:50pt' />
    <tr height="17" style='height:12.75pt'>
      <td colspan="7" height="17" class="xl2427" width="524" style='height:12.75pt;
  width:392pt' x:str="Taxas de Crescimento ">Taxas de Crescimento<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td colspan="7" height="17" class="xl2427" style='height:12.75pt'>Munic&iacute;pio de S&atilde;o
        Paulo, Subprefeituras e Distritos Municipais</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td colspan="7" height="17" class="xl2427" style='height:12.75pt'><p>1950, 1960, 1970,
        1980, 1991, 2000 e 2010</p></td>
    </tr>
    <tr height="18" style='height:13.5pt'>
      <td height="18" class="xl3414" style='height:13.5pt'>&nbsp;</td>
      <td class="xl2527">&nbsp;</td>
      <td class="xl2527">&nbsp;</td>
      <td class="xl2527">&nbsp;</td>
      <td class="xl2527">&nbsp;</td>
      <td class="xl2527">&nbsp;</td>
      <td class="xl2527">&nbsp;</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td rowspan="2" height="35" class="xl388" style='border-bottom:1.0pt solid black;
  height:26.25pt'>Unidades Territoriais</td>
      <td colspan="6" class="xl406">Taxas de Crescimento</td>
    </tr>
    <tr height="18" style='height:13.5pt'>
      <td height="18" class="xl2627" style='height:13.5pt'>1950/1960</td>
      <td class="xl2727">1960/1970</td>
      <td class="xl2627">1970/1980</td>
      <td class="xl2627">1980/1991</td>
      <td class="xl2627">1991/2000</td>
      <td class="xl2627">2000/2010</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2427" style='height:12.75pt'>MSP</td>
      <td class="xl2827" x:num="5.4803049451191965">5,48</td>
      <td class="xl2827" x:num="4.9117850575830735">4,91</td>
      <td class="xl2827" x:num="3.667172803359553">3,67</td>
      <td class="xl2827" x:num="1.1639361372562496">1,16</td>
      <td class="xl2827" x:num="0.87638861338827923">0,88</td>
      <td width="64" align="center">0,76</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Aricanduva/Formosa/Carr&atilde;o</td>
      <td class="xl2827" x:num="5.638130310566436">5,64</td>
      <td class="xl2827" x:num="3.1579001319034017">3,16</td>
      <td class="xl2827" x:num="1.1641517523397704">1,16</td>
      <td class="xl2827" x:num="-0.51075053730414988">-0,51</td>
      <td class="xl2827" x:num="-0.60387245524341493">-0,60</td>
      <td align="center">0,03</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Aricanduva</td>
      <td class="xl3027" x:num="6.0364709011085038">6,04</td>
      <td class="xl3027" x:num="3.4564593004690947">3,46</td>
      <td class="xl3027" x:num="1.2962090289674322">1,30</td>
      <td class="xl3027" x:num="0.35815923961657337">0,36</td>
      <td class="xl3027" x:num="-0.19714787759944619">-0,20</td>
      <td align="center">-0,56</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Carr&atilde;o</td>
      <td class="xl3027" x:num="6.0364709011085038">6,04</td>
      <td class="xl3027" x:num="3.4564593004690947">3,46</td>
      <td class="xl3027" x:num="1.2962090289674322">1,30</td>
      <td class="xl3027" x:num="-1.1528673087832675">-1,15</td>
      <td class="xl3027" x:num="-1.2237049241511477">-1,22</td>
      <td align="center">0,63</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Vila Formosa</td>
      <td class="xl3027" x:num="5.0277462452229305">5,03</td>
      <td class="xl3027" x:num="2.6586154395667583">2,66</td>
      <td class="xl3027" x:num="0.92990535611292557">0,93</td>
      <td class="xl3027" x:num="-0.7255583263992671">-0,73</td>
      <td class="xl3027" x:num="-0.47284834937474374">-0,47</td>
      <td align="center">0,10</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Butant&atilde;</td>
      <td class="xl2827" x:num="9.541470217417757">9,54</td>
      <td class="xl2827" x:num="9.9605621977162819">9,96</td>
      <td class="xl2827" x:num="6.1657494353540399">6,17</td>
      <td class="xl2827" x:num="2.3177790705312118">2,32</td>
      <td class="xl2827" x:num="0.32415651040609283">0,32</td>
      <td align="center">1,27</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Butant&atilde;</td>
      <td class="xl3027" x:num="9.1721843711949589">9,17</td>
      <td class="xl3027" x:num="9.8451118789693268">9,85</td>
      <td class="xl3027" x:num="6.0869250763390781">6,09</td>
      <td class="xl3027" x:num="0.17181202770648607">0,17</td>
      <td class="xl3027" x:num="-1.0733458459884493">-1,07</td>
      <td align="center">0,29</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Morumbi</td>
      <td class="xl3027" x:num="11.051163168398205">11,05</td>
      <td class="xl3027" x:num="7.7184780438217304">7,72</td>
      <td class="xl3027" x:num="5.1968126235795831">5,20</td>
      <td class="xl3027" x:num="2.3284743185317813">2,33</td>
      <td class="xl3027" x:num="-1.6107459558749704">-1,61</td>
      <td align="center">3,10</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Raposo Tavares</td>
      <td class="xl3027" x:num="9.1721843711949358">9,17</td>
      <td class="xl3027" x:num="9.8451118789693268">9,85</td>
      <td class="xl3027" x:num="6.0869250763390781">6,09</td>
      <td class="xl3027" x:num="4.8234150066689185">4,82</td>
      <td class="xl3027" x:num="1.0677078401225115">1,07</td>
      <td align="center">0,94</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Rio Pequeno</td>
      <td class="xl3027" x:num="9.1721843711949358">9,17</td>
      <td class="xl3027" x:num="9.8451118789693268">9,85</td>
      <td class="xl3027" x:num="6.0869250763390781">6,09</td>
      <td class="xl3027" x:num="1.7646944166732625">1,76</td>
      <td class="xl3027" x:num="0.93344212397439286">0,93</td>
      <td align="center">0,58</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Vila S&ocirc;nia</td>
      <td class="xl3027" x:num="9.8453345762806279">9,85</td>
      <td class="xl3027" x:num="12.003133086825812">12,00</td>
      <td class="xl3027" x:num="6.9406417907264428">6,94</td>
      <td class="xl3027" x:num="2.5605474409589268">2,56</td>
      <td class="xl3027" x:num="0.57209787449190586">0,57</td>
      <td align="center">2,18</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Campo Limpo</td>
      <td class="xl2827" x:num="10.606700890056086">10,61</td>
      <td class="xl2827" x:num="13.537086052740532">13,54</td>
      <td class="xl2827" x:num="7.7484989912946389">7,75</td>
      <td class="xl2827" x:num="3.8397566769371005">3,84</td>
      <td class="xl2827" x:num="2.7734680795376221">2,77</td>
      <td align="center">1,84</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Campo Limpo</td>
      <td class="xl3027" x:num="10.293401996658913">10,29</td>
      <td class="xl3027" x:num="13.190773421668634">13,19</td>
      <td class="xl3027" x:num="7.318503814169075">7,32</td>
      <td class="xl3027" x:num="3.3864424630936529">3,39</td>
      <td class="xl3027" x:num="2.0560367073511943">2,06</td>
      <td align="center">0,99</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Cap&atilde;o Redondo</td>
      <td class="xl3027" x:num="10.927041876718558">10,93</td>
      <td class="xl3027" x:num="14.693610868462059">14,69</td>
      <td class="xl3027" x:num="8.3932487596085625">8,39</td>
      <td class="xl3027" x:num="3.8138466541735916">3,81</td>
      <td class="xl3027" x:num="2.4594877247818392">2,46</td>
      <td align="center">1,10</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Vila Andrade</td>
      <td class="xl3027" x:num="10.706876244652697">10,71</td>
      <td class="xl3027" x:num="10.457442849292974">10,46</td>
      <td class="xl3027" x:num="6.4487777794019818">6,45</td>
      <td class="xl3027" x:num="5.9335909997274561">5,93</td>
      <td class="xl3027" x:num="6.2783164993641005">6,28</td>
      <td align="center">5,60</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Capela do Socorro</td>
      <td class="xl2827" x:num="11.383941942222142">11,38</td>
      <td class="xl2827" x:num="18.291817714480942">18,29</td>
      <td class="xl2827" x:num="10.473567820706631">10,47</td>
      <td class="xl2827" x:num="3.3956988675486022">3,40</td>
      <td class="xl2827" x:num="3.7247129105950849">3,72</td>
      <td align="center">0,54</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Cidade Dutra</td>
      <td class="xl3027" x:num="13.805758424937409">13,81</td>
      <td class="xl3027" x:num="19.228480662479996">19,23</td>
      <td class="xl3027" x:num="10.535983460753439">10,54</td>
      <td class="xl3027" x:num="2.9212840612925728">2,92</td>
      <td class="xl3027" x:num="1.403863160935348">1,40</td>
      <td align="center">0,26</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Graja&uacute;</td>
      <td class="xl3027" x:num="9.1639621454457689">9,16</td>
      <td class="xl3027" x:num="17.122538594114477">17,12</td>
      <td class="xl3027" x:num="10.387091985753161">10,39</td>
      <td class="xl3027" x:num="4.6678992459638469">4,67</td>
      <td class="xl3027" x:num="6.2174220560057947">6,22</td>
      <td align="center">0,79</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Socorro</td>
      <td class="xl3027" x:num="13.805758424937409">13,81</td>
      <td class="xl3027" x:num="19.228480662479996">19,23</td>
      <td class="xl3027" x:num="10.535983460753439">10,54</td>
      <td class="xl3027" x:num="0.5335189064936019">0,53</td>
      <td class="xl3027" x:num="-1.1011794609099845">-1,10</td>
      <td align="center">-0,34</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Casa Verde/Cachoeirinha</td>
      <td class="xl2827" x:num="6.1782214098641486">6,18</td>
      <td class="xl2827" x:num="3.4546620795928629">3,45</td>
      <td class="xl2827" x:num="1.6797597265491682">1,68</td>
      <td class="xl2827" x:num="0.43498065094647043">0,43</td>
      <td class="xl2827" x:num="2.3183643287150169E-2">0,02</td>
      <td align="center">-0,13</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Cachoeirinha</td>
      <td class="xl3027" x:num="6.1264633171733918">6,13</td>
      <td class="xl3027" x:num="3.7542396037501202">3,75</td>
      <td class="xl3027" x:num="2.2002506635194097">2,20</td>
      <td class="xl3027" x:num="1.5967452259483705">1,60</td>
      <td class="xl3027" x:num="1.7906343653799839">1,79</td>
      <td align="center">-0,28</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Casa Verde</td>
      <td class="xl3027" x:num="5.5376311658787314">5,54</td>
      <td class="xl3027" x:num="2.2328916323826276">2,23</td>
      <td class="xl3027" x:num="1.1013853831694176">1,10</td>
      <td class="xl3027" x:num="-0.64041755332271411">-0,64</td>
      <td class="xl3027" x:num="-1.5662093217236661">-1,57</td>
      <td align="center">0,24</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Lim&atilde;o</td>
      <td class="xl3027" x:num="7.3736891966996065">7,37</td>
      <td class="xl3027" x:num="4.8372701324513656">4,84</td>
      <td class="xl3027" x:num="1.7729004741707577">1,77</td>
      <td class="xl3027" x:num="0.15327142966921059">0,15</td>
      <td class="xl3027" x:num="-1.0744057331578349">-1,07</td>
      <td align="center">-0,22</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Cidade Ademar</td>
      <td class="xl2827" x:num="9.6625003416810351">9,66</td>
      <td class="xl2827" x:num="11.554940674135894">11,55</td>
      <td class="xl2827" x:num="6.3144157882712992">6,31</td>
      <td class="xl2827" x:num="1.0403148642134541">1,04</td>
      <td class="xl2827" x:num="1.7642699801502904">1,76</td>
      <td align="center">1,03</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Cidade Ademar</td>
      <td class="xl3027" x:num="9.5331749974632896">9,53</td>
      <td class="xl3027" x:num="11.177050117834497">11,18</td>
      <td class="xl3027" x:num="6.0443900745288826">6,04</td>
      <td class="xl3027" x:num="0.45097977189338945">0,45</td>
      <td class="xl3027" x:num="0.59135943580750361">0,59</td>
      <td align="center">0,92</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Pedreira</td>
      <td class="xl3027" x:num="10.293401996658913">10,29</td>
      <td class="xl3027" x:num="13.190773421668634">13,19</td>
      <td class="xl3027" x:num="7.318503814169075">7,32</td>
      <td class="xl3027" x:num="2.8610458623713475">2,86</td>
      <td class="xl3027" x:num="4.4653705305616631">4,47</td>
      <td align="center">1,25</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Cidade Tiradentes</td>
      <td class="xl2827" x:num="9.0030140668448055">9,00</td>
      <td class="xl2827" x:num="11.721594937698354">11,72</td>
      <td class="xl2827" x:num="7.1906284284704913">7,19</td>
      <td class="xl2827" x:num="24.55246722171054">24,55</td>
      <td class="xl2827" x:num="7.8867270352538155">7,89</td>
      <td align="center">1,04</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Cidade Tiradentes</td>
      <td class="xl3027" x:num="9.0030140668448055">9,00</td>
      <td class="xl3027" x:num="11.721594937698354">11,72</td>
      <td class="xl3027" x:num="7.1906284284704913">7,19</td>
      <td class="xl3027" x:num="24.55246722171054">24,55</td>
      <td class="xl3027" x:num="7.8867270352538155">7,89</td>
      <td align="center">1,04</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Ermelino Matarazzo</td>
      <td class="xl2827" x:num="13.434409880110643">13,43</td>
      <td class="xl2827" x:num="5.250175206577179">5,25</td>
      <td class="xl2827" x:num="4.6980521206050563">4,70</td>
      <td class="xl2827" x:num="1.0229746664088379">1,02</td>
      <td class="xl2827" x:num="0.36660837817115155">0,37</td>
      <td align="center">0,12</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Ermelino Matarazzo</td>
      <td class="xl3027" x:num="13.434409880110643">13,43</td>
      <td class="xl3027" x:num="2.9013270688517112">2,90</td>
      <td class="xl3027" x:num="4.6980521206050563">4,70</td>
      <td class="xl3027" x:num="1.5745716570614521">1,57</td>
      <td class="xl3027" x:num="1.241495701569395">1,24</td>
      <td align="center">0,62</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Ponte Rasa</td>
      <td class="xl3027" x:num="13.434409880110643">13,43</td>
      <td class="xl3027" x:num="7.768889458785444">7,77</td>
      <td class="xl3027" x:num="4.6980521206050563">4,70</td>
      <td class="xl3027" x:num="0.54004839702732621">0,54</td>
      <td class="xl3027" x:num="-0.50662027646698471">-0,51</td>
      <td align="center">-0,44</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Freguesia/Brasil&acirc;ndia</td>
      <td class="xl2827" x:num="9.9137981641552297">9,91</td>
      <td class="xl2827" x:num="8.7281800272594587">8,73</td>
      <td class="xl2827" x:num="3.7794187077576868">3,78</td>
      <td class="xl2827" x:num="1.014912650214872">1,01</td>
      <td class="xl2827" x:num="1.1382331994858053">1,14</td>
      <td align="center">0,38</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Brasil&acirc;ndia</td>
      <td class="xl3027" x:num="9.9137981641552297">9,91</td>
      <td class="xl3027" x:num="8.7281800272594587">8,73</td>
      <td class="xl3027" x:num="3.7794187077576868">3,78</td>
      <td class="xl3027" x:num="1.7570584058673289">1,76</td>
      <td class="xl3027" x:num="2.2979439708856075">2,30</td>
      <td align="center">0,69</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Freguesia do &Oacute;</td>
      <td class="xl3027" x:num="9.9137981641552297">9,91</td>
      <td class="xl3027" x:num="8.7281800272594587">8,73</td>
      <td class="xl3027" x:num="3.7794187077576868">3,78</td>
      <td class="xl3027" x:num="0.12564551047382633">0,13</td>
      <td class="xl3027" x:num="-0.57709793811370202">-0,58</td>
      <td align="center">-0,18</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Guaianases</td>
      <td class="xl2827" x:num="9.9366791111071819">9,94</td>
      <td class="xl2827" x:num="13.20207256261603">13,20</td>
      <td class="xl2827" x:num="7.207458614999962">7,21</td>
      <td class="xl2827" x:num="4.4856162895056118">4,49</td>
      <td class="xl2827" x:num="3.1329325718697953">3,13</td>
      <td align="center">0,47</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Guaianases</td>
      <td class="xl3027" x:num="9.0030140668448055">9,00</td>
      <td class="xl3027" x:num="11.721594937698354">11,72</td>
      <td class="xl3027" x:num="7.1906284284704913">7,19</td>
      <td class="xl3027" x:num="4.4480261082638695">4,45</td>
      <td class="xl3027" x:num="2.1503484922164029">2,15</td>
      <td align="center">0,54</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Lajeado</td>
      <td class="xl3027" x:num="10.886215180922676">10,89</td>
      <td class="xl3027" x:num="14.432498653084469">14,43</td>
      <td class="xl3027" x:num="7.2197003842571661">7,22</td>
      <td class="xl3027" x:num="4.5128329684334334">4,51</td>
      <td class="xl3027" x:num="3.797887513203424">3,80</td>
      <td align="center">0,42</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Ipiranga</td>
      <td class="xl2827" x:num="3.6280879787244702">3,63</td>
      <td class="xl2827" x:num="2.3962735634126542">2,40</td>
      <td class="xl2827" x:num="1.4412610065488662">1,44</td>
      <td class="xl2827" x:num="0.55834850417710857">0,56</td>
      <td class="xl2827" x:num="0.15829505653990328">0,16</td>
      <td align="center">0,78</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Cursino</td>
      <td class="xl3027" x:num="7.4057872492121479">7,41</td>
      <td class="xl3027" x:num="5.688716943644212">5,69</td>
      <td class="xl3027" x:num="2.559485721914756">2,56</td>
      <td class="xl3027" x:num="-0.48278066708768996">-0,48</td>
      <td class="xl3027" x:num="-0.86933403406953547">-0,87</td>
      <td align="center">0,67</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Ipiranga</td>
      <td class="xl3027" x:num="1.4678715807889597">1,47</td>
      <td class="xl3027" x:num="0.21634274583244295">0,22</td>
      <td class="xl3027" x:num="0.49350678670834203">0,49</td>
      <td class="xl3027" x:num="-1.3256884250806178">-1,33</td>
      <td class="xl3027" x:num="-0.29566001160735711">-0,30</td>
      <td align="center">0,78</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Sacom&atilde;</td>
      <td class="xl3027" x:num="4.6175455060616599">4,62</td>
      <td class="xl3027" x:num="2.5655155650963213">2,57</td>
      <td class="xl3027" x:num="1.4090470550098821">1,41</td>
      <td class="xl3027" x:num="2.3279726464288997">2,33</td>
      <td class="xl3027" x:num="0.86797340530031519">0,87</td>
      <td align="center">0,83</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Itaim Paulista</td>
      <td class="xl2827" x:num="9.8664841445518228">9,87</td>
      <td class="xl2827" x:num="12.168391577047633">12,17</td>
      <td class="xl2827" x:num="7.0279092527047782">7,03</td>
      <td class="xl2827" x:num="3.2300518341824125">3,23</td>
      <td class="xl2827" x:num="2.502559687770689">2,50</td>
      <td align="center">0,38</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Itaim Paulista</td>
      <td class="xl3027" x:num="10.745494270374323">10,75</td>
      <td class="xl3027" x:num="12.571271523123251">12,57</td>
      <td class="xl3027" x:num="6.8853562987172268">6,89</td>
      <td class="xl3027" x:num="3.8934902663392279">3,89</td>
      <td class="xl3027" x:num="2.9840876239656478">2,98</td>
      <td align="center">0,52</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Vila Curu&ccedil;&aacute;</td>
      <td class="xl3027" x:num="9.0030140668448055">9,00</td>
      <td class="xl3027" x:num="11.721594937698354">11,72</td>
      <td class="xl3027" x:num="7.1906284284704913">7,19</td>
      <td class="xl3027" x:num="2.429813917523993">2,43</td>
      <td class="xl3027" x:num="1.8412406580580409">1,84</td>
      <td align="center">0,17</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Itaquera</td>
      <td class="xl2827" x:num="9.2607383338752847">9,26</td>
      <td class="xl2827" x:num="13.340682963515359">13,34</td>
      <td class="xl2827" x:num="7.0839527733228325">7,08</td>
      <td class="xl2827" x:num="4.8396319547968858">4,84</td>
      <td class="xl2827" x:num="1.4192819597961925">1,42</td>
      <td align="center">0,68</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Cidade L&iacute;der</td>
      <td class="xl3027" x:num="7.5805440721587347">7,58</td>
      <td class="xl3027" x:num="9.8150694561907272">9,82</td>
      <td class="xl3027" x:num="6.2594919074634214">6,26</td>
      <td class="xl3027" x:num="2.9779328686523998">2,98</td>
      <td class="xl3027" x:num="2.0461624455673899">2,05</td>
      <td align="center">0,81</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Itaquera</td>
      <td class="xl3027" x:num="11.637310603226613">11,64</td>
      <td class="xl3027" x:num="15.257530840318134">15,26</td>
      <td class="xl3027" x:num="7.227127189267768">7,23</td>
      <td class="xl3027" x:num="2.9971094571627388">3,00</td>
      <td class="xl3027" x:num="1.5561360182135386">1,56</td>
      <td align="center">0,17</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Jos&eacute; Bonif&aacute;cio</td>
      <td class="xl3027" x:num="8.5843590310465743">8,58</td>
      <td class="xl3027" x:num="15.377981189746981">15,38</td>
      <td class="xl3027" x:num="7.83323072547919">7,83</td>
      <td class="xl3027" x:num="14.20970372550201">14,21</td>
      <td class="xl3027" x:num="0.35593270964211499">0,36</td>
      <td align="center">1,49</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Parque do Carmo</td>
      <td class="xl3027" x:num="8.5843590310465743">8,58</td>
      <td class="xl3027" x:num="15.377981189746981">15,38</td>
      <td class="xl3027" x:num="7.83323072547919">7,83</td>
      <td class="xl3027" x:num="4.1235198935533957">4,12</td>
      <td class="xl3027" x:num="1.7629135627223347">1,76</td>
      <td align="center">0,64</td>
    </tr>
    <tr height="17" style='page-break-before:always;height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Jabaquara</td>
      <td class="xl2827" x:num="10.448884273978098">10,45</td>
      <td class="xl2827" x:num="6.928741797453597">6,93</td>
      <td class="xl2827" x:num="3.3006588821298921">3,30</td>
      <td class="xl2827" x:num="0.80985837755147561">0,81</td>
      <td class="xl2827" x:num="-1.3225250877080263E-2">-0,01</td>
      <td align="center">0,44</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Jabaquara</td>
      <td class="xl3027" x:num="10.448884273978098">10,45</td>
      <td class="xl3027" x:num="6.928741797453597">6,93</td>
      <td class="xl3027" x:num="3.3006588821298921">3,30</td>
      <td class="xl3027" x:num="0.80985837755147561">0,81</td>
      <td class="xl3027" x:num="-1.3225250877080263E-2">-0,01</td>
      <td align="center">0,44</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Ja&ccedil;an&atilde;/Trememb&eacute;</td>
      <td class="xl2827" x:num="9.3146115380874139">9,31</td>
      <td class="xl2827" x:num="4.8671073231675965">4,87</td>
      <td class="xl2827" x:num="2.5432942839791695">2,54</td>
      <td class="xl2827" x:num="1.6552132818949072">1,66</td>
      <td class="xl2827" x:num="2.1054427113018193">2,11</td>
      <td align="center">1,34</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Ja&ccedil;an&atilde;</td>
      <td class="xl3027" x:num="9.3146115380874139">9,31</td>
      <td class="xl3027" x:num="4.8671073231675965">4,87</td>
      <td class="xl3027" x:num="2.5432942839791695">2,54</td>
      <td class="xl3027" x:num="0.73844816248000988">0,74</td>
      <td class="xl3027" x:num="0.62145806466755715">0,62</td>
      <td align="center">0,30</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Trememb&eacute;</td>
      <td class="xl3027" x:num="9.3146115380874139">9,31</td>
      <td class="xl3027" x:num="4.8671073231675965">4,87</td>
      <td class="xl3027" x:num="2.5432942839791695">2,54</td>
      <td class="xl3027" x:num="2.355588925957508">2,36</td>
      <td class="xl3027" x:num="3.042601696488112">3,04</td>
      <td align="center">1,88</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Lapa</td>
      <td class="xl2827" x:num="2.7298022989937776">2,73</td>
      <td class="xl2827" x:num="1.9532835481012256">1,95</td>
      <td class="xl2827" x:num="2.1954162515184006">2,20</td>
      <td class="xl2827" x:num="-0.69705027724722424">-0,70</td>
      <td class="xl2827" x:num="-0.99416836568051448">-0,99</td>
      <td align="center">1,22</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Barra Funda</td>
      <td class="xl3027" x:num="1.9150527815693374">1,92</td>
      <td class="xl3027" x:num="0.93266938882310413">0,93</td>
      <td class="xl3027" x:num="1.5077587296603134">1,51</td>
      <td class="xl3027" x:num="-1.0249194248626248">-1,02</td>
      <td class="xl3027" x:num="-2.2943454662496032">-2,29</td>
      <td align="center">1,04</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Jaguara</td>
      <td class="xl3027" x:num="10.469909925082789">10,47</td>
      <td class="xl3027" x:num="4.0575223354322842">4,06</td>
      <td class="xl3027" x:num="3.2591283617706024">3,26</td>
      <td class="xl3027" x:num="-0.86070667866902095">-0,86</td>
      <td class="xl3027" x:num="-1.6249263643783873">-1,62</td>
      <td align="center">-0,32</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Jaguar&eacute;</td>
      <td class="xl3027" x:num="9.1721843711949358">9,17</td>
      <td class="xl3027" x:num="9.8451118789693268">9,85</td>
      <td class="xl3027" x:num="6.0869250763390781">6,09</td>
      <td class="xl3027" x:num="0.97564896061523854">0,98</td>
      <td class="xl3027" x:num="-0.48051812097458235">-0,48</td>
      <td align="center">1,62</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Lapa</td>
      <td class="xl3027" x:num="2.150856065745721">2,15</td>
      <td class="xl3027" x:num="1.2038441426588609">1,20</td>
      <td class="xl3027" x:num="1.6625095526818345">1,66</td>
      <td class="xl3027" x:num="-1.5716428792197701">-1,57</td>
      <td class="xl3027" x:num="-1.7144170055873764">-1,71</td>
      <td align="center">0,89</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Perdizes</td>
      <td class="xl3027" x:num="2.1508560657456988">2,15</td>
      <td class="xl3027" x:num="1.2038441426588609">1,20</td>
      <td class="xl3027" x:num="1.6625095526818345">1,66</td>
      <td class="xl3027" x:num="-0.68529977217240967">-0,69</td>
      <td class="xl3027" x:num="-0.67055109089595444">-0,67</td>
      <td align="center">0,82</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Vila Leopoldina</td>
      <td class="xl3027" x:num="1.7525767193424802">1,75</td>
      <td class="xl3027" x:num="1.4456007274794125">1,45</td>
      <td class="xl3027" x:num="0.97018927734868754">0,97</td>
      <td class="xl3027" x:num="-0.44540794935730155">-0,45</td>
      <td class="xl3027" x:num="1.7796912062073567E-2">0,02</td>
      <td align="center">3,92</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>M'Boi Mirim</td>
      <td class="xl2827" x:num="10.927041876718558">10,93</td>
      <td class="xl2827" x:num="14.693610868462059">14,69</td>
      <td class="xl2827" x:num="8.3932487596085625">8,39</td>
      <td class="xl2827" x:num="3.178839764527952">3,18</td>
      <td class="xl2827" x:num="2.6676247104150619">2,67</td>
      <td align="center">1,51</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Jardim &Acirc;ngela</td>
      <td class="xl3027" x:num="10.927041876718558">10,93</td>
      <td class="xl3027" x:num="14.693610868462059">14,69</td>
      <td class="xl3027" x:num="8.3932487596085625">8,39</td>
      <td class="xl3027" x:num="4.7040079824522074">4,70</td>
      <td class="xl3027" x:num="3.6271396257174793">3,63</td>
      <td align="center">1,86</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Jardim S&atilde;o Lu&iacute;s</td>
      <td class="xl3027" x:num="10.927041876718558">10,93</td>
      <td class="xl3027" x:num="14.693610868462059">14,69</td>
      <td class="xl3027" x:num="8.3932487596085625">8,39</td>
      <td class="xl3027" x:num="2.0375605470477343">2,04</td>
      <td class="xl3027" x:num="1.7668244841437808">1,77</td>
      <td align="center">1,14</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Mooca</td>
      <td class="xl2827" x:num="2.4441275697109965">2,44</td>
      <td class="xl2827" x:num="1.4049009576382554">1,40</td>
      <td class="xl2827" x:num="0.62098440983591185">0,62</td>
      <td class="xl2827" x:num="-1.3259585387900175">-1,33</td>
      <td class="xl2827" x:num="-1.5126236311428287">-1,51</td>
      <td align="center">1,11</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>&Aacute;gua Rasa</td>
      <td class="xl3027" x:num="5.5342259105940483">5,53</td>
      <td class="xl3027" x:num="3.7188599562491431">3,72</td>
      <td class="xl3027" x:num="1.5887729747498192">1,59</td>
      <td class="xl3027" x:num="-1.5246166830409691">-1,52</td>
      <td class="xl3027" x:num="-1.1245314743703827">-1,12</td>
      <td align="center">-0,11</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Bel&eacute;m</td>
      <td class="xl3027" x:num="1.0361837663223739">1,04</td>
      <td class="xl3027" x:num="-0.46283000425568765">-0,46</td>
      <td class="xl3027" x:num="-0.48269035487708001">-0,48</td>
      <td class="xl3027" x:num="-1.2693919309768931">-1,27</td>
      <td class="xl3027" x:num="-2.4859132408569073">-2,49</td>
      <td align="center">1,29</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Br&aacute;s</td>
      <td class="xl3027" x:num="-1.1912160560883622">-1,19</td>
      <td class="xl3027" x:num="-1.7401914298427079">-1,74</td>
      <td class="xl3027" x:num="-0.59510755031784157">-0,60</td>
      <td class="xl3027" x:num="-1.2772323147123843">-1,28</td>
      <td class="xl3027" x:num="-3.1433535597844342">-3,14</td>
      <td align="center">1,52</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Mo&oacute;ca</td>
      <td class="xl3027" x:num="2.874675954002659">2,87</td>
      <td class="xl3027" x:num="1.8423538853537424">1,84</td>
      <td class="xl3027" x:num="1.2929451922108814">1,29</td>
      <td class="xl3027" x:num="-1.4536734871776202">-1,45</td>
      <td class="xl3027" x:num="-1.4240180846245565">-1,42</td>
      <td align="center">1,81</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Pari</td>
      <td class="xl3027" x:num="0.73964221892994786">0,74</td>
      <td class="xl3027" x:num="-1.1864170499363391">-1,19</td>
      <td class="xl3027" x:num="-1.0312867229242739">-1,03</td>
      <td class="xl3027" x:num="-2.1226834639798686">-2,12</td>
      <td class="xl3027" x:num="-3.9468085609900228">-3,95</td>
      <td align="center">1,56</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Tatuap&eacute;</td>
      <td class="xl3027" x:num="5.8929795734431467">5,89</td>
      <td class="xl3027" x:num="3.248033000448447">3,25</td>
      <td class="xl3027" x:num="0.71082562279201067">0,71</td>
      <td class="xl3027" x:num="-0.79894654879971716">-0,80</td>
      <td class="xl3027" x:num="-0.33839367296227829">-0,34</td>
      <td align="center">1,45</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Parelheiros</td>
      <td class="xl2827" x:num="6.5834610704483376">6,58</td>
      <td class="xl2827" x:num="15.169308986323337">15,17</td>
      <td class="xl2827" x:num="10.217859372355132">10,22</td>
      <td class="xl2827" x:num="4.9624311578966074">4,96</td>
      <td class="xl2827" x:num="6.7901011969295322">6,79</td>
      <td align="center">2,29</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Marsilac</td>
      <td class="xl3027" x:num="0.90019100097389337">0,90</td>
      <td class="xl3027" x:num="4.3217672156320441">4,32</td>
      <td class="xl3027" x:num="8.1999177699797254">8,20</td>
      <td class="xl3027" x:num="2.7648586944648113">2,76</td>
      <td class="xl3027" x:num="3.8302272013129413">3,83</td>
      <td align="center">-0,18</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Parelheiros</td>
      <td class="xl3027" x:num="13.805758424937409">13,81</td>
      <td class="xl3027" x:num="19.228480662479996">19,23</td>
      <td class="xl3027" x:num="10.535983460753439">10,54</td>
      <td class="xl3027" x:num="5.236189267828828">5,24</td>
      <td class="xl3027" x:num="7.0729318887778225">7,07</td>
      <td align="center">2,46</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Penha</td>
      <td class="xl2827" x:num="6.9939536595417851">6,99</td>
      <td class="xl2827" x:num="4.9991544298176205">5,00</td>
      <td class="xl2827" x:num="3.2420708166985168">3,24</td>
      <td class="xl2827" x:num="0.25154663005491074">0,25</td>
      <td class="xl2827" x:num="5.8154934460930008E-3">0,01</td>
      <td align="center">-0,03</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Artur Alvim</td>
      <td class="xl3027" x:num="7.8995632953132944">7,90</td>
      <td class="xl3027" x:num="6.8464486789982848">6,85</td>
      <td class="xl3027" x:num="4.5527248299002565">4,55</td>
      <td class="xl3027" x:num="0.92359155558014994">0,92</td>
      <td class="xl3027" x:num="-0.70587716661202338">-0,71</td>
      <td align="center">-0,55</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Canga&iacute;ba</td>
      <td class="xl3027" x:num="9.9181331663613648">9,92</td>
      <td class="xl3027" x:num="6.5686973732161258">6,57</td>
      <td class="xl3027" x:num="4.0674938952254491">4,07</td>
      <td class="xl3027" x:num="1.490031366328548">1,49</td>
      <td class="xl3027" x:num="1.9936277539680525">1,99</td>
      <td align="center">-0,06</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Penha</td>
      <td class="xl3027" x:num="5.6658714731218529">5,67</td>
      <td class="xl3027" x:num="2.8560521916225268">2,86</td>
      <td class="xl3027" x:num="0.94381939381755764">0,94</td>
      <td class="xl3027" x:num="-0.47859630501168038">-0,48</td>
      <td class="xl3027" x:num="-0.75006844026130892">-0,75</td>
      <td align="center">0,28</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Vila Matilde</td>
      <td class="xl3027" x:num="7.4711772589879155">7,47</td>
      <td class="xl3027" x:num="6.3945309052642507">6,39</td>
      <td class="xl3027" x:num="4.6837102453061163">4,68</td>
      <td class="xl3027" x:num="-0.6806861524654928">-0,68</td>
      <td class="xl3027" x:num="-0.6364233935655772">-0,64</td>
      <td align="center">0,19</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Perus</td>
      <td class="xl2827" x:num="5.2398118310248876">5,24</td>
      <td class="xl2827" x:num="11.369713927841318">11,37</td>
      <td class="xl2827" x:num="5.8898984259605047">5,89</td>
      <td class="xl2827" x:num="3.1934513317979585">3,19</td>
      <td class="xl2827" x:num="7.129556255327385">7,13</td>
      <td align="center">2,96</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Anhanguera</td>
      <td class="xl3027" x:num="9.1629395438380676">9,16</td>
      <td class="xl3027" x:num="9.8085466327971318">9,81</td>
      <td class="xl3027" x:num="7.3741826259667853">7,37</td>
      <td class="xl3027" x:num="7.9477155175732728">7,95</td>
      <td class="xl3027" x:num="13.383092865541734">13,38</td>
      <td align="center">5,54</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Perus</td>
      <td class="xl3027" x:num="4.7735409922385896">4,77</td>
      <td class="xl3027" x:num="11.585046258666987">11,59</td>
      <td class="xl3027" x:num="5.6886395707717252">5,69</td>
      <td class="xl3027" x:num="2.2635079884594234">2,26</td>
      <td class="xl3027" x:num="4.8136731183893833">4,81</td>
      <td align="center">1,27</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Pinheiros</td>
      <td class="xl2827" x:num="3.8709326205703665">3,87</td>
      <td class="xl2827" x:num="1.8793497449367313">1,88</td>
      <td class="xl2827" x:num="2.4354495238983809">2,44</td>
      <td class="xl2827" x:num="-0.98303579334259039">-0,98</td>
      <td class="xl2827" x:num="-2.4142314255707564">-2,41</td>
      <td align="center">0,61</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Alto de Pinheiros</td>
      <td class="xl3027" x:num="2.6540826707823983">2,65</td>
      <td class="xl3027" x:num="1.5095576818387135">1,51</td>
      <td class="xl3027" x:num="1.3912838773542546">1,39</td>
      <td class="xl3027" x:num="-0.14795559894643651">-0,15</td>
      <td class="xl3027" x:num="-1.374505469772791">-1,37</td>
      <td align="center">-0,30</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Itaim Bibi</td>
      <td class="xl3027" x:num="6.970376265848266">6,97</td>
      <td class="xl3027" x:num="3.2098976165500837">3,21</td>
      <td class="xl3027" x:num="3.0743806903259285">3,07</td>
      <td class="xl3027" x:num="-0.60800891909340571">-0,61</td>
      <td class="xl3027" x:num="-3.0352054253343863">-3,04</td>
      <td align="center">1,29</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Jardim Paulista</td>
      <td class="xl3027" x:num="2.7385145882862894">2,74</td>
      <td class="xl3027" x:num="1.3653916968419999">1,37</td>
      <td class="xl3027" x:num="2.609483751743813">2,61</td>
      <td class="xl3027" x:num="-1.2014181603869356">-1,20</td>
      <td class="xl3027" x:num="-2.2978898780397161">-2,30</td>
      <td align="center">0,58</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Pinheiros</td>
      <td class="xl3027" x:num="3.6025959890634729">3,60</td>
      <td class="xl3027" x:num="1.370312783378802">1,37</td>
      <td class="xl3027" x:num="2.0755578593628199">2,08</td>
      <td class="xl3027" x:num="-1.6728025613144681">-1,67</td>
      <td class="xl3027" x:num="-2.4348044585674522">-2,43</td>
      <td align="center">0,37</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Pirituba</td>
      <td class="xl2827" x:num="10.333985578339089">10,33</td>
      <td class="xl2827" x:num="7.6898339839558183">7,69</td>
      <td class="xl2827" x:num="3.5126717754911052">3,51</td>
      <td class="xl2827" x:num="2.165695093825093">2,17</td>
      <td class="xl2827" x:num="2.3852818525079922">2,39</td>
      <td align="center">1,14</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Jaragu&aacute;</td>
      <td class="xl3027" x:num="9.7872315120999041">9,79</td>
      <td class="xl3027" x:num="8.5755982006462617">8,58</td>
      <td class="xl3027" x:num="4.8492704943582154">4,85</td>
      <td class="xl3027" x:num="6.3345386022247929">6,33</td>
      <td class="xl3027" x:num="5.1076593124544045">5,11</td>
      <td align="center">2,39</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Pirituba</td>
      <td class="xl3027" x:num="10.415867279945502">10,42</td>
      <td class="xl3027" x:num="8.2371012305821001">8,24</td>
      <td class="xl3027" x:num="3.246125288314361">3,25</td>
      <td class="xl3027" x:num="1.2620380284902977">1,26</td>
      <td class="xl3027" x:num="0.67394075235149842">0,67</td>
      <td align="center">0,37</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>S&atilde;o Domingos</td>
      <td class="xl3027" x:num="10.470022364542375">10,47</td>
      <td class="xl3027" x:num="6.2917283784037492">6,29</td>
      <td class="xl3027" x:num="3.1840632590808271">3,18</td>
      <td class="xl3027" x:num="0.12088719567402428">0,12</td>
      <td class="xl3027" x:num="1.825848742708458">1,83</td>
      <td align="center">0,24</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Santana/Tucuruvi</td>
      <td class="xl2827" x:num="7.6246122508472736">7,62</td>
      <td class="xl2827" x:num="4.8203579053402112">4,82</td>
      <td class="xl2827" x:num="2.619094956317225">2,62</td>
      <td class="xl2827" x:num="0.28160663150500476">0,28</td>
      <td class="xl2827" x:num="-0.86017887870186716">-0,86</td>
      <td align="center">-0,07</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Mandaqui</td>
      <td class="xl3027" x:num="7.9880790603670926">7,99</td>
      <td class="xl3027" x:num="4.9545074497996167">4,95</td>
      <td class="xl3027" x:num="2.8013140486898402">2,80</td>
      <td class="xl3027" x:num="1.5109677926737453">1,51</td>
      <td class="xl3027" x:num="-9.7474029664457174E-2">-0,10</td>
      <td align="center">0,42</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Santana</td>
      <td class="xl3027" x:num="7.1504322319826397">7,15</td>
      <td class="xl3027" x:num="4.6351602416114135">4,64</td>
      <td class="xl3027" x:num="2.3582654398834668">2,36</td>
      <td class="xl3027" x:num="-8.8459524529871381E-2">-0,09</td>
      <td class="xl3027" x:num="-1.0981809168537082">-1,10</td>
      <td align="center">-0,48</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Tucuruvi</td>
      <td class="xl3027" x:num="7.9880790603670926">7,99</td>
      <td class="xl3027" x:num="4.9545074497996167">4,95</td>
      <td class="xl3027" x:num="2.8013140486898402">2,80</td>
      <td class="xl3027" x:num="-0.29551190592663756">-0,30</td>
      <td class="xl3027" x:num="-1.3094893745052905">-1,31</td>
      <td align="center">-0,09</td>
    </tr>
    <tr height="17" style='page-break-before:always;height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Santo Amaro</td>
      <td class="xl2827" x:num="12.204672964622709">12,20</td>
      <td class="xl2827" x:num="8.5724741719644282">8,57</td>
      <td class="xl2827" x:num="5.7340022926306577">5,73</td>
      <td class="xl2827" x:num="-0.14578976022593393">-0,15</td>
      <td class="xl2827" x:num="-0.82892566827738046">-0,83</td>
      <td align="center">0,86</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Campo Belo</td>
      <td class="xl3027" x:num="13.408837782753324">13,41</td>
      <td class="xl3027" x:num="5.0766988690793324">5,08</td>
      <td class="xl3027" x:num="3.6277680100753162">3,63</td>
      <td class="xl3027" x:num="0.2752125887342638">0,28</td>
      <td class="xl3027" x:num="-1.7260219531996968">-1,73</td>
      <td align="center">-0,13</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Campo Grande</td>
      <td class="xl3027" x:num="10.293401996658913">10,29</td>
      <td class="xl3027" x:num="13.190773421668634">13,19</td>
      <td class="xl3027" x:num="7.318503814169075">7,32</td>
      <td class="xl3027" x:num="1.3909662082322249">1,39</td>
      <td class="xl3027" x:num="1.202695324707248">1,20</td>
      <td align="center">0,98</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Santo Amaro</td>
      <td class="xl3027" x:num="11.373424024281098">11,37</td>
      <td class="xl3027" x:num="10.687558128950482">10,69</td>
      <td class="xl3027" x:num="6.5764846823316292">6,58</td>
      <td class="xl3027" x:num="-1.8951337711572869">-1,90</td>
      <td class="xl3027" x:num="-2.4320084675667153">-2,43</td>
      <td align="center">1,69</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>S&atilde;o Mateus</td>
      <td class="xl2827" x:num="6.9305936127493473">6,93</td>
      <td class="xl2827" x:num="8.801521283710434">8,80</td>
      <td class="xl2827" x:num="5.1197099350208219">5,12</td>
      <td class="xl2827" x:num="2.8118224530528702">2,81</td>
      <td class="xl2827" x:num="2.6958544298236742">2,70</td>
      <td align="center">1,12</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Iguatemi</td>
      <td class="xl3027" x:num="8.639770144243597">8,64</td>
      <td class="xl3027" x:num="14.93715457493261">14,94</td>
      <td class="xl3027" x:num="7.6333255280638612">7,63</td>
      <td class="xl3027" x:num="5.6749809928497763">5,67</td>
      <td class="xl3027" x:num="6.0831058782636172">6,08</td>
      <td align="center">2,29</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>S&atilde;o Mateus</td>
      <td class="xl3027" x:num="6.6584887111336144">6,66</td>
      <td class="xl3027" x:num="6.0472228195048938">6,05</td>
      <td class="xl3027" x:num="3.2452926730732301">3,25</td>
      <td class="xl3027" x:num="2.2194801140765108">2,22</td>
      <td class="xl3027" x:num="0.29756636500646305">0,30</td>
      <td align="center">0,02</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>S&atilde;o Rafael</td>
      <td class="xl3027" x:num="8.1706726765871771">8,17</td>
      <td class="xl3027" x:num="18.286890706189119">18,29</td>
      <td class="xl3027" x:num="7.9595706318444037">7,96</td>
      <td class="xl3027" x:num="2.2380520789643699">2,24</td>
      <td class="xl3027" x:num="3.7432745812172374">3,74</td>
      <td align="center">1,42</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>S&atilde;o Miguel</td>
      <td class="xl2827" x:num="12.862668726753235">12,86</td>
      <td class="xl2827" x:num="13.061950863064276">13,06</td>
      <td class="xl2827" x:num="6.5712083229867879">6,57</td>
      <td class="xl2827" x:num="1.9464744150459179">1,95</td>
      <td class="xl2827" x:num="1.7902584812490296">1,79</td>
      <td align="center">-0,24</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Jardim Helena</td>
      <td class="xl3027" x:num="13.428576434588923">13,43</td>
      <td class="xl3027" x:num="13.549565822358112">13,55</td>
      <td class="xl3027" x:num="6.5585136929890986">6,56</td>
      <td class="xl3027" x:num="2.4120655231101518">2,41</td>
      <td class="xl3027" x:num="1.8086955921193359">1,81</td>
      <td align="center">-0,30</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt' x:str="S&atilde;o Miguel ">S&atilde;o
        Miguel<span style='mso-spacerun:yes'>&nbsp;</span></td>
      <td class="xl3027" x:num="11.637310603226613">11,64</td>
      <td class="xl3027" x:num="15.257530840318134">15,26</td>
      <td class="xl3027" x:num="7.227127189267768">7,23</td>
      <td class="xl3027" x:num="0.24934522093733591">0,25</td>
      <td class="xl3027" x:num="-0.61841818266916704">-0,62</td>
      <td align="center">-0,56</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Vila Jacu&iacute;</td>
      <td class="xl3027" x:num="13.432104961951064">13,43</td>
      <td class="xl3027" x:num="10.399463585738644">10,40</td>
      <td class="xl3027" x:num="5.7150212710104675">5,72</td>
      <td class="xl3027" x:num="3.4539701229492126">3,45</td>
      <td class="xl3027" x:num="3.8279351388888605">3,83</td>
      <td align="center">0,03</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>S&eacute;</td>
      <td class="xl2827" x:num="2.1163547843009889">2,12</td>
      <td class="xl2827" x:num="0.28444767663056147">0,28</td>
      <td class="xl2827" x:num="1.6856323426334807">1,69</td>
      <td class="xl2827" x:num="-1.24023076342481">-1,24</td>
      <td class="xl2827" x:num="-2.2446513004688806">-2,24</td>
      <td align="center">1,43</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Bela Vista</td>
      <td class="xl3027" x:num="2.1570407345268938">2,16</td>
      <td class="xl3027" x:num="1.2113015779657843">1,21</td>
      <td class="xl3027" x:num="2.8160219836047773">2,82</td>
      <td class="xl3027" x:num="-1.5630730476418497">-1,56</td>
      <td class="xl3027" x:num="-1.4131044348688282">-1,41</td>
      <td align="center">0,95</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Bom Retiro</td>
      <td class="xl3027" x:num="1.6228065531844305">1,62</td>
      <td class="xl3027" x:num="-1.6436683146922038">-1,64</td>
      <td class="xl3027" x:num="0.41389268487799225">0,41</td>
      <td class="xl3027" x:num="-2.4715402774732942">-2,47</td>
      <td class="xl3027" x:num="-3.3477206477960042">-3,35</td>
      <td align="center">2,45</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Cambuci</td>
      <td class="xl3027" x:num="1.1471938655819747">1,15</td>
      <td class="xl3027" x:num="-1.5457008808061889E-2">-0,02</td>
      <td class="xl3027" x:num="1.2203960466750763">1,22</td>
      <td class="xl3027" x:num="-1.7174077452168146">-1,72</td>
      <td class="xl3027" x:num="-2.7967220174239915">-2,80</td>
      <td align="center">2,55</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Consola&ccedil;&atilde;o</td>
      <td class="xl3027" x:num="3.1605512961369708">3,16</td>
      <td class="xl3027" x:num="1.5068909931958974">1,51</td>
      <td class="xl3027" x:num="2.4688948409985256">2,47</td>
      <td class="xl3027" x:num="-1.3511260807085312">-1,35</td>
      <td class="xl3027" x:num="-2.1971707751998082">-2,20</td>
      <td align="center">0,51</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Liberdade</td>
      <td class="xl3027" x:num="2.0793179668062711">2,08</td>
      <td class="xl3027" x:num="0.47261032894656552">0,47</td>
      <td class="xl3027" x:num="1.437429122025069">1,44</td>
      <td class="xl3027" x:num="-0.71115722520540547">-0,71</td>
      <td class="xl3027" x:num="-2.2936816042632979">-2,29</td>
      <td align="center">1,11</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Rep&uacute;blica</td>
      <td class="xl3027" x:num="2.9942430686085375">2,99</td>
      <td class="xl3027" x:num="0.40644375259328847">0,41</td>
      <td class="xl3027" x:num="1.937519184505665">1,94</td>
      <td class="xl3027" x:num="-0.4889608409526347">-0,49</td>
      <td class="xl3027" x:num="-2.1066945859009478">-2,11</td>
      <td align="center">1,79</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Santa Cec&iacute;lia</td>
      <td class="xl3027" x:num="2.4172302182705829">2,42</td>
      <td class="xl3027" x:num="0.30530865213846958">0,31</td>
      <td class="xl3027" x:num="1.3014185200362016">1,30</td>
      <td class="xl3027" x:num="-0.87512836468224275">-0,88</td>
      <td class="xl3027" x:num="-2.0580722628953829">-2,06</td>
      <td align="center">1,64</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>S&eacute;</td>
      <td class="xl3027" x:num="0.74725587881736555">0,75</td>
      <td class="xl3027" x:num="-0.89723027096653141">-0,90</td>
      <td class="xl3027" x:num="1.097776150867702">1,10</td>
      <td class="xl3027" x:num="-1.7369419285694687">-1,74</td>
      <td class="xl3027" x:num="-3.2916756815689174">-3,29</td>
      <td align="center">1,63</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Vila Maria/Vila Guilherme</td>
      <td class="xl2827" x:num="8.660313065968662">8,66</td>
      <td class="xl2827" x:num="4.6189989437394052">4,62</td>
      <td class="xl2827" x:num="2.365520196860027">2,37</td>
      <td class="xl2827" x:num="-0.56957412762574933">-0,57</td>
      <td class="xl2827" x:num="-1.2354282799314387">-1,24</td>
      <td align="center">-0,22</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Vila Guilherme</td>
      <td class="xl3027" x:num="8.3425884891814128">8,34</td>
      <td class="xl3027" x:num="5.0546357851929402">5,05</td>
      <td class="xl3027" x:num="2.2020801724660366">2,20</td>
      <td class="xl3027" x:num="-0.94512213976433168">-0,95</td>
      <td class="xl3027" x:num="-2.2994250413142181">-2,30</td>
      <td align="center">0,84</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Vila Maria</td>
      <td class="xl3027" x:num="8.1268405443931648">8,13</td>
      <td class="xl3027" x:num="4.1195721596870571">4,12</td>
      <td class="xl3027" x:num="2.2358390127702243">2,24</td>
      <td class="xl3027" x:num="-0.6703312317208554">-0,67</td>
      <td class="xl3027" x:num="-0.82540501774589492">-0,83</td>
      <td align="center">-0,03</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Vila Medeiros</td>
      <td class="xl3027" x:num="9.3146115380874139">9,31</td>
      <td class="xl3027" x:num="4.8671073231675965">4,87</td>
      <td class="xl3027" x:num="2.5432942839791695">2,54</td>
      <td class="xl3027" x:num="-0.33501551365882065">-0,34</td>
      <td class="xl3027" x:num="-1.1608774296552715">-1,16</td>
      <td align="center">-0,78</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Vila Mariana</td>
      <td class="xl2827" x:num="5.5461890212772369">5,55</td>
      <td class="xl2827" x:num="3.2720368372743502">3,27</td>
      <td class="xl2827" x:num="2.3764719171596393">2,38</td>
      <td class="xl2827" x:num="-0.3914389741310198">-0,39</td>
      <td class="xl2827" x:num="-0.80834155723832346">-0,81</td>
      <td align="center">0,97</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Moema</td>
      <td class="xl3027" x:num="3.8563027838934616">3,86</td>
      <td class="xl3027" x:num="1.462728202007102">1,46</td>
      <td class="xl3027" x:num="2.3195455772805795">2,32</td>
      <td class="xl3027" x:num="0.63198578287178009">0,63</td>
      <td class="xl3027" x:num="-0.90313723000362556">-0,90</td>
      <td align="center">1,58</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Sa&uacute;de</td>
      <td class="xl3027" x:num="8.0870624566005134">8,09</td>
      <td class="xl3027" x:num="5.2049839215375648">5,20</td>
      <td class="xl3027" x:num="2.6498522747549158">2,65</td>
      <td class="xl3027" x:num="-0.66391591015420026">-0,66</td>
      <td class="xl3027" x:num="-0.77105598958325805">-0,77</td>
      <td align="center">1,03</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Vila Mariana</td>
      <td class="xl3027" x:num="5.0055170626509549">5,01</td>
      <td class="xl3027" x:num="2.6960969877151575">2,70</td>
      <td class="xl3027" x:num="2.1517418805667043">2,15</td>
      <td class="xl3027" x:num="-0.68299942956614457">-0,68</td>
      <td class="xl3027" x:num="-0.78896063031682617">-0,79</td>
      <td align="center">0,54</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl3513" style='height:12.75pt'>Vila Prudente/Sapopemba</td>
      <td class="xl2827" x:num="6.4053963084202303">6,41</td>
      <td class="xl2827" x:num="6.0196853973287778">6,02</td>
      <td class="xl2827" x:num="3.6228984309351731">3,62</td>
      <td class="xl2827" x:num="1.1864681876911698">1,19</td>
      <td class="xl2827" x:num="-5.8119138752976696E-3">-0,01</td>
      <td align="center">0,14</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>S&atilde;o Lucas</td>
      <td class="xl3027" x:num="7.7933617941526201">7,79</td>
      <td class="xl3027" x:num="6.1387307677972736">6,14</td>
      <td class="xl3027" x:num="3.2596790476201898">3,26</td>
      <td class="xl3027" x:num="-0.25866885233423176">-0,26</td>
      <td class="xl3027" x:num="-0.96476689983369113">-0,96</td>
      <td align="center">0,21</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td height="17" class="xl2926" style='height:12.75pt'>Sapopemba</td>
      <td class="xl3027" x:num="7.8564729843687564">7,86</td>
      <td class="xl3027" x:num="9.2322426460806906">9,23</td>
      <td class="xl3027" x:num="5.2607295409495158">5,26</td>
      <td class="xl3027" x:num="3.3658318410094035">3,37</td>
      <td class="xl3027" x:num="1.0193856253957634">1,02</td>
      <td align="center">0,08</td>
    </tr>
    <tr height="18" style='height:13.5pt'>
      <td height="18" class="xl3127" style='height:13.5pt'>Vila Prudente</td>
      <td class="xl3224" x:num="4.6448773773105634">4,64</td>
      <td class="xl3224" x:num="3.3983648377919673">3,40</td>
      <td class="xl3224" x:num="2.066401436679377">2,07</td>
      <td class="xl3224" x:num="-0.79434444691800499">-0,79</td>
      <td class="xl3224" x:num="-1.2456042345837859">-1,25</td>
      <td class="xl3224">0,21</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td colspan="7" height="17" class="xl378" style='height:12.75pt'>Fonte: IBGE -
        Censos Demogr&aacute;ficos, 1950, 1960, 1970, 1980, 1991, 2000, 2010</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td colspan="7" height="17" class="xl378" style='height:12.75pt'><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Sinopses Preliminares dos Censos
        Demogr&aacute;ficos de 1950 e 1960</td>
    </tr>
    <tr height="17" style='height:12.75pt'>
      <td colspan="7" height="17" class="xl378" style='height:12.75pt'
  x:str="           Sempla/Dipro - Retroestimativas e Recomposi&ccedil;&atilde;o dos Distritos para os anos 1950,1960 e 1970 "><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>SMDU /Dipro - Retroestimativas e
        Recomposi&ccedil;&atilde;o dos Distritos para os anos 1950,1960 e 1970<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
    </tr>
        <tr height="17" style='height:12.75pt'>
      <td colspan="7" height="17" class="xl378" style='height:12.75pt'
  x:str="           Sempla/Dipro - Retroestimativas e Recomposi&ccedil;&atilde;o dos Distritos para os anos 1950,1960 e 1970 "><span
  style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>Elabora&ccedil;&atilde;o: Secretaria Municipal de Desenvolvimento Urbano / SMDU - Departamento de Estat&iacute;stica e Produ&ccedil;&atilde;o de Informa&ccedil;&atilde;o / Dipro<span
  style='mso-spacerun:yes'>&nbsp;</span></td>
    </tr>
    <![if supportMisalignedColumns]>
    <tr height="0" style='display:none'>
      <td width="189" style='width:142pt'></td>
      <td width="67" style='width:50pt'></td>
      <td width="67" style='width:50pt'></td>
      <td width="67" style='width:50pt'></td>
      <td width="67" style='width:50pt'></td>
      <td width="67" style='width:50pt'></td>
      <td width="67" style='width:50pt'></td>
    </tr>
    <![endif]>
  </table>
  <p>&nbsp;</p>
  <p><strong><img src="../img/seta-download.gif" width="11" height="12" /></strong><strong> </strong><a href="xls/tx_cresc.xls" title="Clique para baixar a tabela no formato Excel (.xls)"><strong>FORMATO EXCEL (.XLS)</strong></a></p>
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">  
  <p align="center">
</div>

</div>

<td><div id="assinatura">
<div style="text-align:center"><div>
</div></td>

</body>
</html>
